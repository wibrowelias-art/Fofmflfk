/* Network-first documents; bounded static cache. Never intercept market APIs. */
const CACHE = 'replay-shell-v5'
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(['/','/icon.svg','/manifest.webmanifest']))); self.skipWaiting() })
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('replay-shell-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())) })
self.addEventListener('fetch', event => {
 const request = event.request, url = new URL(request.url)
 if(request.method !== 'GET' || url.origin !== self.location.origin) return
 if(request.mode === 'navigate') {
  event.respondWith(fetch(request).then(response => { if(response.ok) { const copy=response.clone(); caches.open(CACHE).then(cache=>cache.put('/',copy)) } return response }).catch(async()=>await caches.match('/') || Response.error()))
 } else if(url.pathname.startsWith('/brand/') || url.pathname.startsWith('/art/') || url.pathname.startsWith('/icons/') || url.pathname.startsWith('/_next/static/')) {
  event.respondWith(caches.match(request).then(cached=>cached||fetch(request).then(response=>{if(response.ok){const copy=response.clone();caches.open(CACHE).then(async cache=>{await cache.put(request,copy);const keys=await cache.keys();if(keys.length>120)await cache.delete(keys[0])})}return response})))
 }
})

