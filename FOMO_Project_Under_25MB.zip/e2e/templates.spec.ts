import {test,expect} from './fixtures'
import {templates,createCandidate} from '../lib/templates'
import {makeInitialState} from '../lib/store'
import {price} from '../lib/formatting/numbers'
import {templateAssets} from '../qa/template-fixtures'
import {derivePositions} from '../lib/positions/calculations'
import {calculateFumble} from '../lib/positions/fumble'
import type {Page} from '@playwright/test'
const data=async(page:Page)=>{await page.getByRole('button',{name:'Profile',exact:true}).click();await page.getByRole('button',{name:'Profile settings'}).click();await page.getByRole('tab',{name:'Data',exact:true}).click()}
test('every template previews, replaces atomically, renders, replays and survives reload',async({page})=>{
  test.setTimeout(180000)
  const assets=templateAssets()
  await page.route('**/api/market/**',route=>{
    const url=new URL(route.request().url()),asset=assets.find(a=>a.contractAddress===url.searchParams.get('address'))??assets[0]
    return route.fulfill({json:{data:url.searchParams.has('discovery')?{assets,source:'Controlled QA response',updatedAt:Date.now()}:url.pathname.endsWith('candles')?asset.candles:url.pathname.endsWith('holders')?{items:[],cursor:null,updatedAt:Date.now()}:asset}})
  })
  await page.goto('/')
  for(const def of templates){
    await data(page)
    await page.getByRole('button',{name:`Preview ${def.name}`,exact:true}).click()
    const previous=await page.evaluate(()=>localStorage.getItem('replay:setup:v1'))
    await page.getByRole('button',{name:'Prepare preview',exact:true}).click()
    await expect(page.locator('.template-summary')).toBeVisible()
    expect(await page.evaluate(()=>localStorage.getItem('replay:setup:v1'))).toBe(previous)
    if(await page.locator('.template-confirm input').count()){await expect(page.getByRole('button',{name:'Load template',exact:true})).toBeDisabled();await page.locator('.template-confirm input').check()}
    if(def.id==='rich')await page.screenshot({animations:'disabled',path:'qa/current-template-preview-390.png'})
    await page.getByRole('button',{name:'Load template',exact:true}).click()
    await expect(page.locator('.loaded-template')).toContainText(def.name)
    const saved=await page.evaluate(()=>JSON.parse(localStorage.getItem('replay:setup:v1')!).state)
    const positions=derivePositions(saved.tradeEvents)
    expect(saved.assets.length).toBe(def.assets);expect(saved.tradeEvents.length).toBe(def.events);expect(saved.cash).toBe(def.startingCash)
    expect(positions.filter(p=>p.status==='open').length).toBe(def.open);expect(positions.filter(p=>p.status==='closed').length).toBe(def.closed)
    await page.getByRole('button',{name:'Back to app'}).click()
    if(def.assets){
      await expect(page.locator('.token-row')).toHaveCount(def.assets)
      await page.getByRole('button',{name:`Open ${saved.assets[0].symbol}`,exact:true}).click()
      if(def.events){
        await page.getByRole('button',{name:'Back',exact:true}).click();await page.getByRole('button',{name:'Portfolio balance. Hold to open Backstage',exact:true}).press('Enter');await page.getByRole('tab',{name:'Replay',exact:true}).click()
        const slider=page.getByRole('slider',{name:'Replay timeline',exact:true});await slider.press('Home');await expect(page.getByRole('button',{name:'Open position',exact:true})).toHaveCount(0);await page.getByRole('button',{name:'Jump Live',exact:true}).click()
        await page.getByRole('button',{name:'Open position',exact:true}).click();await page.getByRole('button',{name:'Share',exact:true}).click();await expect(page.getByText('Replay · Learning').first()).toBeVisible();await page.getByRole('button',{name:'Back to profile',exact:true}).click()
      }else{await page.getByRole('button',{name:'Back',exact:true}).click();await page.getByRole('button',{name:'Profile',exact:true}).click()}
    }else{await expect(page.getByText('No tokens yet')).toBeVisible();await page.getByRole('button',{name:'Profile',exact:true}).click()}
    await expect(page.getByRole('heading',{name:`Positions (${def.open+def.closed})`,exact:true})).toBeVisible()
    await page.getByRole('tab',{name:'Closed',exact:true}).click();await expect(page.locator('.position-row')).toHaveCount(def.closed)
    if(def.id==='fumble'){
      const p=positions.find(p=>calculateFumble(p,saved.tradeEvents,3.2,Date.now()))!
      const a=saved.assets.find((a:{id:string})=>a.id===p.assetId)
      await page.locator('.position-row').filter({hasText:a.symbol}).click();await page.getByRole('button',{name:/View Fumble/}).click();await expect(page.locator('.fumble-card').first()).toBeVisible();await page.getByRole('button',{name:'Back to profile',exact:true}).click()
    }
    await page.waitForTimeout(450);await page.reload()
    const restored=await page.evaluate(()=>JSON.parse(localStorage.getItem('replay:setup:v1')!).state)
    expect(restored.assets.length).toBe(def.assets);expect(restored.tradeEvents.length).toBe(def.events);expect(restored.settings.loadedTemplate.id).toBe(def.id)
    await page.screenshot({animations:'disabled',path:`qa/current-template-${def.id}-home-390.png`})
  }
})
test('cancel, provider failure and quota failure preserve the saved setup',async({page})=>{
  await page.goto('/');await data(page);await page.getByRole('tab',{name:'Funds',exact:true}).click();await page.getByLabel('Cash amount').fill('42');await page.getByRole('button',{name:'Update cash'}).click();await page.waitForTimeout(450);await page.getByRole('tab',{name:'Data',exact:true}).click()
  const previous=await page.evaluate(()=>localStorage.getItem('replay:setup:v1'))
  await page.getByRole('button',{name:'Preview Clean Start',exact:true}).click();await page.getByRole('button',{name:'Prepare preview',exact:true}).click();await page.getByRole('button',{name:'Cancel',exact:true}).click();expect(await page.evaluate(()=>localStorage.getItem('replay:setup:v1'))).toBe(previous)
  // A structured provider error is displayed in the preview; it is an expected request failure.
  await page.route('**/api/market/search?discovery=trending',route=>route.fulfill({json:{error:{message:'Controlled provider outage'}}}))
  await page.getByRole('button',{name:'Preview Rich Demo',exact:true}).click();await page.getByRole('button',{name:'Prepare preview',exact:true}).click();await expect(page.locator('.template-preview [role="alert"]')).toContainText('Controlled provider outage');expect(await page.evaluate(()=>localStorage.getItem('replay:setup:v1'))).toBe(previous)
  await page.getByRole('button',{name:'Cancel',exact:true}).click()
  await page.getByRole('button',{name:'Preview Clean Start',exact:true}).click();await page.getByRole('button',{name:'Prepare preview',exact:true}).click();await page.locator('.template-confirm input').check()
  await page.evaluate(()=>{const original=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key==='replay:setup:v1')throw new DOMException('Controlled quota failure','QuotaExceededError');return original.call(this,key,value)}})
  await page.getByRole('button',{name:'Load template',exact:true}).click();await expect(page.locator('.template-preview [role="alert"]')).toContainText('Controlled quota failure');expect(await page.evaluate(()=>localStorage.getItem('replay:setup:v1'))).toBe(previous)
})
test('scrubbing updates price and positions before release without network or persistence per pointer move',async({page})=>{
  const assets=templateAssets(),state=createCandidate(templates.find(d=>d.id==='stress')!,makeInitialState(),assets,'Controlled QA response')
  await page.addInitScript(s=>localStorage.setItem('replay:setup:v1',JSON.stringify({version:2,state:s})),state)
  let requests=0
  await page.route('**/api/market/**',route=>{requests++;const u=new URL(route.request().url()),a=assets.find(a=>a.contractAddress===u.searchParams.get('address'))??assets[0];return route.fulfill({json:{data:u.pathname.endsWith('candles')?a.candles:u.pathname.endsWith('holders')?{items:[],cursor:null,updatedAt:Date.now()}:a}})})
  await page.goto('/');await page.getByRole('button',{name:'Open QA0',exact:true}).click();await page.getByRole('button',{name:'Back',exact:true}).click();await page.getByRole('button',{name:'Portfolio balance. Hold to open Backstage',exact:true}).press('Enter');await page.getByRole('tab',{name:'Replay',exact:true}).click()
  const slider=page.getByRole('slider',{name:'Replay timeline',exact:true});await slider.press('End');await page.waitForTimeout(450)
  const saved=await page.evaluate(()=>localStorage.getItem('replay:setup:v1')),before=requests,box=(await slider.boundingBox())!
  await page.mouse.move(box.x+box.width*.03,box.y+box.height/2);await page.mouse.down();await page.waitForTimeout(450)
  const index=Number(await slider.getAttribute('aria-valuenow'));expect(index).toBe(3)
  await expect(page.getByTestId('replay-price')).toHaveText(price(assets[0].candles[index].close));await expect(page.getByRole('button',{name:'Open position',exact:true})).toHaveCount(0)
  expect(await page.evaluate(()=>localStorage.getItem('replay:setup:v1'))).toBe(saved);expect(requests).toBe(before)
  await page.mouse.move(box.x+box.width*.9,box.y+box.height/2);await page.waitForTimeout(100);await expect(page.getByRole('button',{name:'Open position',exact:true})).toBeVisible()
  await page.mouse.up();await page.waitForTimeout(450)
  expect(await page.evaluate(()=>JSON.parse(localStorage.getItem('replay:setup:v1')!).state.timeline.timestamp)).toBe(assets[0].candles[89].timestamp)
  expect(await page.locator('.replay-workbench .price-chart').evaluate(svg=>{
    const wicks=Array.from(svg.querySelectorAll('g[fill][stroke] > line'))
    const markers=Array.from(svg.querySelectorAll('.trade-marker > circle:not([fill=transparent])'))
    return markers.length>0&&markers.every(circle=>{const x=Number(circle.getAttribute('cx')),wick=wicks.find(line=>Math.abs(Number(line.getAttribute('x1'))-x)<1e-7);return wick&&Number(circle.getAttribute('cy'))+Number(circle.getAttribute('r'))<=Number(wick.getAttribute('y1'))-6+1e-7})
  })).toBeTruthy()
  await page.screenshot({animations:'disabled',path:'qa/current-marker-stress-token-390.png'})
  await slider.press('Home');for(let i=0;i<6;i++)await slider.press('PageUp')
  await page.getByRole('button',{name:'Open position',exact:true}).click()
  await expect(page.locator('.position-sheet .trade-marker[data-side="buy"]')).not.toHaveCount(0)
  await expect(page.locator('.position-sheet .trade-marker[data-side="sell"]')).toHaveCount(0)
  await page.screenshot({animations:'disabled',path:'qa/current-marker-buys-position-390.png'});await page.getByRole('button',{name:'Close sheet'}).click()
  await slider.press('End');await page.getByRole('button',{name:'Open position',exact:true}).click()
  for(const [width,height]of [[375,812],[390,844],[393,852],[412,915],[430,932]]){await page.setViewportSize({width,height});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();await page.screenshot({animations:'disabled',path:`qa/current-marker-sells-position-${width}.png`})}
})
