import {test as base,expect} from '@playwright/test'
import {writeFile} from 'node:fs/promises'
export const test=base.extend<{audit:void}>({audit:[async({page},use,testInfo)=>{
 const errors:string[]=[],consoleMessages:string[]=[],network:string[]=[]
 page.on('pageerror',e=>errors.push(e.message))
 page.on('console',m=>{if(['warning','error'].includes(m.type()))consoleMessages.push(`${m.type()}: ${m.text()}`)})
 page.on('response',r=>{if(r.status()>=400)network.push(`${r.status()} ${r.url()}`)})
 page.on('requestfailed',r=>network.push(`${r.failure()?.errorText} ${r.url()}`))
 await use()
 await writeFile(`qa/audit-${testInfo.title.replace(/[^a-z0-9]+/gi,'-').slice(0,90)}.json`,JSON.stringify({test:testInfo.title,errors,consoleMessages,network},null,2))
 expect(errors,'Browser runtime errors').toEqual([])
},{auto:true}]})
export {expect}
