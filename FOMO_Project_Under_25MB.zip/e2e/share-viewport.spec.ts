import {test,expect} from './fixtures'
import {makeFixtureState} from '../lib/store'
const sizes=[[375,812],[390,844],[393,852],[412,915],[430,932]]
test('position, share, Fumble and deposit remain usable across mobile widths',async({page})=>{
 const state=makeFixtureState(),asset=state.assets.find(a=>a.id==='si')!,candles=asset.candles
 state.cash=1000;state.tradeEvents=[{id:'share-buy',assetId:asset.id,side:'buy',timestamp:candles[100].timestamp,priceUsd:candles[100].close,marketCapUsd:candles[100].marketCapUsd??null,units:1000,usdValue:1000*candles[100].close},{id:'share-sell',assetId:asset.id,side:'sell',timestamp:candles[150].timestamp,priceUsd:candles[150].close,marketCapUsd:candles[150].marketCapUsd??null,units:1000,usdValue:1000*candles[150].close}]
 await page.addInitScript(s=>localStorage.setItem('replay:setup:v1',JSON.stringify({version:2,state:s})),state)
 const capture=async(name:string)=>{for(const [width,height]of sizes){await page.setViewportSize({width,height});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();await page.screenshot({path:`qa/final-${name}-${width}.png`,animations:'disabled'})}await page.setViewportSize({width:390,height:844})}
 await page.goto('/');await page.getByRole('button',{name:'Deposit',exact:true}).click();await capture('deposit');await page.getByRole('button',{name:'Close sheet'}).click()
 await page.getByRole('button',{name:'Open SI',exact:true}).click();await page.getByRole('button',{name:'Open position',exact:true}).click();await capture('position');await page.getByRole('button',{name:'Share',exact:true}).click();await capture('position-share');await page.getByRole('switch',{name:'Buy/Sell',exact:true}).click();await expect(page.getByRole('switch',{name:'Buy/Sell',exact:true})).toHaveAttribute('aria-checked','false')
 await page.getByRole('button',{name:'Back to profile',exact:true}).click();await page.getByRole('tab',{name:'Closed',exact:true}).click();await page.locator('.position-row').click();await page.getByRole('button',{name:/View Fumble/}).click();await capture('fumble-share')
})

