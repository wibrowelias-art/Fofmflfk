import {test,expect} from './fixtures'
import type {Page} from '@playwright/test'
import {makeFixtureState,makeInitialState} from '../lib/store'
import {derivePositions} from '../lib/positions/calculations'
import {selectPositionView} from '../lib/positions/selectors'
import {quoteAt,candleAtOrBefore} from '../lib/market/timeline'
import {money,price} from '../lib/formatting/numbers'
import {writeFile} from 'node:fs/promises'
const fixture=()=>{const s=makeFixtureState(),a=s.assets.find(a=>a.id==='si')!,b=a.candles[100],e=a.candles[150];s.cash=1000;s.settings.appearance={reducedMotion:true};s.tradeEvents=[{id:'completion-buy',assetId:a.id,side:'buy' as const,timestamp:b.timestamp,priceUsd:b.close,marketCapUsd:b.marketCapUsd??null,units:1000,usdValue:1000*b.close},{id:'completion-sell',assetId:a.id,side:'sell' as const,timestamp:e.timestamp,priceUsd:e.close,marketCapUsd:e.marketCapUsd??null,units:1000,usdValue:1000*e.close}];s.positions=derivePositions(s.tradeEvents);return s}
async function seed(page:Page,s=fixture()){await page.addInitScript(state=>{if(!localStorage.getItem('replay:setup:v1'))localStorage.setItem('replay:setup:v1',JSON.stringify({version:2,state}))},s);await page.goto('/');await expect(page.getByRole('button',{name:'Profile',exact:true})).toBeVisible()}
async function backstage(page:Page,tab:string){await page.getByRole('button',{name:'Profile',exact:true}).click();await page.getByRole('button',{name:'Profile settings'}).click();await page.getByRole('tab',{name:tab,exact:true}).click()}
async function saved(page:Page){return page.evaluate(()=>JSON.parse(localStorage.getItem('replay:setup:v1')!).state)}

test('public pan follows right-edge historical price and MC, preserves global state and permits vertical touch scroll',async({page})=>{
  const s=fixture(),asset=s.assets.find(a=>a.id==='si')!;await seed(page,s);await page.getByRole('button',{name:'Open SI',exact:true}).click();await page.waitForTimeout(450)
  const before=await saved(page),chart=page.locator('.pan-chart'),box=(await chart.boundingBox())!
  await page.mouse.move(box.x+60,box.y+box.height*.7);await page.mouse.down();await page.mouse.move(box.x+200,box.y+box.height*.7,{steps:16});await page.waitForTimeout(50)
  await expect(page.locator('.token-screen')).toHaveAttribute('data-chart-context','historical')
  const right=Number(await chart.getAttribute('data-domain-last')),selected=candleAtOrBefore(asset.candles,right)!,q=quoteAt(asset,{type:'replay',timestamp:selected.timestamp,speed:0})
  await expect(page.locator('.token-screen')).toHaveAttribute('data-context-timestamp',String(selected.timestamp))
  await expect(page.getByTestId('token-context-price')).toHaveText(price(q.priceUsd));await expect(page.getByTestId('token-context-mc')).toHaveText(money(q.marketCapUsd,true))
  await expect(chart.locator('text').filter({hasText:price(q.priceUsd)}).first()).toBeVisible()
  await page.mouse.up();await page.waitForTimeout(450);const after=await saved(page);expect(after.timeline).toEqual(before.timeline);expect(after.cash).toBe(before.cash);expect(after.tradeEvents).toEqual(before.tradeEvents)
  await chart.press('End');await expect(page.locator('.token-screen')).toHaveAttribute('data-chart-context','live');await expect(page.getByTestId('token-context-price')).toHaveText(price(quoteAt(asset,s.timeline).priceUsd))
  // A hold stays ordinary chart browsing. There is no hidden global replay gesture.
  await page.mouse.move(box.x+120,box.y+100);await page.mouse.down();await page.waitForTimeout(650);await page.mouse.up();await expect(page.locator('.replay-dock')).toHaveCount(0);await expect(page.locator('.token-screen')).toHaveAttribute('data-chart-context','live')
  const cdp=await page.context().newCDPSession(page)
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:180,y:box.y+200}]})
  for(let i=1;i<=8;i++)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:181,y:box.y+200-i*22}]})
  await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await expect.poll(()=>page.evaluate(()=>scrollY)).toBeGreaterThan(20)
  expect((await saved(page)).timeline.type).toBe('live')
})

test('global chart scrubs before release, hides future candles and events, and persists only after release',async({page})=>{
  const s=fixture();await seed(page,s);await backstage(page,'Replay');await page.waitForTimeout(450)
  await page.evaluate(()=>{(window as any).__writes=0;const original=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='replay:setup:v1')(window as any).__writes++;return original.call(this,k,v)}})
  const chart=page.locator('.scrub-chart'),box=(await chart.boundingBox())!,before=await saved(page)
  await page.mouse.move(box.x+box.width*.8,box.y+box.height*.65);await page.mouse.down();await page.mouse.move(box.x+box.width*.11,box.y+box.height*.65,{steps:20});await page.waitForTimeout(100)
  const t=Number(await page.getByRole('slider',{name:'Replay timeline',exact:true}).getAttribute('aria-valuenow')),a=s.assets.find(a=>a.id===s.settings.replayAssetId)!,time=a.candles[t].timestamp
  await expect(page.getByTestId('replay-price')).toHaveText(price(a.candles[t].close))
  expect(await chart.locator('[data-candle-time]').evaluateAll((nodes,T)=>nodes.every(n=>Number(n.getAttribute('data-candle-time'))<=T),time)).toBeTruthy()
  expect(await page.evaluate(()=>(window as any).__writes)).toBe(0);expect((await saved(page)).timeline).toEqual(before.timeline)
  await page.mouse.up();await expect.poll(async()=>(await saved(page)).timeline.type).toBe('replay')
  await page.getByRole('button',{name:'Back to app',exact:true}).click();await expect(page.locator('.global-replay-notice')).toContainText('Replay')
  await page.getByRole('button',{name:'Jump Live',exact:true}).click();await expect(page.locator('.global-replay-notice')).toHaveCount(0)
})

test('trader library, Weekly cards and profile preview save and reappear after reload',async({page})=>{
  await seed(page);await backstage(page,'Traders');await page.getByRole('button',{name:'Add trader',exact:true}).click();await page.getByLabel('Trader name',{exact:true}).fill('Copper Lantern');await page.getByLabel('Trader handle',{exact:true}).fill('copperlantern');await page.getByLabel('Trader PnL',{exact:true}).fill('1234.56');await page.getByLabel('Leaderboard rank').fill('1');await page.getByRole('switch',{name:'Verified',exact:true}).click();await page.getByRole('button',{name:'Save trader',exact:true}).click()
  await page.getByRole('tab',{name:'Weekly',exact:true}).click();await page.getByRole('button',{name:'Weekly mode',exact:true}).click();await page.getByRole('button',{name:/MANUAL/}).click();await page.getByRole('button',{name:'Weekly trader 1',exact:true}).click();await page.getByRole('button',{name:'Copper Lantern',exact:false}).click();await page.getByLabel('Weekly profit 1',{exact:true}).fill('456.78');await expect(page.locator('.weekly-card').first()).toContainText('Copper Lantern');await expect(page.locator('.weekly-card').first()).toContainText('$456.78')
  await page.getByRole('tab',{name:'Profile',exact:true}).click();await page.getByLabel('Display name',{exact:true}).fill('Evening Atlas');await expect(page.locator('.profile-live-preview')).toContainText('Evening Atlas');await page.waitForTimeout(650)
  await page.getByRole('button',{name:'Back to app',exact:true}).click();await expect(page.locator('.weekly-card').first()).toContainText('$456.78');await page.getByRole('button',{name:'Search',exact:true}).click();await expect(page.locator('.recent-card').filter({hasText:'Copper Lantern'})).toBeVisible();await expect(page.getByRole('tab',{name:'Clans',exact:true})).toHaveCount(0)
  await page.getByRole('button',{name:'People',exact:true}).click();await expect(page.locator('.leader-list article').first()).toContainText('Copper Lantern');await page.reload();await page.getByRole('button',{name:'Profile',exact:true}).click();await expect(page.locator('.profile-info h1')).toHaveText('Evening Atlas')
})

test('cash adjustments log exact amounts; import preview and cancellation are atomic',async({page})=>{
  await seed(page,makeInitialState());await backstage(page,'Funds');await page.getByLabel('Cash amount').fill('10.25');await page.getByRole('button',{name:'Update cash',exact:true}).click();await page.getByLabel('Cash amount').fill('0.15');await page.getByRole('button',{name:'Add cash',exact:true}).click();await page.getByRole('button',{name:'Subtract cash',exact:true}).click();await expect(page.locator('.overview-balance')).toContainText('$10.25');await expect(page.locator('.cash-log article')).toHaveCount(3);await page.waitForTimeout(450)
  await page.getByRole('tab',{name:'Data',exact:true}).click();const before=await saved(page)
  await page.getByLabel('Import setup',{exact:true}).setInputFiles({name:'candidate.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify({version:2,state:fixture()}))});await expect(page.getByRole('heading',{name:'Import preview'})).toBeVisible();expect(await saved(page)).toEqual(before);await page.getByRole('button',{name:'Cancel import'}).click();expect(await saved(page)).toEqual(before)
  await page.getByLabel('Import setup',{exact:true}).setInputFiles({name:'bad.json',mimeType:'application/json',buffer:Buffer.from('{"version":99}')});await expect(page.locator('.backstage-panel .form-error')).toBeVisible();expect(await saved(page)).toEqual(before)
  await page.getByRole('tab',{name:'Funds',exact:true}).click();await page.getByRole('button',{name:'Reset cash',exact:true}).click();await expect(page.locator('.overview-balance')).toContainText('$0');await expect(page.locator('.cash-log article')).toHaveCount(4)
})

test('position details and exports agree, event details work, Back dismisses sheets and final rows clear navigation',async({page})=>{
  const s=fixture(),v=selectPositionView(s,'position-completion-buy')!;await seed(page,s);await page.getByRole('button',{name:'Deposit',exact:true}).click();await expect(page.getByRole('heading',{name:'Deposit with'})).toBeVisible();await page.goBack();await expect(page.getByRole('heading',{name:'Deposit with'})).toHaveCount(0);await expect(page.locator('.home-screen')).toBeVisible()
  await page.getByRole('button',{name:'Open SI',exact:true}).click();await page.getByRole('button',{name:'Open position',exact:true}).click();await expect(page.locator('.position-sheet .position-value')).toContainText(money(Math.abs(v.metrics.pnlUsd)));await page.locator('.trade-event>button').first().click();await expect(page.getByText('Execution price',{exact:true})).toBeVisible()
  await page.getByRole('button',{name:'Share',exact:true}).click();await expect(page.locator('.position-share-card').first()).toContainText(money(Math.abs(v.metrics.pnlUsd)));await expect(page.locator('.share-stats').first()).toContainText(money(v.entryMC,true));await expect(page.locator('.share-stats').first()).toContainText(money(v.exitMC,true))
  const dimensions=[];for(const width of [360,390,430]){await page.setViewportSize({width,height:844});const box=(await page.locator('.export-renderer').boundingBox())!;dimensions.push([box.width,box.height])}expect(dimensions[0]).toEqual(dimensions[1]);expect(dimensions[1]).toEqual(dimensions[2]);await writeFile('qa/continuation/export-dimensions.json',JSON.stringify(dimensions))
  await page.getByRole('button',{name:'Back to profile',exact:true}).click();await page.getByRole('button',{name:'Home',exact:true}).click();await page.evaluate(()=>scrollTo(0,document.documentElement.scrollHeight));const last=(await page.locator('.token-row').last().boundingBox())!,nav=(await page.locator('.bottom-nav').boundingBox())!;expect(last.y+last.height).toBeLessThan(nav.y)
})
