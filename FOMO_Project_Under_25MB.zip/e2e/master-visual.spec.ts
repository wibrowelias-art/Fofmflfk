import { test, expect } from './fixtures'
import { makeFixtureState } from '../lib/store'
import { derivePositions } from '../lib/positions/calculations'
import { mkdir, writeFile } from 'node:fs/promises'
import type { Page } from '@playwright/test'
const sizes=[[360,800],[375,812],[390,844],[393,852],[412,915],[430,932]]
const folder=`qa/master-pass/${process.env.MASTER_PASS??'final'}`
test('master visual matrix and complete control center',async({page})=>{
  test.setTimeout(180000)
  await mkdir(folder,{recursive:true})
  const state=makeFixtureState();state.cash=100000
  for(const [index,a]of state.assets.slice(0,5).entries()){
    const c=a.candles,entry=Math.floor(c.length*.65),exit=Math.floor(c.length*.76),units=1000/c[entry].close
    for(let i=0;i<4;i++){const bar=c[entry+Math.floor(i/2)];state.tradeEvents.push({id:`visual-${a.id}-buy-${i}`,assetId:a.id,side:'buy',timestamp:bar.timestamp,priceUsd:bar.close,marketCapUsd:bar.marketCapUsd??null,units:units/4,usdValue:units/4*bar.close})}
    const bar=c[exit],sold=units*(index===2?1:.25);state.tradeEvents.push({id:`visual-${a.id}-sell`,assetId:a.id,side:'sell',timestamp:bar.timestamp,priceUsd:bar.close,marketCapUsd:bar.marketCapUsd??null,units:sold,usdValue:sold*bar.close})
  }
  state.positions=derivePositions(state.tradeEvents);state.settings.weeklyMode='auto'
  const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message))
  await page.addInitScript(s=>{if(!localStorage.getItem('replay:setup:v1'))localStorage.setItem('replay:setup:v1',JSON.stringify({version:2,state:s}))},state)
  const capture=async(name:string)=>{for(const [width,height]of sizes){await page.setViewportSize({width,height});await page.screenshot({path:`${folder}/${name}-${width}.png`,animations:'disabled'});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`${name} at ${width}`).toBeTruthy()}await page.setViewportSize({width:390,height:844})}
  await page.goto('/');await expect(page.locator('.token-row').first()).toBeVisible();await page.waitForTimeout(350);await capture('home')
  await page.getByRole('button',{name:'Search',exact:true}).click();await capture('search')
  await page.getByRole('button',{name:'People',exact:true}).click();await capture('people')
  await page.getByRole('button',{name:'Profile',exact:true}).click();await capture('profile')
  await page.locator('.position-row').first().click();await capture('open-position');await page.getByRole('button',{name:'Close sheet',exact:true}).click()
  await page.getByRole('tab',{name:'Closed',exact:true}).click();await page.locator('.position-row').first().click();await capture('closed-position');await page.getByRole('button',{name:'Share',exact:true}).click();await capture('position-share')
  await page.getByRole('button',{name:'Back to profile',exact:true}).click();await page.getByRole('tab',{name:'Closed',exact:true}).click();await page.locator('.position-row').first().click();await page.getByRole('button',{name:/View Fumble/}).click();await capture('fumble')
  await page.getByRole('button',{name:'Back to profile',exact:true}).click();await page.getByRole('button',{name:'Add cash',exact:true}).click();await capture('deposit');await page.getByRole('button',{name:'Close sheet',exact:true}).click()
  await page.getByRole('button',{name:'Home',exact:true}).click();await page.getByRole('button',{name:'Open SI',exact:true}).click();await capture('token')
  await page.getByRole('button',{name:'Back',exact:true}).click();await page.getByRole('button',{name:'Profile',exact:true}).click();await page.getByRole('button',{name:'Profile settings',exact:true}).click()
  for(const tab of ['Overview','Profile','Funds','Tokens','Traders','Weekly','Positions','Replay','Charts','Social','Templates','Data','Appearance','Development']){await page.getByRole('tab',{name:tab,exact:true}).click();await capture(`backstage-${tab.toLowerCase()}`)}
  await writeFile(`${folder}/audit.json`,JSON.stringify({viewports:sizes,screens:24,errors,capturedAt:new Date().toISOString()},null,2));expect(errors).toEqual([])
})
