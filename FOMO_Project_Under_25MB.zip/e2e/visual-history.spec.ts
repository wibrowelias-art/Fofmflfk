import {test,expect} from './fixtures'
import {makeFixtureState} from '../lib/store'
import type {Page} from '@playwright/test'
const sizes=[[375,812],[390,844],[393,852],[412,915],[430,932]]
const capture=async(page:Page,name:string)=>{for(const [width,height]of sizes){await page.setViewportSize({width,height});await expect.poll(()=>page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();await page.screenshot({animations:'disabled',path:`qa/final-${name}-${width}.png`})}await page.setViewportSize({width:390,height:844})}
test('all major screens and Backstage sections fit the mobile viewport matrix',async({page})=>{
 test.setTimeout(120000)
 const state=makeFixtureState();await page.addInitScript(s=>{if(!localStorage.getItem('replay:setup:v1'))localStorage.setItem('replay:setup:v1',JSON.stringify({version:2,state:s}))},state)
 await page.goto('/');await expect(page.getByRole('button',{name:'Open PAID',exact:true})).toBeVisible();await capture(page,'home')
 for(const [label,name]of [['Search','search'],['People','leaderboard'],['Replay hub','hub'],['Profile','profile']]){await page.getByRole('button',{name:label,exact:true}).click();await capture(page,name)}
 await page.getByRole('button',{name:'Profile settings'}).click()
 for(const tab of ['Profile','Funds','Tokens','Positions','Replay','Data','Development']){await page.getByRole('tab',{name:tab,exact:true}).click();await capture(page,`backstage-${tab.toLowerCase()}`)}
 await page.getByRole('button',{name:'Back to app'}).click();await page.getByRole('tab',{name:'Perps New',exact:true}).click();await capture(page,'perps');await page.getByRole('tab',{name:'Tokens',exact:true}).click();await page.getByRole('button',{name:'Open PAID',exact:true}).click();await capture(page,'token')
 await page.getByRole('button',{name:'Back',exact:true}).click();await page.getByRole('button',{name:'Portfolio balance. Hold to open Backstage',exact:true}).press('Enter');await page.getByRole('tab',{name:'Replay',exact:true}).click();await capture(page,'replay-controller')
})
test('older history UI sends cursor, merges pages, and reports exhaustion',async({page})=>{
 const state=makeFixtureState(),asset={...state.assets[0],source:'remote' as const,candles:[],id:'history-remote',chain:'Base',contractAddress:'0x1111111111111111111111111111111111111111'},rows=state.assets[0].candles.slice(0,10),cursors:string[]=[]
 state.assets=[asset];state.settings.replayAssetId=asset.id;state.watchlist=[];state.searchRecents=[];state.weeklyTopTrades=[];state.holders=[]
 await page.addInitScript(s=>localStorage.setItem('replay:setup:v1',JSON.stringify({version:2,state:s})),state)
 await page.route('**/api/market/**',route=>{const u=new URL(route.request().url()),before=u.searchParams.get('before');if(u.pathname.endsWith('candles')){if(before)cursors.push(before);return route.fulfill({json:{data:before?(Number(before)<rows[0].timestamp?[]:rows.slice(0,5)):rows.slice(5)}})}return route.fulfill({json:{data:u.pathname.endsWith('holders')?{items:[],cursor:null,updatedAt:Date.now()}:asset}})})
 await page.goto('/');await page.getByRole('button',{name:`Open ${asset.symbol}`,exact:true}).click();await page.getByRole('button',{name:'Back',exact:true}).click();await page.getByRole('button',{name:'Portfolio balance. Hold to open Backstage',exact:true}).press('Enter');await page.getByRole('tab',{name:'Replay',exact:true}).click();await page.getByRole('button',{name:'Load older history'}).click();await expect(page.getByText('10 candles cached')).toBeVisible();expect(cursors[0]).toBe(String(rows[5].timestamp-1));await page.getByRole('button',{name:'Load older history'}).click();await expect(page.getByText('No earlier history available')).toBeVisible()
})
test('server-rendered splash uses the brand mark',async({browser})=>{const context=await browser.newContext({javaScriptEnabled:false,viewport:{width:390,height:844}});const page=await context.newPage();await page.goto('http://localhost:3000');await expect(page.locator('.splash-mark')).toBeVisible();await page.screenshot({animations:'disabled',path:'qa/final-splash-390.png'});await context.close()})

