import {test,expect} from './fixtures'
import {makeFixtureState} from '../lib/store'
import {writeFile} from 'node:fs/promises'

test('manual token artwork persists, failure falls back cleanly, and retry recovers',async({page})=>{
  const state=makeFixtureState();await page.addInitScript(s=>{if(!localStorage.getItem('replay:setup:v1'))localStorage.setItem('replay:setup:v1',JSON.stringify({version:2,state:s}))},state)
  await page.route('https://artwork.example/**',r=>r.fulfill({status:404,body:''}))
  await page.goto('/');await page.getByRole('button',{name:'Profile',exact:true}).click();await page.getByRole('button',{name:'Profile settings'}).click();await page.getByRole('tab',{name:'Tokens',exact:true}).click()
  const token=page.locator('.managed-token').first();await token.getByRole('button',{name:'Edit artwork',exact:true}).click();await token.locator('summary').filter({hasText:'Artwork controls'}).click();await token.getByLabel('Artwork URL').fill('https://artwork.example/missing.png');await token.getByRole('button',{name:'Apply artwork URL'}).click()
  await expect(token.locator('.avatar img').first()).toHaveAttribute('src',state.assets[0].iconUrl);await expect(token.locator('.avatar img').first()).toBeVisible();await page.waitForTimeout(450);await page.reload()
  const manual=await page.evaluate(()=>JSON.parse(localStorage.getItem('replay:setup:v1')!).state.assets[0].manualImageUrl);expect(manual).toBe('https://artwork.example/missing.png')
  await page.unroute('https://artwork.example/**');await page.route('https://artwork.example/**',r=>r.fulfill({contentType:'image/svg+xml',body:'<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="64" height="64" fill="#7a51ec"/></svg>'}))
  await page.getByRole('button',{name:'Profile',exact:true}).click();await page.getByRole('button',{name:'Profile settings'}).click();await page.getByRole('tab',{name:'Tokens',exact:true}).click();await token.getByRole('button',{name:'Edit artwork',exact:true}).click();await token.getByRole('button',{name:'Retry artwork'}).click();await expect(token.locator('.avatar img').first()).toHaveAttribute('src',manual);await expect(token.locator('.avatar img').first()).toBeVisible()
})

test('bounded swipe momentum can be interrupted; sheet drag dismisses; chart frame timing is recorded',async({page})=>{
  const s=makeFixtureState();s.settings.appearance={animations:true};await page.addInitScript(state=>localStorage.setItem('replay:setup:v1',JSON.stringify({version:2,state})),s);await page.goto('/');await page.getByRole('button',{name:'Open SI',exact:true}).click()
  await page.evaluate(()=>{const times:number[]=[];(window as any).__chartFrames=times;let last=performance.now();const frame=(now:number)=>{times.push(now-last);last=now;if(times.length<90)requestAnimationFrame(frame)};requestAnimationFrame(frame)})
  const chart=page.locator('.pan-chart'),box=(await chart.boundingBox())!
  await page.mouse.move(box.x+60,box.y+box.height*.7);await page.mouse.down();await page.mouse.move(box.x+190,box.y+box.height*.7,{steps:10});await page.mouse.up();await page.waitForTimeout(260)
  const first=await chart.getAttribute('data-domain-last');await page.waitForTimeout(260);expect(await chart.getAttribute('data-domain-last')).toBe(first)
  await chart.press('End');await expect(page.locator('.token-screen')).toHaveAttribute('data-chart-context','live');await page.mouse.move(box.x+60,box.y+box.height*.7);await page.mouse.down();await page.mouse.move(box.x+190,box.y+box.height*.7,{steps:8});await page.mouse.up();await page.mouse.down();await page.waitForTimeout(280);const held=await chart.getAttribute('data-domain-last');await page.waitForTimeout(100);expect(await chart.getAttribute('data-domain-last')).toBe(held);await page.mouse.up()
  await page.waitForTimeout(350);const times=await page.evaluate(()=>(window as any).__chartFrames as number[]);const sorted=times.slice().sort((a,b)=>a-b);await writeFile('qa/continuation/pan-performance.json',JSON.stringify({frames:times.length,medianMs:sorted[Math.floor(sorted.length/2)],p95Ms:sorted[Math.floor(sorted.length*.95)],maxMs:Math.max(...times),note:'Chromium mobile emulation, development server; timing is diagnostic, not a hardware-independent benchmark.'},null,2))
  await page.getByRole('button',{name:'Back',exact:true}).click();await page.getByRole('button',{name:'Deposit',exact:true}).click();const handle=(await page.getByRole('button',{name:'Dismiss sheet'}).boundingBox())!;await page.mouse.move(handle.x+30,handle.y+10);await page.mouse.down();await page.mouse.move(handle.x+30,handle.y+120,{steps:10});await page.mouse.up();await expect(page.getByRole('dialog',{name:'Deposit with'})).toHaveCount(0)
})
