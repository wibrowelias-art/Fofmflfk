import type { AppState, AppearanceSettings, ChartSettings } from './store-types'
import type { Asset } from './market/types'

export const chartDefaults: ChartSettings = { grid: 'normal', markers: true, compression: true, priceLine: true, crosshair: true, animation: true, density: 'comfortable', marketCapLabels: false, eventCount: false }
export const appearanceDefaults: AppearanceSettings = { scale: 1, gutter: 16, navOffset: 8, chartHeight: 330, rowDensity: 'comfortable', animations: true, reducedMotion: false }
export const avatarGallery = ['/art/profile.svg', ...Array.from({ length: 4 }, (_, i) => `/art/trader-${i}.svg`)]
const projectSymbols = new Set(['paid', 'si', 'moin', 'vault', 'nosh', 'martians', 'zc', 'cyberleek', 'cashcat'])
export function imageSources(asset: Asset) {
  // Symbol artwork belongs to explicit local fixtures, never an unrelated real contract.
  const local = asset.source === 'fixture' && projectSymbols.has(asset.symbol.toLowerCase()) ? `/art/${asset.symbol.toLowerCase()}.svg` : ''
  return [...new Set([asset.manualImageUrl, asset.iconUrl, asset.metadataImageUrl, local].filter((v): v is string => !!v))]
}
export function validImage(value: string) { return !value || /^https:\/\/[^\s]+$/i.test(value) || /^\/art\/[\w-]+\.svg$/.test(value) || /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(value) }
export function validateCustomization(state: AppState) {
  const fail = () => { throw new Error('Invalid profile, community or appearance settings.') }
  const bool = (v: unknown) => v === undefined || typeof v === 'boolean'
  const finite = (v: unknown) => v === undefined || (typeof v === 'number' && Number.isFinite(v))
  const range = (v: unknown, min: number, max: number) => v === undefined || (typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max)
  if (!bool(state.profile.verified) || !bool(state.profile.manualStats) || (state.profile.cover !== undefined && (typeof state.profile.cover !== 'string' || !validImage(state.profile.cover)))) fail()
  if (new Set(state.traders.map(t => t.id)).size !== state.traders.length) fail()
  for (const t of state.traders) {
    if (![t.id,t.displayName,t.handle,t.avatar].every(v => typeof v === 'string') || !t.id || !t.displayName.trim() || !t.handle.trim() || !Number.isInteger(t.followers) || t.followers < 0 || typeof t.following !== 'boolean' || !Number.isFinite(t.pnlUsd) || !finite(t.pnlPct) || !range(t.rank,1,100000) || !range(t.followingCount,0,1e10) || ![t.verified,t.favorite,t.enabled].every(bool) || (t.bio !== undefined && typeof t.bio !== 'string')) fail()
    if (t.associatedAssets !== undefined && (!Array.isArray(t.associatedAssets) || t.associatedAssets.some(id => !state.assets.some(a => a.id === id)))) fail()
  }
  for (const a of state.assets) if ([a.metadataImageUrl,a.manualImageUrl].some(v => v !== undefined && (typeof v !== 'string' || !validImage(v))) || !range(a.imageRevision,0,1e10)) fail()
  if (state.tradeEvents.some(e => e.note !== undefined && (typeof e.note !== 'string' || e.note.length > 1000))) fail()
  const crop=state.profile.avatarPosition
  if (!range(state.profile.coverPosition,0,100)) fail()
  if (state.cashAdjustments !== undefined && (!Array.isArray(state.cashAdjustments) || state.cashAdjustments.some(a=>!a.id||!['set','add','subtract','reset'].includes(a.mode)||![a.recordedAt,a.replayTimestamp,a.before,a.after].every(Number.isFinite)||a.before<0||a.after<0))) fail()
  if(crop && (!range(crop.x,0,100)||!range(crop.y,0,100)||!range(crop.zoom,1,3))) fail()
  if (state.weeklyTopTrades.some(t => !bool(t.enabled)||!finite(t.pnlPct)) || new Set(state.weeklyTopTrades.map(t => t.id)).size !== state.weeklyTopTrades.length) fail()
  const s = state.settings, c = s.chart, a = s.appearance
  if (s.weeklyMode !== undefined && !['auto','manual'].includes(s.weeklyMode)) fail()
  if (s.social && (!bool(s.social.showClans) || !bool(s.social.showFollowers))) fail()
  if (c && ((c.grid !== undefined && !['off','sparse','normal'].includes(c.grid)) || (c.density !== undefined && !['comfortable','dense'].includes(c.density)) || ![c.markers,c.compression,c.priceLine,c.crosshair,c.animation,c.marketCapLabels,c.eventCount].every(bool))) fail()
  if (a && (!range(a.scale,.85,1.2) || !range(a.gutter,12,24) || !range(a.navOffset,4,24) || !range(a.chartHeight,260,420) || !bool(a.animations) || !bool(a.reducedMotion) || (a.rowDensity !== undefined && !['comfortable','compact'].includes(a.rowDensity)))) fail()
}
