import type { Asset, Candle, ChartTimeframe, MarketQuote } from './types'
import type { Timeline, QuoteOverride } from '@/lib/store-types'

const WINDOW_MS: Record<ChartTimeframe, number> = {
  LIVE: 15 * 60 * 1000,
  '1H': 60 * 60 * 1000,
  '4H': 4 * 60 * 60 * 1000,
  '1D': 24 * 60 * 60 * 1000,
  '7D': 7 * 24 * 60 * 60 * 1000,
  ALL: Number.POSITIVE_INFINITY,
}

export function candleAtOrBefore(candles: Candle[], timestamp: number): Candle | undefined {
  let lo = 0
  let hi = candles.length - 1
  let best = -1
  while (lo <= hi) {
    const mid = (lo + hi) >> 1
    if (candles[mid].timestamp <= timestamp) {
      best = mid
      lo = mid + 1
    } else hi = mid - 1
  }
  return best >= 0 ? candles[best] : undefined
}

export function quoteAt(asset: Asset, timeline: Timeline, override?: QuoteOverride): MarketQuote {
  if (timeline.type === 'replay') override = undefined
  if (timeline.type === 'live' && asset.source === 'remote') return { assetId: asset.id, timestamp: asset.lastQuoteUpdate ?? Date.now(), priceUsd: override?.priceUsd ?? asset.priceUsd ?? 0, unavailable: (override?.priceUsd??asset.priceUsd) === null, marketCapUsd: override?.marketCapUsd ?? asset.marketCapUsd, priceChange24hPct: asset.priceChange24hPct }
  const timestamp = timeline.type === 'replay'
    ? timeline.timestamp
    : asset.candles.at(-1)?.timestamp ?? Date.now()
  const candle = candleAtOrBefore(asset.candles, timestamp)
  const priceUsd = override?.priceUsd ?? candle?.close ?? 0
  const prior = candleAtOrBefore(asset.candles, timestamp - 86_400_000)
  return {
    assetId: asset.id,
    unavailable:asset.source==='remote'&&!candle&&override?.priceUsd===undefined,
    timestamp,
    priceUsd,
    marketCapUsd: override?.marketCapUsd ?? (asset.source === 'remote' ? candle?.marketCapUsd ?? null : asset.supply && priceUsd ? asset.supply * priceUsd : candle?.marketCapUsd ?? null),
    priceChange24hPct: prior ? (priceUsd / prior.close - 1) * 100 : null,
  }
}

export function visibleCandles(candles: Candle[], timeframe: ChartTimeframe, before = Number.POSITIVE_INFINITY): Candle[] {
  const end = Math.min(before, candles.at(-1)?.timestamp ?? before)
  const inWindow = candles.slice(lowerBound(candles, end - WINDOW_MS[timeframe]), lowerBound(candles, end + 1))
  const bucket = Math.max(1, Math.ceil(inWindow.length / (timeframe === 'LIVE' ? 80 : timeframe === 'ALL' ? 135 : 150)))
  const result: Candle[] = []
  for (let i = 0; i < inWindow.length; i += bucket) {
    const part = inWindow.slice(i, i + bucket)
    const first = part[0]
    const last = part.at(-1)!
    result.push({
      startTimestamp: first.startTimestamp ?? first.timestamp,
      timestamp: last.timestamp,
      open: first.open,
      high: Math.max(...part.map(c => c.high)),
      low: Math.min(...part.map(c => c.low)),
      close: last.close,
      marketCapUsd: last.marketCapUsd,
      volume: part.reduce((sum, c) => sum + (c.volume ?? 0), 0),
    })
  }
  return result
}

export function lowerBound(candles: Candle[], timestamp: number) {
  let lo=0, hi=candles.length
  while(lo<hi) { const mid=(lo+hi)>>1; if(candles[mid].timestamp<timestamp) lo=mid+1; else hi=mid }
  return lo
}
export function nearestCandle(candles: Candle[], timestamp: number): Candle | undefined {
  const i=lowerBound(candles,timestamp), a=candles[i-1], b=candles[i]
  return !a ? b : !b ? a : timestamp-a.timestamp <= b.timestamp-timestamp ? a : b
}
export function stepReplay(candles: Candle[], timestamp: number, speed: number) {
  if (!candles.length) return { timestamp, speed: 0 }
  const candle=nearestCandle(candles,timestamp)!
  const index=lowerBound(candles,candle.timestamp)
  const next=Math.max(0,Math.min(candles.length-1,index+speed))
  return { timestamp:candles[next].timestamp, speed:next===0 || next===candles.length-1 ? 0 : speed }
}
