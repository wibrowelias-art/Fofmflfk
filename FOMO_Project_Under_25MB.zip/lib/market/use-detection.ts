'use client'
import { useEffect, useState } from 'react'
import { isContract } from './normalize'
import type { Asset } from './types'
import { marketRequest } from './providers/router'
export function useDetection(address: string, chain = 'Auto Detect') {
  const [result,setResult]=useState<Asset | null>(null)
  const [error,setError]=useState('')
  const [busy,setBusy]=useState(false)
  useEffect(()=>{
    const controller=new AbortController()
    setResult(null); setError(''); setBusy(!!address.trim())
    if (!address.trim()) return
    if (!isContract(address.trim())) { setBusy(false);setError('Enter a valid EVM contract or Solana mint.');return }
    const timer=setTimeout(()=>{
      marketRequest<Asset>('resolve',{address:address.trim(),chain},controller.signal).then(a=>{if(!controller.signal.aborted)setResult(a)}).catch(e=>{if(!controller.signal.aborted)setError(e instanceof Error?e.message:'Detection failed')}).finally(()=>{if(!controller.signal.aborted)setBusy(false)})
    },400)
    return ()=>{clearTimeout(timer);controller.abort()}
  },[address,chain])
  return { result,error,busy }
}
