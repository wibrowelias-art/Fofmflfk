import { readJson, fetchedAt } from '../cache'
import { record, string, number, safeUrl, emptyAsset, isContract } from '../normalize'
import type { Asset } from '../types'

export interface Discovery { assets: Asset[]; source: string; updatedAt: number }
const discovered=new Map<string,Asset>()
/** The public pool ranking belongs to GeckoTerminal, not Fomo. */
export function normalizeDiscovery(value: unknown, updatedAt: number): Discovery {
  const body = record(value)
  if (!Array.isArray(body.data) || !Array.isArray(body.included)) throw new Error('Malformed discovery response')
  const included = new Map(body.included.map(v => { const r = record(v); return [string(r.id), record(r.attributes)] }))
  const supported: Record<string,string> = { solana:'solana', eth:'ethereum', base:'base', bsc:'bsc', robinhood:'robinhood' }
  const assets: Asset[] = [], seen = new Set<string>()
  for (const row of body.data) {
    const pool = record(row), a = record(pool.attributes), rel = record(pool.relationships)
    const network = supported[string(record(record(rel.network).data).id)]
    const token = included.get(string(record(record(rel.base_token).data).id))
    if (!network || !token || !isContract(string(token.address)) || !string(token.symbol) || !string(token.name)) continue
    const asset = emptyAsset(string(token.address), network), usd = number(a.base_token_price_usd)
    if (seen.has(asset.id) || usd === null || usd <= 0) continue
    seen.add(asset.id)
    assets.push({ ...asset, name:string(token.name), symbol:string(token.symbol), iconUrl:safeUrl(token.image_url) ?? '', decimals:number(token.decimals) ?? undefined,
      poolAddress:string(a.address), provider:'GeckoTerminal', providerAssetId:string(pool.id), priceUsd:usd, priceUnavailable:false,
      marketCapUsd:number(a.market_cap_usd), fdvUsd:number(a.fdv_usd), liquidityUsd:number(a.reserve_in_usd), volume24hUsd:number(record(a.volume_usd).h24),
      priceChange24hPct:number(record(a.price_change_percentage).h24), lastMetadataUpdate:updatedAt, lastQuoteUpdate:updatedAt })
  }
  if (!assets.length) throw new Error('No supported trending market tokens are currently available')
  return { assets, source:'GeckoTerminal · trending market pools', updatedAt }
}
export async function discoverTrending() {
  const value = await readJson('https://api.geckoterminal.com/api/v2/networks/trending_pools?include=base_token,quote_token', 60_000)
  const result=normalizeDiscovery(value, fetchedAt(value))
  for(const asset of result.assets)discovered.set(asset.id,asset)
  for(const [id,asset] of discovered)if(Date.now()-(asset.lastQuoteUpdate??0)>300000)discovered.delete(id)
  return result
}
export async function discoveredAsset(address:string,chain:string) {
  const matching=()=>[...discovered.values()].find(a=>(a.chain==='Solana'?a.contractAddress===address:a.contractAddress.toLowerCase()===address.toLowerCase())&&(chain==='Auto Detect'||a.chain===chain))
  let asset=matching()
  if(asset&&Date.now()-(asset.lastQuoteUpdate??0)>=60000){await discoverTrending();asset=matching()}
  return asset&&Date.now()-(asset.lastQuoteUpdate??0)<60000?asset:undefined
}
