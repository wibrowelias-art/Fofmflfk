import { readJson } from '../cache'
import { normalizeOhlcv } from '../normalize'
import type { Asset, ChartTimeframe } from '../types'
export async function historicalCandles(asset: Asset, frame: ChartTimeframe = 'ALL', before?: number) {
  const network: Record<string,string> = { Solana:'solana', Ethereum:'eth', Base:'base', 'BNB Chain':'bsc', 'Robinhood Chain':'robinhood' }
  if (!asset.poolAddress || !network[asset.chain]) return []
  const timeframe = frame === 'ALL' || frame === '7D' ? 'hour' : 'minute'
  const params = new URLSearchParams({ aggregate: timeframe === 'hour' ? '1' : '1', limit:'1000', currency:'usd', token:asset.contractAddress })
  if (before) params.set('before_timestamp', String(Math.floor(before/1000)))
  return normalizeOhlcv(await readJson(`https://api.geckoterminal.com/api/v2/networks/${network[asset.chain]}/pools/${encodeURIComponent(asset.poolAddress)}/ohlcv/${timeframe}?${params}`, 300000))
}
