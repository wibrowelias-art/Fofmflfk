import { readJson, MarketError, fetchedAt } from '../cache'
import { normalizePons, normalizeHolders, normalizeBlockscoutHolders, record, number } from '../normalize'
import { resolveDex } from './dex'
const base = 'https://api.ponsportal.fun'
async function optional(url: string, ttl: number) { try { return await readJson(url, ttl) } catch (e) { if (e instanceof MarketError && e.code === 'not-found') return null; throw e } }
export async function resolvePons(address: string) {
  const explorer = process.env.BLOCKSCOUT_API_KEY ? `https://api.blockscout.com/4663/api/v2/tokens/${address}?apikey=${encodeURIComponent(process.env.BLOCKSCOUT_API_KEY)}` : `https://robinhoodchain.blockscout.com/api/v2/tokens/${address}`
  const metadata = await readJson(explorer, 30000)
  // Non-factory ERC20s still resolve through Blockscout. Pons budgets are far
  // lower than DEX budgets, so metadata is cached for fifteen minutes.
  const token = await optional(`${base}/token/${address}`, 900000).catch(() => null)
  const price = token ? await optional(`${base}/token/${address}/price`, 60000).catch(() => null) : null
  const eth = price ? (await resolveDex('0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2', 'Ethereum').catch(() => []))[0]?.priceUsd ?? null : null
  return {...normalizePons(address, metadata, token, price, eth),lastMetadataUpdate:fetchedAt(metadata),lastQuoteUpdate:fetchedAt(price??metadata)}
}
export async function ponsHolders(address: string, id: string, cursor: string) {
  const source = new URLSearchParams(cursor), params = new URLSearchParams()
  for (const key of ['value','address_hash','items_count']) { const v = source.get(key); if (v && /^[\da-fx]+$/i.test(v)) params.set(key,v) }
  try {
    const data=await readJson(`${base}/token/${address}/holders?${params}`, 120000)
    return {...normalizeHolders(data,id),updatedAt:fetchedAt(data)}
  } catch(error) {
    // The public Pons route stays primary. Blockscout's documented PRO API
    // provides a read-only fallback when its server credential is configured.
    const apiKey=process.env.BLOCKSCOUT_API_KEY
    if(!apiKey)throw error
    const root=`https://api.blockscout.com/4663/api/v2/tokens/${address}`
    const auth=new URLSearchParams({apikey:apiKey})
    const metadata=await readJson(`${root}?${auth}`,30000)
    params.set('apikey',apiKey)
    const data=await readJson(`${root}/holders?${params}`,120000)
    return {...normalizeBlockscoutHolders(data,id,number(record(metadata).decimals)??Number.NaN),updatedAt:fetchedAt(data)}
  }
}
