import { readJson, fetchedAt } from '../cache'
import { normalizeDex } from '../normalize'
export async function resolveDex(address: string, chain?: string) {
  const data = await readJson(`https://api.dexscreener.com/latest/dex/search?q=${encodeURIComponent(address)}`, 10000)
  return normalizeDex(data, address, chain).map(asset=>({...asset,lastMetadataUpdate:fetchedAt(data),lastQuoteUpdate:fetchedAt(data)}))
}
