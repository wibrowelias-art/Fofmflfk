import { MarketError } from '../cache'
import { isContract, chains } from '../normalize'
import { resolveDex } from './dex'
import { resolvePons } from './pons'
import { discoveredAsset } from './discovery'
export async function resolveRemote(address: string, chain = 'Auto Detect') {
  if (!isContract(address)) throw new MarketError('invalid-address','Enter a valid EVM contract or Solana mint.',400)
  if (chain !== 'Auto Detect' && !Object.values(chains).includes(chain)) throw new MarketError('unsupported-network','Unsupported network.',400)
  const evm = address.startsWith('0x')
  const probes = await Promise.allSettled([
    resolveDex(address,chain === 'Auto Detect' ? undefined : chain),
    evm && (chain === 'Auto Detect' || chain === 'Robinhood Chain') ? resolvePons(address).then(a => [a]) : Promise.resolve([]),
  ])
  const found = probes.flatMap(r => r.status === 'fulfilled' ? r.value : [])
  if (found.length) {
    const dex=found.find(a=>a.chain==='Robinhood Chain' && a.provider==='DEX Screener')
    const metadata=found.find(a=>a.chainId==='4663' && a.provider!=='DEX Screener')
    if(dex && metadata) return {...metadata,...dex,chainId:'4663',holders:metadata.holders,supply:metadata.supply,decimals:metadata.decimals,metadataImageUrl:metadata.iconUrl,provider:`DEX Screener + ${metadata.provider}`}
    const asset=found[0]
    if(asset.priceUsd===null){const discovery=await discoveredAsset(address,chain).catch(()=>undefined);if(discovery)return {...asset,priceUsd:discovery.priceUsd,priceUnavailable:false,poolAddress:discovery.poolAddress,provider:`${asset.provider} + GeckoTerminal`,lastQuoteUpdate:discovery.lastQuoteUpdate}}
    return asset
  }
  const discovery=await discoveredAsset(address,chain).catch(()=>undefined)
  if(discovery)return discovery
  const failure = probes.find(r => r.status === 'rejected' && (!(r.reason instanceof MarketError) || r.reason.code !== 'not-found'))
  if (failure?.status === 'rejected') throw failure.reason
  throw new MarketError('not-found','No token found on the supported networks.',404)
}
