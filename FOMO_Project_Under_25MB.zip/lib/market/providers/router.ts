import type { Asset, Candle, ChartTimeframe, HolderPage } from '../types'
import { FixtureMarketDataProvider } from '../fixture-provider'
import { cacheGet, cachePut } from '@/lib/storage'
export async function marketRequest<T>(kind: string, params: Record<string,string>, signal?: AbortSignal): Promise<T> {
  const response = await fetch(`/api/market/${kind}?${new URLSearchParams(params)}`,{ signal })
  const result = await response.json()
  if (!response.ok || result.error) throw new Error(result.error?.message ?? 'Market data unavailable')
  return result.data as T
}
export class ProviderRouter extends FixtureMarketDataProvider {
  constructor(private allAssets: Asset[], holders: ConstructorParameters<typeof FixtureMarketDataProvider>[1]) { super(allAssets,holders) }
  async resolveToken(chain: string, address: string, signal?: AbortSignal) {
    if (address.startsWith('replay:')) return super.resolveToken(chain,address)
    return marketRequest<Asset>('resolve',{ address,chain },signal)
  }
  async getHolderPage(asset: Asset,cursor = '',signal?: AbortSignal): Promise<HolderPage> {
    if (asset.source !== 'remote') return { items:await super.getHolders(asset.id), cursor:null, updatedAt:Date.now() }
    const key=`holders:${asset.id}:${cursor}`
    const cached=await cacheGet<HolderPage>(key).catch(()=>undefined)
    if (cached && Date.now()-cached.updatedAt<120000) return cached
    const page=await marketRequest<HolderPage>('holders',{address:asset.contractAddress,chain:asset.chain,cursor},signal)
    cachePut(key,page).catch(()=>{})
    return page
  }
  async getCandles(id: string, timeframe: ChartTimeframe, before?: number, signal?: AbortSignal) {
    const asset=this.allAssets.find(a=>a.id===id)
    if (!asset || asset.source !== 'remote') return super.getCandles(id,timeframe,before)
    if(!before&&(timeframe==='ALL'||timeframe==='7D')&&asset.candles.length&&Date.now()-asset.candles.at(-1)!.timestamp<7200000)return asset.candles
    const key=`history-page:${id}:${timeframe}:${before ?? 'latest'}`
    const cached=await cacheGet<{candles:Candle[];at:number}>(key).catch(()=>undefined)
    if(cached && Date.now()-cached.at < (before ? 86400000 : 300000)) return cached.candles
    const candles=await marketRequest<Candle[]>('candles',{address:asset.contractAddress,chain:asset.chain,timeframe,...(before ? {before:String(before)} : {})},signal)
    cachePut(key,{candles,at:Date.now()}).catch(()=>{})
    return candles
  }
}
