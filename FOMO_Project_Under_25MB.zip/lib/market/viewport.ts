import type { Candle, ChartTimeframe } from './types'
import { lowerBound } from './timeline'
const windows:Record<Exclude<ChartTimeframe,'ALL'>,number>={LIVE:900000,'1H':3600000,'4H':14400000,'1D':86400000,'7D':604800000}
export function viewportCapacity(candles:Candle[],frame:ChartTimeframe,dense=false) {
  if(frame==='ALL')return candles.length
  const end=candles.at(-1)?.timestamp??0
  return Math.min(candles.length,Math.max(12,candles.length-lowerBound(candles,end-windows[frame])))
}
/** Local chart camera. It contains no portfolio/global replay state. */
export function tokenChartViewport(candles:Candle[],frame:ChartTimeframe,offset:number,dense=false) {
  const count=viewportCapacity(candles,frame,dense),maxOffset=Math.max(0,candles.length-Math.min(count,12))
  const bounded=Math.max(0,Math.min(maxOffset,offset)),right=Math.max(0,candles.length-1-bounded),left=right-Math.max(1,count-1)
  const interval=candles.length>1?(candles.at(-1)!.timestamp-candles[0].timestamp)/(candles.length-1):60000
  const at=(index:number)=>{const i=Math.floor(index),a=candles[Math.max(0,i)];if(!a)return 0;if(index<0)return a.timestamp+index*interval;const b=candles[Math.min(candles.length-1,i+1)];return a.timestamp+(b.timestamp-a.timestamp)*(index-i)}
  const lastIndex=Math.floor(right),selected=candles[lastIndex],source=candles.slice(Math.max(0,Math.floor(left)-1),lastIndex+1)
  const bucket=Math.max(1,Math.ceil(count/(dense?180:120))),bars:Candle[]=[]
  // Fixed bucket membership prevents bodies changing identity at every pixel.
  const start=Math.max(0,Math.floor(Math.max(0,left)/bucket)*bucket)
  for(let i=start;i<=lastIndex;i+=bucket){const part=candles.slice(i,Math.min(i+bucket,lastIndex+1));if(!part.length)continue;const last=part.at(-1)!;bars.push({...last,startTimestamp:part[0].timestamp,open:part[0].open,high:Math.max(...part.map(c=>c.high)),low:Math.min(...part.map(c=>c.low)),volume:part.reduce((n,c)=>n+(c.volume??0),0)})}
  return {candles:bucket===1?source:bars,selected,domain:{first:at(left),last:at(right)},live:bounded===0,offset:bounded,maxOffset,count}
}
