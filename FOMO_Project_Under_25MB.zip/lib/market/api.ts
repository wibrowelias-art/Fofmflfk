import { resolveRemote } from './providers/server-router'
import { historicalCandles } from './providers/historical'
import { ponsHolders } from './providers/pons'
import { MarketError } from './cache'
import type { ChartTimeframe } from './types'
import { discoverTrending } from './providers/discovery'
export async function marketRoute(request: Request, kind: string) {
  try {
    const params = new URL(request.url).searchParams, address = (params.get('address') ?? '').trim(), chain = params.get('chain') ?? 'Auto Detect'
    if (kind === 'search' && params.get('discovery') === 'trending') return Response.json({ data: await discoverTrending() }, { headers: { 'Cache-Control':'no-store' } })
    const asset = await resolveRemote(address, chain)
    let data: unknown = asset
    if (kind === 'candles') {
      const frame = params.get('timeframe') ?? 'ALL'
      if (!['LIVE','1H','4H','1D','7D','ALL'].includes(frame)) throw new MarketError('invalid-timeframe','Invalid timeframe',400)
      const before = params.has('before') ? Number(params.get('before')) : undefined
      if (before !== undefined && (!Number.isSafeInteger(before) || before <= 0)) throw new MarketError('invalid-cursor','Invalid history cursor',400)
      const pool = params.get('pool')
      if (pool && !/^0x(?:[\da-f]{40}|[\da-f]{64})$/i.test(pool) && !/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(pool)) throw new MarketError('invalid-pool','Invalid pool address',400)
      data = await historicalCandles(pool ? { ...asset, poolAddress: pool } : asset, frame as ChartTimeframe, before)
    }
    if (kind === 'holders') data = asset.chain === 'Robinhood Chain' ? await ponsHolders(address,asset.id,params.get('cursor') ?? '') : { items:[], cursor:null, updatedAt:Date.now() }
    return Response.json({ data }, { headers: { 'Cache-Control':'no-store' } })
  } catch (e) {
    return Response.json({ error: { code:e instanceof MarketError ? e.code : 'unavailable', message:e instanceof Error ? e.message : 'Market data unavailable' } }, { status:e instanceof MarketError ? e.status : 502, headers:{'Cache-Control':'no-store'} })
  }
}
