// Server-only bounded cache, request coalescing, provider-wide cooldowns.
const cache = new Map<string, { value: unknown; until: number }>()
const pending = new Map<string, Promise<unknown>>()
const cooldown = new Map<string, number>()
const budgets = new Map<string, number[]>()
const misses = new Map<string, number>()
const fetched = new WeakMap<object, number>()
const health = new Map<string,{lastRequest?:number;lastSuccess?:number;lastError?:string;lastFailure?:number}>()
export function providerHealth() {return ['api.dexscreener.com','api.geckoterminal.com','api.ponsportal.fun',process.env.BLOCKSCOUT_API_KEY?'api.blockscout.com':'robinhoodchain.blockscout.com'].map(host=>({host,...health.get(host),cooldownUntil:cooldown.get(host)??0,cachedResponses:[...cache.keys()].filter(url=>new URL(url).host===host).length}))}
export function fetchedAt(value: unknown) { return value && typeof value === 'object' ? fetched.get(value) ?? Date.now() : Date.now() }
export class MarketError extends Error { constructor(public code: string, message: string, public status = 502) { super(message) } }
export async function readJson(url: string, ttl: number): Promise<unknown> {
  if ((misses.get(url) ?? 0)>Date.now()) throw new MarketError('not-found','Token not found by this provider.',404)
  const hit = cache.get(url)
  if (hit && hit.until > Date.now()) return hit.value
  if (pending.has(url)) return pending.get(url)!
  const host = new URL(url).host, now = Date.now()
  if ((cooldown.get(host) ?? 0) > now) throw new MarketError('rate-limited', 'Provider is cooling down. Try again shortly.', 429)
  const pons = host === 'api.ponsportal.fun', history = host === 'api.geckoterminal.com'
  const windowMs = pons ? 900000 : 60000, limit = pons ? 55 : history ? 9 : 250
  const recent = (budgets.get(host) ?? []).filter(t => t > now-windowMs)
  if (recent.length >= limit) throw new MarketError('rate-limited', 'Provider request budget reached. Try again later.', 429)
  budgets.set(host, [...recent, now])
  health.set(host,{...health.get(host),lastRequest:now})
  const task = (async () => {
    let response: Response
    try { response = await fetch(url, { signal: AbortSignal.timeout(12000), cache: 'no-store', headers: { Accept: 'application/json' } }) }
    catch (e) { throw new MarketError(e instanceof Error && e.name === 'TimeoutError' ? 'timeout' : 'offline', 'Market provider unavailable. Please retry.') }
    if (response.status === 429) { cooldown.set(host, now + Math.max(60000, Number(response.headers.get('retry-after') || 60)*1000)); throw new MarketError('rate-limited', 'Provider rate limit reached. Please retry later.', 429) }
    if (response.status===402) throw new MarketError('api-key-required','This market provider requires a server API key.',503)
    if (response.status===403) throw new MarketError('provider-access','The market provider is blocking API access. Please retry later.',503)
    if (!response.ok) { if(response.status===404){if(misses.size>=500)misses.delete(misses.keys().next().value!);misses.set(url,Date.now()+900000)} throw new MarketError(response.status === 404 ? 'not-found' : 'unavailable', response.status === 404 ? 'Token not found by this provider.' : 'Market provider unavailable.', response.status === 404 ? 404 : 502) }
    const value: unknown = await response.json()
    if (value && typeof value === 'object') fetched.set(value,Date.now())
    if (cache.size >= 500) cache.delete(cache.keys().next().value!)
    cache.set(url, { value, until: Date.now()+ttl })
    health.set(host,{...health.get(host),lastSuccess:Date.now(),lastError:undefined})
    return value
  })()
  pending.set(url, task)
  try { return await task } catch(error) {health.set(host,{...health.get(host),lastError:error instanceof Error?error.message:'Provider unavailable',lastFailure:Date.now()});throw error} finally { pending.delete(url) }
}
