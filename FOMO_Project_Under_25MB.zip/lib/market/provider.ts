import type { Asset, Candle, ChartTimeframe, Holder, MarketQuote } from './types'

export interface MarketDataProvider {
  resolveToken(chain: string, contractAddress: string): Promise<Asset>
  getCandles(assetId: string, timeframe: ChartTimeframe, before?: number): Promise<Candle[]>
  getQuote(assetId: string): Promise<MarketQuote>
  getHolders(assetId: string): Promise<Holder[]>
  subscribeQuote?(assetId: string, callback: (quote: MarketQuote) => void): () => void
}
