/** Session diagnostics only. Never persisted and never updates the app store. */
export const viewportDiagnostics: {assetId?:string;first?:number;last?:number;selected?:number;live?:boolean;candles?:number} = {}
