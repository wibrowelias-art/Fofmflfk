import type { Asset, Candle, HolderPage } from './types'

export function record(v: unknown): Record<string, unknown> { return v && typeof v === 'object' && !Array.isArray(v) ? v as Record<string, unknown> : {} }
export function number(v: unknown): number | null { if (v === null || v === undefined || v === '' || typeof v === 'boolean') return null; const n = Number(v); return Number.isFinite(n) ? n : null }
export function string(v: unknown) { return typeof v === 'string' ? v : '' }
export function safeUrl(v: unknown): string | undefined { try { const u = new URL(string(v)); return u.protocol === 'https:' ? u.href : undefined } catch { return undefined } }
export const chains: Record<string, string> = { solana: 'Solana', ethereum: 'Ethereum', base: 'Base', bsc: 'BNB Chain', robinhood: 'Robinhood Chain' }
export const isContract = (v: string) => /^0x[a-fA-F0-9]{40}$/.test(v) || /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(v)
export function emptyAsset(address: string, chainId: string): Asset {
  return { id: `${chainId}:${chainId === 'solana' ? address : address.toLowerCase()}`, source: 'remote', chainId: ({ethereum:'1',base:'8453',bsc:'56',robinhood:'4663'} as Record<string,string>)[chainId] ?? chainId, chain: chains[chainId] ?? chainId, contractAddress: address, name: '', symbol: '', iconUrl: '', priceUsd: null, priceUnavailable: true, marketCapUsd: null, fdvUsd: null, liquidityUsd: null, volume24hUsd: null, holders: null, priceChange24hPct: null, candles: [] }
}
export function normalizeDex(value: unknown, address: string, chain?: string): Asset[] {
  const rows = Array.isArray(value) ? value : record(value).pairs
  if (!Array.isArray(rows)) throw new Error('Malformed DEX response')
  return rows.flatMap(row => {
    const p = record(row), base = record(p.baseToken), network = string(p.chainId)
    if (!chains[network] || (chain && chains[network] !== chain) || (network === 'solana' ? string(base.address) !== address : string(base.address).toLowerCase() !== address.toLowerCase()) || !string(base.symbol)) return []
    const info = record(p.info), socials = Array.isArray(info.socials) ? info.socials.map(record) : []
    const rawPrice = number(p.priceUsd), usd = rawPrice !== null && rawPrice > 0 ? rawPrice : null
    return [{ ...emptyAsset(address, network), name: string(base.name), symbol: string(base.symbol), priceUsd: usd, priceUnavailable: usd === null, marketCapUsd: number(p.marketCap), fdvUsd: number(p.fdv), liquidityUsd: number(record(p.liquidity).usd), volume24hUsd: number(record(p.volume).h24), priceChange24hPct: number(record(p.priceChange).h24), poolAddress: string(p.pairAddress), pairToken: string(record(p.quoteToken).address), pairTokenSymbol: string(record(p.quoteToken).symbol), pairCreatedAt: number(p.pairCreatedAt) ?? undefined, iconUrl: safeUrl(info.imageUrl) ?? '', website: safeUrl(record(Array.isArray(info.websites) ? info.websites[0] : null).url), x: safeUrl(socials.find(s => s.type === 'twitter')?.url), telegram: safeUrl(socials.find(s => s.type === 'telegram')?.url), provider: 'DEX Screener', providerAssetId: string(p.pairAddress), lastMetadataUpdate: Date.now(), lastQuoteUpdate: Date.now() }]
  }).sort((a,b) => (b.liquidityUsd ?? 0) - (a.liquidityUsd ?? 0))
}
export function normalizePons(address: string, metadata: unknown, token: unknown, price: unknown, ethUsd: number | null): Asset {
  const m = record(metadata), t = record(token), p = record(price)
  if (!string(m.symbol) || !string(m.name)) throw new Error('Token metadata unavailable')
  const decimals = number(m.decimals), rawSupply = number(m.total_supply)
  const supply = rawSupply !== null && decimals !== null ? rawSupply / 10 ** decimals : undefined
  const ethPrice = t.pairTokenLabel === 'ETH' ? number(p.priceEth) : null
  const rawPrice = ethPrice !== null && ethUsd !== null ? ethPrice * ethUsd : number(m.exchange_rate)
  const usd = rawPrice !== null && rawPrice > 0 ? rawPrice : null
  return { ...emptyAsset(address, 'robinhood'), name: string(m.name), symbol: string(m.symbol), chainId: '4663', decimals: decimals ?? undefined, supply, circulatingSupply: number(m.circulating_supply) ?? undefined, priceUsd: usd, priceUnavailable: usd === null, marketCapUsd: number(m.circulating_market_cap), fdvUsd: usd !== null && supply !== undefined ? usd * supply : null, volume24hUsd: number(m.volume_24h), holders: number(m.holders_count), iconUrl: safeUrl(m.icon_url) ?? '', pairToken: string(t.pairToken) || undefined, pairTokenSymbol: string(t.pairTokenLabel) || undefined, provider: t.ok === true ? 'Pons + Blockscout' : 'Blockscout', providerAssetId: address, lastMetadataUpdate: Date.now(), lastQuoteUpdate: Date.now() }
}
export function normalizeHolders(value: unknown, assetId: string): HolderPage {
  const data = record(value)
  if (data.ok !== true || !Array.isArray(data.holders)) throw new Error('Holder data unavailable')
  const items = data.holders.flatMap(row => { const r = record(row), address = string(r.address), units = number(r.balanceFormatted); return /^0x[\da-f]{40}$/i.test(address) && units !== null ? [{ id: address, address, traderId: '', assetId, units, entryPriceUsd: 0, entryMarketCapUsd: 0 }] : [] })
  const cursor = record(data.next_page_params), params = new URLSearchParams()
  for (const key of ['value', 'address_hash', 'items_count']) if (cursor[key] !== undefined) params.set(key, String(cursor[key]))
  return { items, cursor: params.size ? params.toString() : null, updatedAt: Date.now() }
}
export function normalizeOhlcv(value: unknown): Candle[] {
  const rows = record(record(record(value).data).attributes).ohlcv_list
  if (!Array.isArray(rows)) throw new Error('Malformed OHLCV response')
  const candles: Candle[] = rows.flatMap(row => {
    if (!Array.isArray(row) || row.length < 6) return []
    const ns = row.slice(0,6).map(number)
    if (ns.some(n => n === null)) return []
    const [timestamp, open, high, low, close, volume] = ns as number[]
    if (timestamp <= 0 || !Number.isSafeInteger(timestamp * 1000) || low <= 0 || high < Math.max(open,close) || low > Math.min(open,close) || volume < 0) return []
    return [{ timestamp: timestamp * 1000, open, high, low, close, volume, marketCapUsd: null }]
  })
  return [...new Map(candles.map(c => [c.timestamp,c])).values()].sort((a,b) => a.timestamp-b.timestamp)
}

export function normalizeBlockscoutHolders(value:unknown,assetId:string,decimals:number):HolderPage {
  const data=record(value)
  if(!Array.isArray(data.items)||!Number.isInteger(decimals)||decimals<0||decimals>36)throw new Error('Holder data unavailable')
  const holders=data.items.map(row=>{const r=record(row);return {address:string(record(r.address).hash),balanceFormatted:(number(r.value)??Number.NaN)/10**decimals}})
  return normalizeHolders({ok:true,holders,next_page_params:data.next_page_params},assetId)
}
