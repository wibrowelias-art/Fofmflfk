import type { Candle } from './types'
import type { TradeEvent } from '@/lib/positions/types'
import { lowerBound } from './timeline'
export const MARKER_RADIUS=12
export const MARKER_GAP=27
export function markerLayout(candles:Candle[],events:TradeEvent[],x:(timestamp:number)=>number,y:(price:number)=>number,top:number,bottom:number,options:{compression?:boolean;small?:boolean}={}) {
  if(!candles.length)return []
  const groups:Array<{lastX:number;candle:Candle; items:Array<{event:TradeEvent;x:number}>}>=[]
  const first=candles[0].startTimestamp??candles[0].timestamp,last=candles.at(-1)!.timestamp
  for(const event of [...events].filter(e=>e.timestamp>=first&&e.timestamp<=last).sort((a,b)=>a.timestamp-b.timestamp||a.id.localeCompare(b.id))) {
    // Aggregated candle timestamps are bucket ends: select the containing bucket.
    const candle=candles[Math.min(candles.length-1,lowerBound(candles,event.timestamp))]
    const px=x(candle.timestamp), previous=groups.at(-1)
    if(previous&&px===previous.lastX){previous.items.push({event,x:px})}
    else groups.push({lastX:px,candle,items:[{event,x:px}]})
  }
  const capacity=Math.max(1,Math.floor((bottom-top-2*MARKER_RADIUS)/MARKER_GAP)+1)
  const placed:Array<{event:TradeEvent;x:number;y:number;overflow:number;events:TradeEvent[];radius:number;compact:boolean}>=[]
  for(const group of groups){
    const px=group.lastX
    const radius=options.small?8:options.compression&&group.items.length>10?9:options.compression&&group.items.length>5?10:12,gap=radius*2+3
    const neighbors=placed.filter(p=>Math.abs(p.x-px)<p.radius+radius+3)
    // Markers sit above the displayed candle's wick, including aggregated
    // candles. Excess events get a count instead of spilling below the candle.
    const anchor=Math.max(top+radius,Math.min(bottom-radius,y(group.candle.high)-radius-6))
    const slots=Array.from({length:Math.max(capacity,Math.ceil((bottom-top)/gap))},(_,i)=>anchor-i*gap).filter(py=>py>=top+radius&&!neighbors.some(p=>Math.abs(p.y-py)<p.radius+radius+3))
    const nearbyColumns=groups.filter(g=>Math.abs(g.lastX-px)<MARKER_GAP).length
    const availableRows=Math.max(1,Math.floor((anchor-top-radius)/gap)+1)
    const sharedLimit=Math.max(1,Math.floor(availableRows/nearbyColumns))
    const selected=slots.slice(0,Math.min(sharedLimit,options.compression?Math.min(group.items.length,group.items.length>10?3:5):group.items.length))
    if(!selected.length){placed.push({...group.items[0],y:Math.max(top+3,Math.min(bottom-3,anchor)),overflow:group.items.length-1,events:group.items.map(i=>i.event),radius:3,compact:true});continue}
    selected.forEach((py,i)=>{const events=i===selected.length-1?group.items.slice(i).map(item=>item.event):[group.items[i].event];placed.push({...group.items[i],y:py,overflow:events.length-1,events,radius,compact:false})})
  }
  return placed
}
