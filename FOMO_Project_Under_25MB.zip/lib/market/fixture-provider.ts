import type { MarketDataProvider } from './provider'
import type { Asset, ChartTimeframe, Holder } from './types'
import { quoteAt, visibleCandles } from './timeline'

export class FixtureMarketDataProvider implements MarketDataProvider {
  constructor(private assets: Asset[] = [], private holders: Holder[] = []) {}
  private asset(id: string) {
    const asset = this.assets.find(a => a.id === id)
    if (!asset) throw new Error('Asset not found.')
    return asset
  }
  async resolveToken(chain: string, contractAddress: string) {
    const asset = this.assets.find(a => a.chain === chain && a.contractAddress === contractAddress.trim())
    if (!asset) throw new Error('No loaded fixture found. Load the dataset in Backstage → Development.')
    return structuredClone(asset)
  }
  async getCandles(assetId: string, timeframe: ChartTimeframe, before?: number) {
    return visibleCandles(this.asset(assetId).candles, timeframe, before)
  }
  async getQuote(assetId: string) {
    return quoteAt(this.asset(assetId), { type: 'live' })
  }
  async getHolders(assetId: string) {
    return this.holders.filter(h => h.assetId === assetId)
  }
}
