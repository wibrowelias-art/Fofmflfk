export type Chain = 'Solana' | 'Base' | 'Ethereum' | 'BNB Chain' | 'Generic' | string
export type ChartTimeframe = 'LIVE' | '1H' | '4H' | '1D' | '7D' | 'ALL'

export interface Candle {
  /** Inclusive start of a displayed aggregate; timestamp is its last candle. */
  startTimestamp?: number
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume?: number
  marketCapUsd?: number | null
}

export interface Asset {
  metadataImageUrl?: string
  manualImageUrl?: string
  imageRevision?: number
  source?: 'fixture' | 'remote'
  chainId?: string
  provider?: string
  providerAssetId?: string
  poolAddress?: string
  pairToken?: string
  pairTokenSymbol?: string
  pairCreatedAt?: number
  decimals?: number
  circulatingSupply?: number
  lastMetadataUpdate?: number
  lastQuoteUpdate?: number
  priceUnavailable?: boolean
  transient?: boolean
  id: string
  symbol: string
  name: string
  chain: Chain
  contractAddress: string
  iconUrl: string
  priceUsd: number | null
  marketCapUsd: number | null
  fdvUsd: number | null
  liquidityUsd: number | null
  volume24hUsd: number | null
  holders: number | null
  priceChange24hPct: number | null
  supply?: number
  verified?: boolean
  launchpad?: string
  category?: 'graduated' | 'bonding'
  description?: string
  website?: string
  x?: string
  telegram?: string
  candles: Candle[]
}

export interface MarketQuote {
  unavailable?: boolean
  assetId: string
  timestamp: number
  priceUsd: number
  marketCapUsd: number | null
  priceChange24hPct: number | null
}

export interface Trader {
  rank?: number
  followingCount?: number
  pnlPct?: number
  verified?: boolean
  bio?: string
  associatedAssets?: string[]
  favorite?: boolean
  enabled?: boolean
  id: string
  displayName: string
  handle: string
  avatar: string
  followers: number
  pnlUsd: number
  following: boolean
}

export interface Holder {
  address?: string
  id: string
  traderId: string
  assetId: string
  units: number
  entryPriceUsd: number
  entryMarketCapUsd: number
  thesis?: string
}

export interface HolderPage { items: Holder[]; cursor: string | null; updatedAt: number }
