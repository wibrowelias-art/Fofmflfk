import type { TemplateDefinition } from './types'
export const stress:TemplateDefinition={id:'stress',name:'Chart Stress Test',description:'12 buys and 12 partial sells per token. Dense columns and neighboring candles.',category:'Charts',startingCash:100000,assets:2,events:48,open:2,closed:0,requiresMarketResolution:true}
