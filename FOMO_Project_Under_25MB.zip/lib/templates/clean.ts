import type { TemplateDefinition } from './types'
export const clean:TemplateDefinition={id:'clean',name:'Clean Start',description:'Clear market data, cash and practice history. Keep your identity and chart preference.',category:'Fresh start',startingCash:0,assets:0,events:0,open:0,closed:0,requiresMarketResolution:false}
