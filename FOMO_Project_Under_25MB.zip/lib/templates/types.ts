import type { AppState } from '../store-types'
import type { Asset, Candle } from '../market/types'
import type { Discovery } from '../market/providers/discovery'
export interface TemplateDefinition {
  id: 'rich'|'trending'|'active'|'fumble'|'stress'|'clean'|'portfolio'
  name: string
  description: string
  category: string
  startingCash: number
  assets: number
  events: number
  open: number
  closed: number
  requiresMarketResolution: boolean
}
export interface TemplateMarket {
  discovery(signal?:AbortSignal): Promise<Discovery>
  resolve(asset:Asset,signal?:AbortSignal): Promise<Asset>
  candles(asset:Asset,signal?:AbortSignal): Promise<Candle[]>
}
export interface TemplateCandidate { state:AppState; warnings:string[]; source:string }
