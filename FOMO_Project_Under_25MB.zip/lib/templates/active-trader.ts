import type { TemplateDefinition } from './types'
export const active:TemplateDefinition={id:'active',name:'Active Trader',description:'Multiple entries and partial exits, with varied holding times and closed wins and losses.',category:'Practice',startingCash:75000,assets:7,events:32,open:5,closed:2,requiresMarketResolution:true}
