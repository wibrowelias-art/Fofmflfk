import type { TemplateDefinition } from './types'
export const trending:TemplateDefinition={id:'trending',name:'Trending Tokens',description:'Current trending market tokens, ready to watch. No holdings or practice trades.',category:'Discovery',startingCash:0,assets:12,events:0,open:0,closed:0,requiresMarketResolution:true}
