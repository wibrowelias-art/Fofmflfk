import { fixtureTraders } from '../fixtures/traders'
import { rich } from './rich'
import { trending } from './trending'
import { active } from './active-trader'
import { fumble } from './fumble'
import { stress } from './stress'
import { clean } from './clean'
import { portfolio } from './portfolio-showcase'
import type { TemplateDefinition, TemplateCandidate, TemplateMarket } from './types'
import type { Asset } from '../market/types'
import type { AppState } from '../store-types'
import { makeInitialState, parseBackup, portfolioValue } from '../store'
import { derivePositions, positionMetrics, validateCash } from '../positions/calculations'
import { calculateFumble } from '../positions/fumble'
import { quoteAt } from '../market/timeline'
export const templates=[rich,trending,active,fumble,stress,clean,portfolio]
export function summarize(state:AppState) {
  const positions=derivePositions(state.tradeEvents)
  return {cash:state.cash,assets:state.assets.length,events:state.tradeEvents.length,open:positions.filter(p=>p.status==='open').length,closed:positions.filter(p=>p.status==='closed').length,watchlist:state.watchlist.length,favorites:state.watchlist.length,recents:state.searchRecents.length,weekly:state.weeklyTopTrades.length,history:state.assets.reduce((n,a)=>n+a.candles.length,0),performance:state.portfolioHistory.length}
}
type Strategy='win'|'loss'|'fumble'|'nonfumble'
function windowFor(asset:Asset,strategy:Strategy) {
  const c=asset.candles, current=asset.priceUsd ?? c.at(-1)?.close ?? 0
  let best:{entry:number;exit:number;score:number}|undefined
  for(let exit=7;exit<c.length-4;exit++) {
    if(strategy==='fumble'&&c[exit].close>=current*.98 || strategy==='nonfumble'&&c[exit].close<current)continue
    for(let entry=0;entry<exit-4;entry+=Math.max(1,Math.floor(c.length/60))) {
      const cost=(c[entry].close+c[entry+1].close+c[entry+2].close)/3
      const ratio=c[exit].close/cost
      if(strategy==='win'&&ratio<=1.03 || strategy==='loss'&&ratio>=.97)continue
      if(ratio>5 || ratio<.05)continue
      const score=strategy==='loss'?1-ratio:strategy==='fumble'?current/c[exit].close:ratio
      if(!best||score>best.score)best={entry,exit,score}
    }
  }
  return best
}
function chooseAssets(def:TemplateDefinition,available:Asset[]) {
  const chosen:Asset[]=[], plans=new Map<string,ReturnType<typeof windowFor>>()
  const strategies:Strategy[]=def.id==='fumble'?['fumble','fumble','fumble','nonfumble']:def.id==='rich'?['fumble','loss','win']:def.id==='active'?['win','loss']:[]
  for(const strategy of strategies) {
    const asset=available.find(a=>!chosen.some(x=>x.id===a.id)&&windowFor(a,strategy))
    if(!asset)throw new Error(`Available history cannot create the required ${strategy} example. Your current setup is unchanged. Retry discovery later.`)
    chosen.push(asset);plans.set(asset.id,windowFor(asset,strategy))
  }
  const remaining=available.filter(a=>!chosen.some(x=>x.id===a.id))
  if(def.id==='fumble')return {assets:chosen,plans}
  const assets=[...remaining.slice(0,def.open),...chosen,...remaining.slice(def.open,def.assets-chosen.length)]
  return {assets:assets.slice(0,def.assets),plans}
}
export function createCandidate(def:TemplateDefinition,current:AppState,available:Asset[],source:string,now=Date.now()):AppState {
  const state=makeInitialState()
  state.profile={...current.profile,manualStats:false,tradeCount:0,averageHold:'—'}
  state.settings.chart=current.settings.chart
  state.settings.appearance=current.settings.appearance
  state.settings.social=current.settings.social
  state.settings.chartStyle=current.settings.chartStyle
  state.settings.loadedTemplate={id:def.id,name:def.name,loadedAt:new Date(now).toISOString(),source}
  if(def.id==='clean')return parseBackup(JSON.stringify({version:2,state}))
  if(available.length<def.assets)throw new Error(`Need ${def.assets} valid tokens; only ${available.length} are available. Current setup preserved.`)
  const selection=chooseAssets(def,available)
  state.assets=structuredClone(selection.assets).map(a=>({...a,transient:false}))
  if(state.assets.length<def.assets)throw new Error(`Need ${def.assets} valid tokens; only ${state.assets.length} are available. Current setup preserved.`)
  state.cash=def.startingCash
  state.watchlist=state.assets.map(a=>a.id)
  state.searchRecents=state.assets.slice(0,10).map(a=>({type:'asset',id:a.id}))
  state.settings.replayAssetId=state.assets[0].id
  if(def.id==='trending')return parseBackup(JSON.stringify({version:2,state}))
  let serial=0
  const add=(asset:Asset,index:number,side:'buy'|'sell',units:number)=>{
    const candle=asset.candles[index]
    state.tradeEvents.push({id:`practice-${def.id}-${String(serial++).padStart(4,'0')}`,assetId:asset.id,side,units,priceUsd:candle.close,usdValue:units*candle.close,timestamp:candle.timestamp,marketCapUsd:candle.marketCapUsd??null})
  }
  state.assets.forEach((asset,index)=>{
    const c=asset.candles
    if(c.length<24)throw new Error(`Historical chart unavailable for ${asset.symbol}. Current setup preserved.`)
    const plan=selection.plans.get(asset.id)
    const first=plan?.entry??Math.floor(c.length*(.12+index%4*.1))
    const exit=plan?.exit??Math.min(c.length-5,Math.max(first+5,Math.floor(c.length*(.65+index%3*.08))))
    const scale=def.id==='fumble'?[.05,.4,1.5,.2][index]:def.id==='portfolio'?[.05,.2,.4,1,1.8,.6,1.2][index]:1
    const units=def.startingCash*.6/def.assets/c[first].close*scale
    if(def.id==='fumble'){add(asset,exit-2,'buy',units*.5);add(asset,exit-1,'buy',units*.5);add(asset,exit,'sell',units);return}
    const dense=def.id==='stress'||def.id==='rich'&&index===0
    const buyCount=dense?12:def.id==='rich'&&index===1?5:3
    for(let i=0;i<buyCount;i++)add(asset,first+(dense?Math.floor(i/6):i),'buy',units/buyCount)
    if(dense){const n=def.id==='stress'?12:10;for(let i=0;i<n;i++)add(asset,exit+Math.floor(i/6),'sell',units*.5/n)}
    else if(index>=def.open&&def.id==='rich'&&index===state.assets.length-1){add(asset,exit,'sell',units*.2);add(asset,exit+1,'buy',units*.2);add(asset,exit+2,'sell',units*.3);add(asset,exit+3,'sell',units*.7)}
    else if(index>=def.open){add(asset,exit,'sell',units*.2);add(asset,exit+1,'sell',units*.3);add(asset,exit+2,'sell',units*.5)}
    else add(asset,exit,'sell',units*.15)
  })
  state.tradeEvents.sort((a,b)=>a.timestamp-b.timestamp)
  // cash is the promised local balance. Reconstruct initial funding through
  // cashAt, and reduce practice size only if historical proceeds need it.
  for(let attempt=0;;attempt++) {
    try{validateCash(state.cash,state.tradeEvents,state.tradeEvents);break}
    catch(error){if(attempt===12)throw error;state.tradeEvents=state.tradeEvents.map(e=>({...e,units:e.units/2,usdValue:e.usdValue/2}))}
  }
  // Late historical entries keep Rich Demo's holdings substantial even when
  // older markets have fallen sharply. Prices still come from real candles.
  if(def.id==='rich')for(const asset of state.assets.slice(0,3))add(asset,asset.candles.length-1,'buy',def.startingCash*.5/asset.candles.at(-1)!.close)
  state.tradeEvents.sort((a,b)=>a.timestamp-b.timestamp)
  validateCash(state.cash,state.tradeEvents,state.tradeEvents)
  state.positions=derivePositions(state.tradeEvents)
  const fumbles=state.positions.map(p=>{const a=state.assets.find(a=>a.id===p.assetId)!;return calculateFumble(p,state.tradeEvents,quoteAt(a,{type:'live'}).priceUsd,now)}).filter(Boolean)
  const metrics=state.positions.map(p=>positionMetrics(p,quoteAt(state.assets.find(a=>a.id===p.assetId)!,{type:'live'}).priceUsd))
  if(def.id==='fumble'&&fumbles.length!==3 || def.id==='rich'&&(!fumbles.length||!metrics.some(m=>m.pnlUsd<0)||!metrics.some(m=>m.pnlUsd>0)))throw new Error('Current history cannot satisfy this template’s win, loss or Fumble requirements. Current setup preserved.')
  const start=Math.min(...state.assets.map(a=>a.candles[0].timestamp)), end=Math.max(...state.assets.map(a=>a.candles.at(-1)!.timestamp))
  state.portfolioHistory=Array.from({length:100},(_,i)=>{const timestamp=start+(end-start)*i/99;return {timestamp,valueUsd:portfolioValue({...state,timeline:{type:'replay',timestamp,speed:0}},timestamp,false)}}).filter(p=>Number.isFinite(p.valueUsd))
  state.traders=structuredClone(current.traders.filter(t=>t.id!=='local-practice').length?current.traders.filter(t=>t.id!=='local-practice'):fixtureTraders).map(t=>({...t,associatedAssets:t.associatedAssets?.filter(id=>state.assets.some(a=>a.id===id))}))
  state.settings.weeklyMode='auto'
  state.searchRecents=[...state.traders.filter(t=>t.enabled!==false).slice(0,4).map(t=>({type:'trader' as const,id:t.id})),...state.searchRecents]
  state.weeklyTopTrades=state.positions.map((p,i)=>({id:p.id,traderId:state.traders[i%state.traders.length].id,assetId:p.assetId,pnlUsd:positionMetrics(p,quoteAt(state.assets.find(a=>a.id===p.assetId)!,{type:'live'}).priceUsd).pnlUsd})).sort((a,b)=>b.pnlUsd-a.pnlUsd).slice(0,3)
  return parseBackup(JSON.stringify({version:2,state}))
}
export async function buildTemplate(def:TemplateDefinition,current:AppState,market:TemplateMarket,onProgress:(message:string)=>void=()=>{},signal?:AbortSignal):Promise<TemplateCandidate> {
  if(def.id==='clean')return {state:createCandidate(def,current,[],'Local practice'),warnings:[],source:'Local practice'}
  onProgress('Finding tokens…')
  const discovery=await market.discovery(signal), warnings:string[]=[], assets:Asset[]=[]
  // Trade scenarios may reuse currently tracked real markets with cached history.
  const candidates=def.id==='trending'?discovery.assets:[...current.assets.filter(a=>a.source==='remote'),...discovery.assets]
  for(const item of [...new Map(candidates.map(a=>[a.id,a])).values()]) {
    signal?.throwIfAborted()
    onProgress(`Resolving ${assets.length+1} of ${def.assets}…`)
    try {
      let resolved=await market.resolve(item,signal)
      if(resolved.id!==item.id||resolved.contractAddress.toLowerCase()!==item.contractAddress.toLowerCase())throw new Error('Provider returned another token')
      resolved={...resolved,poolAddress:item.poolAddress||resolved.poolAddress,candles:item.candles,transient:false}
      if(def.id!=='trending') {
        onProgress(`Loading historical data · ${resolved.symbol}…`)
        resolved.candles=item.candles.length>=24?item.candles:await market.candles(resolved,signal)
        if(resolved.candles.length<24)throw new Error('Historical chart unavailable')
      }
      assets.push(resolved)
    } catch(error){signal?.throwIfAborted();warnings.push(`${item.symbol}: ${error instanceof Error?error.message:'Unavailable'}`)}
    if(assets.length>=def.assets) {
      try{const state=createCandidate(def,current,assets,discovery.source);onProgress('Ready');return {state,warnings,source:discovery.source}}catch(error){if(assets.length>=24)throw error}
    }
  }
  onProgress('Creating replay timeline…')
  return {state:createCandidate(def,current,assets,discovery.source),warnings,source:discovery.source}
}
