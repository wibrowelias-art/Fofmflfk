import type { TemplateDefinition } from './types'
export const rich:TemplateDefinition={id:'rich',name:'Rich Demo',description:'A full portfolio with layered entries, partial exits, wins, losses and Fumble.',category:'Portfolio',startingCash:550555.55,assets:12,events:80,open:8,closed:4,requiresMarketResolution:true}
