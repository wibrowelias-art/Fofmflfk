import { marketRequest } from '../market/providers/router'
import type { Asset, Candle } from '../market/types'
import type { Discovery } from '../market/providers/discovery'
import type { TemplateMarket } from './types'
const wait=(ms:number,signal?:AbortSignal)=>new Promise<void>((resolve,reject)=>{signal?.throwIfAborted();const done=()=>{signal?.removeEventListener('abort',abort);resolve()};const timer=setTimeout(done,ms);const abort=()=>{clearTimeout(timer);reject(signal?.reason)};signal?.addEventListener('abort',abort,{once:true})})
export function templateMarket(progress:(text:string)=>void):TemplateMarket {
  let nextHistory=0
  return {
    discovery:async signal=>{
      for(let attempt=0;;attempt++){
        try{return await marketRequest<Discovery>('search',{discovery:'trending'},signal)}
        catch(error){signal?.throwIfAborted();if(attempt===1||!(error instanceof Error)||!/rate limit|budget|cooling/i.test(error.message))throw error;progress('Discovery provider is cooling down · waiting to retry…');await wait(65000,signal)}
      }
    },
    resolve:(a,signal)=>marketRequest<Asset>('resolve',{address:a.contractAddress,chain:a.chain},signal),
    candles:async(a,signal)=>{
      // Stay within the existing provider budget; cancellation remains responsive.
      if(Date.now()<nextHistory){progress(`Loading historical data · ${a.symbol} · pacing provider requests…`);await wait(nextHistory-Date.now(),signal)}
      nextHistory=Date.now()+8000
      for(let attempt=0;;attempt++){
        try{return await marketRequest<Candle[]>('candles',{address:a.contractAddress,chain:a.chain,timeframe:'ALL',...(a.poolAddress?{pool:a.poolAddress}:{})},signal)}
        catch(error){signal?.throwIfAborted();if(attempt===1||!(error instanceof Error)||!/rate limit|budget|cooling/i.test(error.message))throw error;progress('Historical provider is cooling down · waiting to retry…');await wait(65000,signal)}
      }
    },
  }
}
