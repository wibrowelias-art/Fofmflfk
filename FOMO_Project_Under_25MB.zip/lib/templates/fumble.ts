import type { TemplateDefinition } from './types'
export const fumble:TemplateDefinition={id:'fumble',name:'Fumble Showcase',description:'Three exited positions with small, medium and large missed gains, plus a nonqualifying exit.',category:'Replay',startingCash:50000,assets:4,events:12,open:0,closed:4,requiresMarketResolution:true}
