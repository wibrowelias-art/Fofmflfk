import type { TemplateDefinition } from './types'
export const portfolio:TemplateDefinition={id:'portfolio',name:'Portfolio Showcase',description:'Varied token quantities and position sizes for checking every mobile alignment.',category:'Layout',startingCash:250000,assets:7,events:28,open:7,closed:0,requiresMarketResolution:true}
