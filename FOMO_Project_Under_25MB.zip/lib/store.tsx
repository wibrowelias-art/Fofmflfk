'use client'

import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { validateCustomization } from './customization'
import type { BackstageTab, AppState } from './store-types'
import type { Asset, Candle } from './market/types'
import type { TradeEvent } from './positions/types'
import { fixtureAssets } from './fixtures/assets'
import { fixtureTraders } from './fixtures/traders'
import { ProviderRouter, marketRequest } from './market/providers/router'
import { cacheGet, cachePut, cacheDelete, blobDataUrl } from './storage'
import { derivePositions, validateCash, cashAt } from './positions/calculations'
import { quoteAt, stepReplay, nearestCandle } from './market/timeline'
import { APP_MARK, APP_NAME } from './branding'
import { selectPortfolioAt, selectTimestamp } from './positions/selectors'

export type Screen = 'home' | 'search' | 'token' | 'profile' | 'backstage' | 'share' | 'center' | 'people'
export type Sheet = null | 'deposit' | 'trade' | 'position'
export interface TradeDraft { side: 'buy' | 'sell'; candle: Candle }
export interface UIState {
  qaMode?: 'none' | 'quote-unavailable' | 'candles-unavailable' | 'image-failure' | 'rate-limit'
  replayStart?: number
  backstageTab?: BackstageTab
  screen: Screen
  assetId: string
  sheet: Sheet
  positionId: string | null
  shareKind: 'position' | 'fumble'
  tradeDraft: TradeDraft | null
  toast: string
}

const STORAGE_KEY = 'replay:setup:v1'

/** Provider refreshes must not overwrite locally edited artwork or tracking. */
export function mergeMarketAsset(asset: Asset, market?: Asset): Asset {
  return market ? {...market,manualImageUrl:asset.manualImageUrl,imageRevision:asset.imageRevision,metadataImageUrl:market.metadataImageUrl||asset.metadataImageUrl,transient:asset.transient} : asset
}

export function makeInitialState(): AppState {
  return {
    profile: { displayName: 'QuietOrbit', handle: 'quietorbit', bio: '', avatar: '/art/profile.svg', followers: 0, following: 0, averageHold: '—', tradeCount: 0, joinedDate: new Date().toISOString().slice(0, 10) },
    cash: 0, assets: [], watchlist: [], positions: [], tradeEvents: [], searchRecents: [], weeklyTopTrades: [], traders: [], holders: [],
    timeline: { type: 'live' }, portfolioHistory: [], settings: { replayAssetId: '', overrides: {}, chartStyle: 'candles' },
  }
}

/** Only called by the explicit Development action and test scenarios. */
export function makeFixtureState(): AppState {
  const assets = fixtureAssets()
  const traders = structuredClone(fixtureTraders)
  return {
    profile: {
      displayName: 'QuietOrbit', handle: 'quietorbit', bio: '', avatar: '/art/profile.svg', followers: 3, following: 4,
      averageHold: '4h 46m', tradeCount: 0, joinedDate: '2026-08-01',
    },
    cash: 0,
    assets,
    watchlist: ['paid', 'si'],
    positions: [],
    tradeEvents: [],
    searchRecents: [
      { type: 'trader', id: 'nova' }, { type: 'trader', id: 'lunar' }, { type: 'trader', id: 'orbit' },
      ...['paid', 'cyberleek', 'cashcat', 'si'].map(id => ({ type: 'asset' as const, id })),
    ],
    weeklyTopTrades: traders.slice(0, 3).map((trader, i) => ({ id: `weekly-${i}`, traderId: trader.id, assetId: i === 2 ? 'moin' : 'si', pnlUsd: trader.pnlUsd })),
    traders,
    holders: assets.flatMap(asset => traders.slice(0, 3).map((trader, i) => ({
      id: asset.id + trader.id,
      traderId: trader.id,
      assetId: asset.id,
      units: 331972.24 / (i + 1) / (asset.priceUsd ?? 1),
      entryPriceUsd: (asset.priceUsd ?? 0) / (6.9 - i),
      entryMarketCapUsd: (asset.marketCapUsd ?? 0) / (6.9 - i),
      thesis: i === 0 ? 'Watching the higher lows. Patience over noise.' : undefined,
    }))),
    timeline: { type: 'live' },
    portfolioHistory: [],
    settings: { replayAssetId: 'si', overrides: {}, chartStyle: 'candles' },
  }
}

function currentTimestamp(state: AppState) {
  return selectTimestamp(state)
}

export function portfolioValue(state: AppState, timestamp = currentTimestamp(state), useOverrides = true) {
  return selectPortfolioAt(state,timestamp,useOverrides).value
}

function packState(state: AppState) {
  const tracked = new Set(state.assets.filter(a=>!a.transient).map(a=>a.id))
  return JSON.stringify({
    version: 2,
    packed: true,
    savedAt: new Date().toISOString(),
    state: {
      ...state,
      profile: { ...state.profile, avatar: state.profile.avatarKey ? '/art/profile.svg' : state.profile.avatar },
      watchlist: state.watchlist.filter(id=>tracked.has(id)),
      searchRecents: state.searchRecents.filter(r=>r.type!=='asset'||tracked.has(r.id)),
      assets: state.assets.filter(a => !a.transient).map(asset => ({ ...asset, candles: asset.candles.map(c => [c.timestamp, c.open, c.high, c.low, c.close, c.volume ?? null, c.marketCapUsd ?? null]) })),
    },
  })
}

export function parseBackup(text: string): AppState {
  if (text.length > 15_000_000) throw new Error('Invalid setup: file too large. Your current setup was not changed.')
  const parsed = JSON.parse(text)
  if (!parsed || ![1, 2].includes(parsed.version) || !parsed.state) throw new Error('Invalid setup: schema version. Your current setup was not changed.')
  const state = parsed.state as AppState
  if (!Array.isArray(state.assets) || !Array.isArray(state.tradeEvents) || !state.profile || !state.settings || !state.timeline) throw new Error('Invalid setup: missing required data.')
  if (parsed.packed) {
    state.assets = state.assets.map(asset => ({
      ...asset,
      candles: asset.candles.map(c => Array.isArray(c) ? {
        timestamp: c[0], open: c[1], high: c[2], low: c[3], close: c[4], ...(c[5] == null ? {} : { volume: c[5] }), marketCapUsd: c[6],
      } : c),
    }))
  }
  if (!Array.isArray(state.assets) || !Array.isArray(state.tradeEvents) || !state.profile || !state.settings) throw new Error('Invalid setup: missing required data. Your current setup was not changed.')
  for (const asset of state.assets) {
    if (!asset.id || !asset.name || !asset.symbol || !Array.isArray(asset.candles) || (asset.priceUsd !== null && !Number.isFinite(asset.priceUsd))) throw new Error('Invalid asset data.')
    if (!asset.source) asset.source = asset.contractAddress.startsWith('replay:') ? 'fixture' : 'remote'
    if (asset.candles.some((c,i)=>![c.timestamp,c.open,c.high,c.low,c.close].every(Number.isFinite) || c.low<=0 || c.high<Math.max(c.open,c.close) || c.low>Math.min(c.open,c.close) || (i>0&&c.timestamp<=asset.candles[i-1].timestamp))) throw new Error('Invalid candle history.')
  }
  if (state.tradeEvents.some(e=>!state.assets.some(a=>a.id===e.assetId))) throw new Error('Trade references an unknown asset.')
  if (!state.assets.some(a=>a.id===state.settings.replayAssetId)) state.settings.replayAssetId=state.assets[0]?.id ?? ''
  for (const key of ['watchlist','searchRecents','weeklyTopTrades','traders','holders','portfolioHistory'] as const) if (!Array.isArray(state[key])) throw new Error(`Invalid setup: ${key}.`)
  for (const key of ['displayName','handle','bio','avatar','averageHold','joinedDate'] as const) if (typeof state.profile[key] !== 'string') throw new Error('Invalid profile data.')
  for (const key of ['followers','following','tradeCount'] as const) if (!Number.isInteger(state.profile[key]) || state.profile[key]<0) throw new Error('Invalid profile counts.')
  if (!state.profile.displayName.trim() || !state.profile.handle.trim() || !Number.isFinite(Date.parse(state.profile.joinedDate))) throw new Error('Invalid profile identity or date.')
  if (!state.settings.overrides || !['line','candles'].includes(state.settings.chartStyle)) throw new Error('Invalid settings.')
  for (const override of Object.values(state.settings.overrides)) if (!override || (override.priceUsd!==undefined&&(!Number.isFinite(override.priceUsd)||override.priceUsd<=0)) || (override.marketCapUsd!==undefined&&(!Number.isFinite(override.marketCapUsd)||override.marketCapUsd<0))) throw new Error('Invalid quote override.')
  if (new Set(state.assets.map(a=>a.id)).size !== state.assets.length) throw new Error('Duplicate asset IDs.')
  if (state.watchlist.some(id=>!state.assets.some(a=>a.id===id)) || new Set(state.watchlist).size!==state.watchlist.length) throw new Error('Invalid watchlist references.')
  if (state.searchRecents.some(r=>!r || !['asset','trader'].includes(r.type) || !(r.type==='asset'?state.assets:state.traders).some(v=>v.id===r.id))) throw new Error('Invalid search recents.')
  if (state.weeklyTopTrades.some(t=>!state.assets.some(a=>a.id===t.assetId)||!state.traders.some(p=>p.id===t.traderId)||!Number.isFinite(t.pnlUsd))) throw new Error('Invalid weekly trades.')
  if (state.portfolioHistory.some(p=>!Number.isFinite(p.timestamp)||!Number.isFinite(p.valueUsd)||p.valueUsd<0)) throw new Error('Invalid portfolio history.')
  const template=state.settings.loadedTemplate
  if(template && (![template.id,template.name,template.source].every(v=>typeof v==='string'&&v.length>0)||!Number.isFinite(Date.parse(template.loadedAt)))) throw new Error('Invalid template metadata.')
  if (!['live','replay'].includes(state.timeline.type)) throw new Error('Invalid timeline.')
  if (!state.assets.length) state.timeline={type:'live'}
  if (state.timeline.type==='replay' && (!Number.isFinite(state.timeline.timestamp)||![-50,-10,-5,-1,0,1,5,10,50].includes(state.timeline.speed))) throw new Error('Invalid replay timeline.')
  validateCustomization(state)
  state.positions = derivePositions(state.tradeEvents)
  validateCash(state.cash, state.tradeEvents, state.tradeEvents)
  return state
}

interface StoreValue {
  state: AppState
  ui: UIState
  setUI: (patch: Partial<UIState>) => void
  update: (fn: (state: AppState) => AppState) => void
  replace: (state: AppState) => void
  setScrubbing: (active: boolean) => void
  navigate: (screen: Screen) => void
  notify: (message: string) => void
  commitEvents: (events: TradeEvent[]) => void
  provider: ProviderRouter
  marketStatus: Record<string, { error?: string; updatedAt?: number }>
  refreshMarket: () => void
  setHistory: (id:string,candles:Candle[]) => void
  openAsset: (asset: Asset) => void
}

const StoreContext = createContext<StoreValue | null>(null)

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState | null>(null)
  const stateRef = useRef<AppState | null>(null)
  const [loadError, setLoadError] = useState('')
  const [ui, setUIState] = useState<UIState>({ screen: 'home', assetId: '', sheet: null, positionId: null, shareKind: 'position', tradeDraft: null, toast: '' })
  const [market, setMarket] = useState<Record<string, Asset>>({})
  const [marketStatus, setMarketStatus] = useState<Record<string, { error?: string; updatedAt?: number }>>({})
  const [refresh, setRefresh] = useState(0)
  const marketRef=useRef(market)
  marketRef.current=market
  const setHistory=useCallback((id:string,candles:Candle[])=>{
    const asset=stateRef.current?.assets.find(a=>a.id===id)
    if(!asset || !candles.length)return
    setMarket(prev=>{
      const older=(prev[id]?.candles??asset.candles).filter(c=>c.timestamp<candles[0].timestamp||c.timestamp>candles.at(-1)!.timestamp)
      const merged=[...new Map([...older,...candles].map(c=>[c.timestamp,c])).values()].sort((a,b)=>a.timestamp-b.timestamp)
      cachePut(`candles:${id}`,merged).catch(()=>{})
      return {...prev,[id]:{...asset,...prev[id],candles:merged}}
    })
  },[])
  const previousAvatarKey=useRef<string|undefined>(undefined)
  const dirty = useRef(false)
  const scrubbing = useRef(false)
  const lastState = useRef<AppState | null>(null)

  const replace = useCallback((candidate: AppState) => {
    // Persist the validated complete snapshot before the visible state swap.
    const next=prepareSetup(candidate,text=>localStorage.setItem(STORAGE_KEY,text))
    scrubbing.current=false;dirty.current=false
    setMarket({});setMarketStatus({});stateRef.current=next;lastState.current=next;setState(next)
    setUIState(s=>({...s,assetId:next.settings.replayAssetId,sheet:null,positionId:null}))
  }, [])
  const setScrubbing=useCallback((active:boolean)=>{scrubbing.current=active},[])
  const update = useCallback((fn: (s: AppState) => AppState) => { if (stateRef.current) { const next=fn(stateRef.current);stateRef.current=next;setState(next) } }, [])
  const setUI = useCallback((patch: Partial<UIState>) => setUIState(prev => ({ ...prev, ...patch })), [])

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      replace(saved ? parseBackup(saved) : makeInitialState())
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : 'Could not read saved setup.')
    }
  }, [replace])

  useEffect(() => {
    if (!state) return
    const controller = new AbortController()
    const remote = state.assets.filter(a => a.source === 'remote')
    const lastAttempt = new Map<string,number>()
    let polling=false
    const poll = async () => {
      if (document.hidden || polling || scrubbing.current) return
      polling=true
      for (const asset of remote) {
        if(controller.signal.aborted) {polling=false;return}
        const interval=ui.screen==='token'&&ui.assetId===asset.id?10000:60000
        if(Date.now()-(lastAttempt.get(asset.id)??0)<interval)continue
        lastAttempt.set(asset.id,Date.now())
        try {
          const data=await marketRequest<Asset>('quote',{address:asset.contractAddress,chain:asset.chain},controller.signal)
          if(controller.signal.aborted) return
          setMarket(prev=>({...prev,[asset.id]:{...asset,...data,manualImageUrl:asset.manualImageUrl,imageRevision:asset.imageRevision,metadataImageUrl:data.metadataImageUrl||asset.metadataImageUrl,candles:prev[asset.id]?.candles ?? asset.candles}}))
          setMarketStatus(prev=>({...prev,[asset.id]:{updatedAt:data.lastQuoteUpdate}}))
        } catch(e) { if(!controller.signal.aborted)setMarketStatus(prev=>({...prev,[asset.id]:{...prev[asset.id],error:e instanceof Error?e.message:'Offline'}})) }
      }
      polling=false
    }
    poll()
    const timer=setInterval(poll, ui.screen === 'token' ? 10000 : 60000)
    const visible=()=>{if(!document.hidden)poll()}
    document.addEventListener('visibilitychange',visible)
    return ()=>{controller.abort();clearInterval(timer);document.removeEventListener('visibilitychange',visible)}
  },[state?.assets,ui.screen,ui.assetId,refresh])

  useEffect(()=>{
    if(!state) return
    let cancelled=false
    for(const asset of state.assets.filter(a=>a.source==='remote')) {
      if(asset.candles.length && refresh===0)continue
      const key=`candles:${asset.id}`
      cacheGet<Candle[]>(key).then(c=>{if(c?.length&&!cancelled&&!marketRef.current[asset.id]?.candles.length)setHistory(asset.id,c)}).catch(()=>{})
      marketRequest<Candle[]>('candles',{address:asset.contractAddress,chain:asset.chain}).then(c=>{
        if(cancelled)return
        setHistory(asset.id,c)
      }).catch(()=>{})
    }
    return ()=>{cancelled=true}
  },[state?.assets,refresh])

  useEffect(()=>{
    const key=state?.profile.avatarKey
    const previous=previousAvatarKey.current;previousAvatarKey.current=key
    if(previous&&previous!==key)setTimeout(()=>{if(stateRef.current?.profile.avatarKey!==previous)cacheDelete(previous).catch(()=>{})},1500)
    if(!key)return
    const temporaryUrl=state?.profile.avatar
    let active=true, url=''
    if(temporaryUrl?.startsWith('blob:')) { url=temporaryUrl;return ()=>URL.revokeObjectURL(url) }
    cacheGet<Blob>(key).then(blob=>{if(blob&&active){url=URL.createObjectURL(blob); update(s=>({...s,profile:{...s.profile,avatar:url}}))}}).catch(()=>{})
    return ()=>{active=false;if(url)URL.revokeObjectURL(url)}
  },[state?.profile.avatarKey,update])

  const flush = useCallback(() => {
    if (!stateRef.current || !dirty.current || scrubbing.current) return
    try {
      localStorage.setItem(STORAGE_KEY, packState({...stateRef.current,assets:stateRef.current.assets.map(a=>mergeMarketAsset(a,marketRef.current[a.id]))}))
      dirty.current = false
    } catch {
      setUI({ toast: 'Could not save on this device. Export your setup in Backstage.' })
    }
  }, [setUI])

  useEffect(() => {
    if (!state) return
    if (lastState.current === state) return
    dirty.current = true
    const previous = lastState.current
    const replayOnly = previous && state.timeline.type === 'replay' && state.timeline.speed !== 0 && (Object.keys(state) as (keyof AppState)[]).every(k => k === 'timeline' || previous[k] === state[k])
    lastState.current = state
    if (replayOnly || scrubbing.current) return
    const timer = setTimeout(flush, 350)
    return () => clearTimeout(timer)
  }, [state, flush])

  useEffect(() => {
    const interval = setInterval(flush, 5000)
    const onHide = () => { if (document.visibilityState === 'hidden') flush() }
    window.addEventListener('pagehide', flush)
    document.addEventListener('visibilitychange', onHide)
    return () => { clearInterval(interval); window.removeEventListener('pagehide', flush); document.removeEventListener('visibilitychange', onHide) }
  }, [flush])

  useEffect(() => {
    const interval = setInterval(() => update(s => {
      if (s.timeline.type !== 'replay' || s.timeline.speed === 0) return s
      const timeline = s.timeline
      const candles = marketRef.current[s.settings.replayAssetId]?.candles ?? s.assets.find(a => a.id === s.settings.replayAssetId)?.candles ?? []
      const next = stepReplay(candles,timeline.timestamp,timeline.speed)
      return { ...s, timeline: { type:'replay', timestamp:next.timestamp, speed:next.speed as typeof timeline.speed } }
    }), 1000)
    return () => clearInterval(interval)
  }, [update])

  useEffect(() => {
    if (!ui.toast) return
    const timer = setTimeout(() => setUI({ toast: '' }), 4000)
    return () => clearTimeout(timer)
  }, [ui.toast, setUI])

  const notify = useCallback((message: string) => setUI({ toast: message }), [setUI])
  const navigate = useCallback((screen: Screen) => { setUI({ screen, sheet: null, tradeDraft: null }); window.scrollTo(0, 0) }, [setUI])
  const commitEvents = useCallback((events: TradeEvent[]) => update(s => {
    const positions = derivePositions(events)
    const cash = validateCash(s.cash, s.tradeEvents, events)
    const next = { ...s, positions, cash, tradeEvents: events, assets:s.assets.map(a=>events.some(e=>e.assetId===a.id)?{...a,transient:false}:a) }
    const snapshot={...next,assets:next.assets.map(a=>mergeMarketAsset(a,marketRef.current[a.id]))}
    const valueUsd=portfolioValue(snapshot)
    next.portfolioHistory = Number.isFinite(valueUsd)?[...s.portfolioHistory, { timestamp: currentTimestamp(snapshot), valueUsd }].slice(-500):s.portfolioHistory
    return next
  }), [update])
  const provider = useMemo(() => state ? new ProviderRouter(state.assets, state.holders) : null, [state?.assets, state?.holders])
  const openAsset = useCallback((asset: Asset) => {
    update(s => ({ ...s, settings:{...s.settings,replayAssetId:asset.id},  assets:s.assets.some(a=>a.id===asset.id) ? s.assets : [...s.assets,{...asset,transient:true}], searchRecents: [{ type: 'asset' as const, id: asset.id }, ...s.searchRecents.filter(r => r.type !== 'asset' || r.id !== asset.id)].slice(0, 20) }))
    setUI({ assetId: asset.id, screen: 'token', sheet: null, positionId: null })
    window.scrollTo(0, 0)
  }, [setUI, update])

  const mergedAssets=useMemo(()=>state?.assets.map(a=>mergeMarketAsset(a,market[a.id])),[state?.assets,market])
  const mergedState=useMemo(()=>state&&mergedAssets?{...state,assets:mergedAssets}:null,[state,mergedAssets])
  if (!state || !provider || !mergedState) return <main className="splash"><img className="splash-mark" src={APP_MARK} alt={APP_NAME} draggable={false} />{loadError ? <div className="splash-recovery"><p>{loadError}</p><p>Your saved data is preserved. Export it before resetting.</p><button className="primary" onClick={() => { const blob = new Blob([localStorage.getItem(STORAGE_KEY) ?? ''], { type: 'application/json' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'fomo-recovery.json'; a.click(); URL.revokeObjectURL(url) }}>Download saved data</button><button onClick={() => { if (confirm('Replace the saved setup with a fresh setup?')) { replace(makeInitialState()); setLoadError('') } }}>Start fresh</button></div> : <span className="splash-loader" />}</main>

  return <StoreContext.Provider value={{ state: mergedState, setHistory, marketStatus, refreshMarket:()=>setRefresh(v=>v+1), ui, setUI, update, replace, setScrubbing, navigate, notify, commitEvents, provider, openAsset }}>{children}</StoreContext.Provider>
}

export function useReplayStore() {
  const value = useContext(StoreContext)
  if (!value) throw new Error('Missing application store')
  return value
}

export function activeTimestamp(state: AppState) { return currentTimestamp(state) }
export function prepareSetup(candidate: AppState, persist: (text:string)=>void): AppState {
  const validated=parseBackup(JSON.stringify({version:2,state:candidate}))
  persist(packState(validated))
  return validated
}
export async function exportPackedState(state: AppState) { const blob=state.profile.avatarKey ? await cacheGet<Blob>(state.profile.avatarKey).catch(()=>undefined) : undefined; return JSON.stringify({ version:2,savedAt:new Date().toISOString(),state:{...state,profile:{...state.profile,avatar:blob?await blobDataUrl(blob):state.profile.avatar,avatarKey:undefined}} }) }
