// Centralized fomo brand constants. Components should import from here
// instead of hardcoding brand name, colors, or asset paths.

export const APP_NAME = 'fomo'
export const APP_SHORT_NAME = 'fomo'
export const APP_TAGLINE = 'Your market. Your timeline.'

/** Transparent white wordmark (marketing / share footer use). No baked-in background. */
export const APP_WORDMARK = '/brand/fomo-wordmark.svg'

/** Transparent white connected-symbol mark for nav, splash, and small badges. No baked-in background. */
export const APP_MARK = '/brand/fomo-mark.svg'

export const BRAND_BLUE = '#4d5fff'
export const APP_BACKGROUND = '#080611'
