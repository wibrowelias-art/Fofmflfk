export const money = (value: number | null, compact = false) => value === null || !Number.isFinite(value) ? 'Unavailable' : new Intl.NumberFormat('en-US', {
  style: 'currency', currency: 'USD', notation: compact ? 'compact' : 'standard', maximumFractionDigits: compact ? 1 : 2,
}).format(value)

export const price = (value: number | null) => value === null || !Number.isFinite(value) ? 'Unavailable' : '$' + new Intl.NumberFormat('en-US', {
  minimumFractionDigits: value >= 1 ? 2 : 0,
  maximumFractionDigits: value >= 1 ? 2 : Math.min(10, Math.max(4, 2 - Math.floor(Math.log10(value || 1)))),
}).format(value)

export const signedMoney = (value: number) => !Number.isFinite(value) ? 'Unavailable' : `${value >= 0 ? '+' : '−'}${money(Math.abs(value))}`
export const percent = (value: number | null) => value === null || !Number.isFinite(value) ? 'Unavailable' : `${value >= 0 ? '▴' : '▾'} ${Math.abs(value).toLocaleString('en-US', { maximumFractionDigits: 2, minimumFractionDigits: 2 })}%`
export const quantity = (value: number) => new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 2 }).format(value)
export const dateTime = (timestamp: number) => new Date(timestamp).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
export function decimal(value: string): number {
  if (!/^\d+(\.\d{0,8})?$/.test(value.trim())) throw new Error('Enter a positive decimal number (up to 8 decimal places).')
  const n = Number(value)
  if (!Number.isFinite(n) || n > 1e12) throw new Error('Amount is too large.')
  return n
}
