import type { Asset } from '@/lib/market/types'
import { makeCandles } from './candles'

export function fixtureAssets(): Asset[] {
  const rows: Array<[string, string, number, number, number, string]> = [
    ['moin', 'Moin', .00106, 1_000_000, 16_769, 'Solana'],
    ['VAULT', 'Vault', .000602, 597_300, 7_558, 'Solana'],
    ['SI', 'Super Inu', .0193, 19_300_000, 29.2, 'Solana'],
    ['NOSH', 'Nosh', .0035, 3_400_000, 98.77, 'Base'],
    ['MARTIANS', 'Martians', .00143, 1_300_000, 26_446, 'Solana'],
    ['ZC', 'Zigcoin', .000547, 546_900, 12_781, 'BNB Chain'],
    ['PAID', 'Paid', .0244, 23_000_000, -44.92, 'Solana'],
    ['CYBERLEEK', 'Cyberleek', .00146, 1_000_000, 26.1, 'Ethereum'],
    ['CASHCAT', 'Cashcat', .169, 168_800_000, -4.18, 'Generic'],
  ]
  return rows.map(([symbol, name, price, cap, change, chain], index) => {
    const id = symbol.toLowerCase()
    const supply = cap / price
    return {
      id,
      symbol,
      name,
      chain,
      contractAddress: `replay:${id}`,
      iconUrl: `/art/${id}.svg`,
      priceUsd: price,
      marketCapUsd: cap,
      fdvUsd: cap * 1.1,
      liquidityUsd: cap * .07,
      volume24hUsd: cap * .2,
      holders: 1600 + 2458 * index,
      priceChange24hPct: change,
      supply,
      verified: index % 3 === 2,
      launchpad: index % 2 ? 'Launch' : undefined,
      category: index % 3 ? 'graduated' as const : 'bonding' as const,
      description: `${name} is a curated fixture asset in Replay. This independent app is for local market roleplay and historical exploration. Prices, people and activity are fictional; no wallets, payments or real trades are connected.`,
      candles: makeCandles(price, 23 + 91 * index, supply, symbol),
    }
  })
}
