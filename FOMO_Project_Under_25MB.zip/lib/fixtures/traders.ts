import type { Trader } from '@/lib/market/types'

export const fixtureTraders: Trader[] = [
  { id: 'lunar', displayName: 'lunardrift', handle: 'lunar', avatar: '/art/trader-0.svg', followers: 1200, pnlUsd: 352637.54, following: true },
  { id: 'atlas', displayName: 'AtlasAfterdark', handle: 'atlas', avatar: '/art/trader-1.svg', followers: 894, pnlUsd: 282624.24, following: false },
  { id: 'orbit', displayName: 'orbitclub', handle: 'orbit', avatar: '/art/trader-2.svg', followers: 27, pnlUsd: 19400, following: false },
  { id: 'nova', displayName: 'novawave', handle: 'nova', avatar: '/art/trader-3.svg', followers: 2, pnlUsd: -1100, following: false },
]
