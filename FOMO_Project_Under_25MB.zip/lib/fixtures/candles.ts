import type { Candle } from '@/lib/market/types'

export const FIXTURE_END = Date.UTC(2026, 8, 28, 0, 0)

type Anchor = [number, number]

interface Regime {
  anchors: Anchor[]
  /** Base per-step noise magnitude, scaled further by local trend steepness. */
  noise: number
  /** Chance [0,1] of an outlier high/low wick on a given candle. */
  spikeChance: number
  spikeMag: number
}

/**
 * Each fixture symbol gets its own deterministic price regime (shape over
 * time), independent of every other symbol. Values are relative multipliers;
 * the final series is rescaled so the last close equals the asset's real
 * fixture price. Do not reuse a shape across symbols.
 */
const REGIMES: Record<string, Regime> = {
  // flat accumulation -> two breakouts -> consolidation
  moin: {
    anchors: [[0, .5], [.28, .52], [.3, .78], [.34, .74], [.5, .8], [.53, 1.25], [.58, 1.15], [.7, 1.22], [.85, 1.18], [1, 1.24]],
    noise: .012, spikeChance: .01, spikeMag: 1.1,
  },
  // sharp launch pump -> crash -> slow recovery
  PAID: {
    anchors: [[0, .1], [.04, 1.55], [.07, 1.35], [.12, .55], [.2, .28], [.35, .22], [.5, .27], [.7, .34], [1, .5]],
    noise: .026, spikeChance: .02, spikeMag: 1.2,
  },
  // volatile staircase trend: plateau, step, plateau, step...
  SI: {
    anchors: [[0, .2], [.12, .2], [.14, .42], [.26, .4], [.28, .62], [.4, .6], [.42, .82], [.55, .8], [.57, 1.02], [.7, 1.0], [.72, 1.2], [1, 1.18]],
    noise: .022, spikeChance: .03, spikeMag: 1.25,
  },
  // range -> breakdown -> V-shaped recovery
  VAULT: {
    anchors: [[0, .72], [.28, .76], [.45, .68], [.5, .22], [.62, .14], [.75, .55], [.88, .82], [1, .9]],
    noise: .016, spikeChance: .015, spikeMag: 1.15,
  },
  // large launch spike -> fade -> slow recovery
  NOSH: {
    anchors: [[0, .15], [.04, 1.8], [.1, 1.1], [.2, .55], [.4, .38], [.6, .34], [.8, .48], [1, .68]],
    noise: .02, spikeChance: .018, spikeMag: 1.2,
  },
  // high volatility with repeated pumps and dumps
  MARTIANS: {
    anchors: [[0, .3], [.1, .72], [.15, .4], [.25, .95], [.3, .5], [.42, 1.15], [.48, .58], [.6, 1.35], [.66, .7], [.8, 1.05], [.9, .78], [1, .9]],
    noise: .03, spikeChance: .035, spikeMag: 1.3,
  },
  // slow decline -> vertical reversal
  CYBERLEEK: {
    anchors: [[0, 1], [.35, .78], [.55, .55], [.75, .3], [.85, .24], [.89, .7], [.93, 1.15], [1, 1.32]],
    noise: .014, spikeChance: .012, spikeMag: 1.1,
  },
  // huge initial run -> long slow distribution
  CASHCAT: {
    anchors: [[0, .1], [.06, 1.4], [.1, 1.9], [.18, 1.55], [.3, 1.25], [.5, .95], [.7, .68], [1, .5]],
    noise: .02, spikeChance: .02, spikeMag: 1.2,
  },
  // mostly sideways with one clean breakout
  ZC: {
    anchors: [[0, .5], [.4, .5], [.68, .52], [.72, .88], [.8, .82], [1, .87]],
    noise: .009, spikeChance: .008, spikeMag: 1.08,
  },
}

const DEFAULT_REGIME: Regime = {
  anchors: [[0, .3], [.3, .45], [.55, .4], [.75, .65], [1, .8]],
  noise: .018, spikeChance: .015, spikeMag: 1.15,
}

export function makeCandles(finalPrice: number, seed: number, supply: number, regimeKey?: string): Candle[] {
  const regime = (regimeKey && REGIMES[regimeKey]) || DEFAULT_REGIME
  const { anchors, noise: noiseScale, spikeChance, spikeMag } = regime

  let rng = seed >>> 0
  const random = () => {
    rng = (Math.imul(1664525, rng) + 1013904223) >>> 0
    return rng / 4294967296
  }
  const round = (n: number) => Number(n.toPrecision(9))

  const count = 2305
  const points: number[] = []
  let drift = 0
  for (let i = 0; i < count; i++) {
    const t = i / (count - 1)
    const idx = Math.max(1, anchors.findIndex(([at]) => at >= t))
    const a = anchors[Math.min(idx - 1, anchors.length - 1)]
    const b = anchors[Math.min(idx, anchors.length - 1)]
    const span = b[0] - a[0] || 1
    const trend = a[1] + (b[1] - a[1]) * ((t - a[0]) / span)
    const steepness = Math.abs(b[1] - a[1]) / span
    drift = .8 * drift + (random() - .5) * noiseScale * (1 + steepness)
    points.push(Math.max(.02, trend + drift))
  }
  const scale = finalPrice / points[count - 1]
  return points.map((point, i) => {
    const close = round(point * scale)
    const open = round((points[i - 1] ?? .98 * point) * scale)
    const spikeUp = random() < spikeChance ? spikeMag : 1
    const spikeDown = random() < spikeChance ? spikeMag : 1
    return {
      timestamp: FIXTURE_END - (count - 1 - i) * 300_000,
      open,
      close,
      high: round(Math.max(open, close) * (1 + .03 * random()) * spikeUp),
      low: round(Math.min(open, close) * (1 - .03 * random()) / spikeDown),
      volume: Math.round(1000 + 38000 * random()),
      marketCapUsd: round(close * supply),
    }
  })
}
