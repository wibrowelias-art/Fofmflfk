export interface TradeEvent {
  note?: string
  id: string
  assetId: string
  side: 'buy' | 'sell'
  timestamp: number
  priceUsd: number
  marketCapUsd: number | null
  units: number
  usdValue: number
}

export interface Position {
  id: string
  assetId: string
  tradeEventIds: string[]
  status: 'open' | 'closed'
  unitsRemaining: number
  totalInvestedUsd: number
  realizedProceedsUsd: number
  weightedAverageEntryUsd: number | null
  weightedAverageExitUsd: number | null
  openedAt: number
  closedAt: number | null
}
