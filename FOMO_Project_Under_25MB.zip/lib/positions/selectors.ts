import type { AppState } from '../store-types'
import type { Position } from './types'
import { cashAt, derivePositions, positionMetrics } from './calculations'
import { calculateFumble } from './fumble'
import { candleAtOrBefore, quoteAt } from '../market/timeline'

const timestampFallbacks = new WeakMap<AppState,number>()
export function selectTimestamp(state: AppState) {
  if(state.timeline.type==='replay')return state.timeline.timestamp
  // Legacy quote-only backups can lack updatedAt. Freeze that fallback for this
  // immutable snapshot so a millisecond boundary cannot turn LIVE into history.
  let fallback=timestampFallbacks.get(state)
  if(fallback===undefined){fallback=Date.now();timestampFallbacks.set(state,fallback)}
  return state.assets.length?Math.max(...state.assets.map(a=>a.source==='remote'?a.lastQuoteUpdate??fallback:a.candles.at(-1)?.timestamp??fallback)):fallback
}

/** Shared accounting projection for detail, profile, Backstage and exported cards. */
function projectPosition(state: AppState, position: Position, timestamp: number) {
  const asset = state.assets.find(a => a.id === position.assetId)
  if (!asset) return null
  const quote = quoteAt(asset,state.timeline.type === 'live' && timestamp === selectTimestamp(state) ? state.timeline : { type:'replay',timestamp,speed:0 },state.settings.overrides[asset.id])
  const events = state.tradeEvents.filter(e => position.tradeEventIds.includes(e.id) && e.timestamp <= timestamp).map(event => {
    const historical = candleAtOrBefore(asset.candles,event.timestamp)
    return {...event,marketCapUsd:event.marketCapUsd ?? historical?.marketCapUsd ?? (asset.source === 'fixture' && asset.supply ? event.priceUsd * asset.supply : null)}
  }).sort((a,b) => a.timestamp-b.timestamp)
  const averageMC = (side: 'buy'|'sell') => {
    const rows=events.filter(e=>e.side===side),units=rows.reduce((n,e)=>n+e.units,0)
    return units && rows.every(e=>e.marketCapUsd!==null) ? rows.reduce((n,e)=>n+e.units*e.marketCapUsd!,0)/units : null
  }
  // Running weighted cost basis allocates realized and remaining cost without
  // changing the engine's authoritative lifetime invested/proceeds/PnL totals.
  let cost=0,units=0,realizedPnl=0
  for(const e of events) { if(e.side==='buy'){cost+=e.usdValue;units+=e.units}else{const soldCost=units?cost*e.units/units:0;realizedPnl+=e.usdValue-soldCost;cost-=soldCost;units=Math.max(0,units-e.units)} }
  const metrics=positionMetrics(position,quote.priceUsd)
  const valueAvailable=!position.unitsRemaining||!quote.unavailable
  return {position,asset,quote,events,metrics:{...metrics,pnlUsd:valueAvailable?metrics.pnlUsd:Number.NaN,pnlPct:valueAvailable?metrics.pnlPct:Number.NaN,currentValue:valueAvailable?metrics.currentValue:Number.NaN},entryMC:averageMC('buy'),exitMC:averageMC('sell'),realizedPnl,unrealizedPnl:valueAvailable?metrics.currentValue-cost:Number.NaN,fumble:quote.unavailable?null:calculateFumble(position,events,quote.priceUsd,timestamp)}
}
export type PositionView = NonNullable<ReturnType<typeof projectPosition>>
const views = new WeakMap<AppState,{timestamp:number;rows:PositionView[]}>()
export function selectPositionViews(state:AppState,timestamp=selectTimestamp(state)):PositionView[] {
  const hit=views.get(state)
  if(hit?.timestamp===timestamp)return hit.rows
  const rows=derivePositions(state.tradeEvents,timestamp).map(p=>projectPosition(state,p,timestamp)).filter((p):p is PositionView=>p!==null)
  views.set(state,{timestamp,rows});return rows
}
export function selectPositionView(state:AppState,positionId:string,timestamp=selectTimestamp(state)) {
  return selectPositionViews(state,timestamp).find(v=>v.position.id===positionId)??null
}
export function selectPortfolioAt(state: AppState,timestamp=selectTimestamp(state),useOverrides=true) {
  const projected=useOverrides?state:{...state,settings:{...state.settings,overrides:{}}}
  const positions=selectPositionViews(projected,timestamp)
  const cash=cashAt(state.cash,state.tradeEvents,timestamp),positionValue=positions.reduce((n,v)=>n+v.metrics.currentValue,0)
  return {timestamp,cash,positionValue,value:cash+positionValue,positions,realizedPnl:positions.reduce((n,v)=>n+v.realizedPnl,0),unrealizedPnl:positions.reduce((n,v)=>n+v.unrealizedPnl,0)}
}
export type PerformanceRange='24h'|'7d'|'30d'|'All'
export function selectProfilePerformance(state:AppState,range:PerformanceRange,timestamp=selectTimestamp(state)) {
  const span=range==='24h'?86400000:range==='7d'?604800000:range==='30d'?2592000000:Infinity
  const earliest=Math.min(timestamp,...state.assets.map(a=>a.candles[0]?.timestamp??timestamp),...state.tradeEvents.map(e=>e.timestamp))
  const start=Math.max(earliest,timestamp-span)
  // Keep this path linear in the event count, rather than constructing all
  // PositionViews for every chart point.
  const valueAt=(time:number,live=false)=>{
    const positions=derivePositions(state.tradeEvents,time)
    return cashAt(state.cash,state.tradeEvents,time)+positions.reduce((sum,p)=>{
      const a=state.assets.find(a=>a.id===p.assetId);if(!a)return sum
      const q=quoteAt(a,live&&state.timeline.type==='live'?state.timeline:{type:'replay',timestamp:time,speed:0},live?state.settings.overrides[a.id]:undefined)
      return p.unitsRemaining&&q.unavailable?NaN:sum+p.unitsRemaining*q.priceUsd
    },0)
  }
  const series=Array.from({length:65},(_,i)=>{const time=start+(timestamp-start)*i/64;return {timestamp:time,valueUsd:valueAt(time,i===64)}})
  const current=series.at(-1)!.valueUsd,previous=series[0].valueUsd
  return {range,start,timestamp,current,previous,pnl:current-previous,series}
}
