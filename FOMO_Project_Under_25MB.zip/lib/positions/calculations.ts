import type { Position, TradeEvent } from './types'

export function derivePositions(events: TradeEvent[], through = Number.POSITIVE_INFINITY): Position[] {
  const positions: Position[] = []
  const openByAsset = new Map<string, Position>()
  const totals = new Map<string, { bought: number; sold: number }>()
  const ids = new Set<string>()
  if (events.some(event=>!Number.isFinite(event.timestamp))) throw new Error('Trade timestamp must be valid.')

  for (const event of events.filter(e => e.timestamp <= through).sort((a, b) => a.timestamp - b.timestamp)) {
    if (!event.id || ids.has(event.id) || !event.assetId || !['buy','sell'].includes(event.side) || !Number.isFinite(event.usdValue) || event.usdValue <= 0) throw new Error('Invalid or duplicate trade event.')
    ids.add(event.id)
    if (event.marketCapUsd !== null && (!Number.isFinite(event.marketCapUsd) || event.marketCapUsd < 0)) throw new Error('Market cap must be nonnegative or unavailable.')
    if (!Number.isFinite(event.units) || event.units <= 0 || !Number.isFinite(event.priceUsd) || event.priceUsd <= 0 || !Number.isFinite(event.timestamp)) {
      throw new Error('Trade price, units and timestamp must be valid.')
    }
    if (Math.abs(event.usdValue - event.units * event.priceUsd) > Math.max(1e-5, 1e-8 * event.usdValue)) {
      throw new Error('Trade amount must equal units × price.')
    }
    let position = openByAsset.get(event.assetId)
    if (!position) {
      if (event.side === 'sell') throw new Error('A sell cannot precede a buy or exceed an open position.')
      position = {
        id: `position-${event.id}`,
        assetId: event.assetId,
        tradeEventIds: [],
        status: 'open',
        unitsRemaining: 0,
        totalInvestedUsd: 0,
        realizedProceedsUsd: 0,
        weightedAverageEntryUsd: null,
        weightedAverageExitUsd: null,
        openedAt: event.timestamp,
        closedAt: null,
      }
      openByAsset.set(event.assetId, position)
      positions.push(position)
      totals.set(position.id, { bought: 0, sold: 0 })
    }
    const sum = totals.get(position.id)!
    position.tradeEventIds.push(event.id)
    if (event.side === 'buy') {
      sum.bought += event.units
      position.unitsRemaining += event.units
      position.totalInvestedUsd += event.units * event.priceUsd
      position.weightedAverageEntryUsd = position.totalInvestedUsd / sum.bought
    } else {
      const epsilon = Math.max(1e-10, 1e-10 * position.unitsRemaining)
      if (event.units > position.unitsRemaining + epsilon) throw new Error('Sell exceeds units available at that time.')
      sum.sold += event.units
      position.realizedProceedsUsd += event.units * event.priceUsd
      position.unitsRemaining = Math.max(0, position.unitsRemaining - event.units)
      if (position.unitsRemaining < epsilon) position.unitsRemaining = 0
      position.weightedAverageExitUsd = position.realizedProceedsUsd / sum.sold
      if (position.unitsRemaining === 0) {
        position.status = 'closed'
        position.closedAt = event.timestamp
        openByAsset.delete(event.assetId)
      }
    }
  }
  return positions
}

export function positionMetrics(position: Position, currentPrice: number) {
  const currentValue = position.unitsRemaining * currentPrice
  const pnlUsd = currentValue + position.realizedProceedsUsd - position.totalInvestedUsd
  return {
    currentValue,
    pnlUsd,
    pnlPct: position.totalInvestedUsd ? (pnlUsd / position.totalInvestedUsd) * 100 : 0,
  }
}

export function cashAt(baseCash: number, events: TradeEvent[], timestamp: number) {
  return events.filter(e => e.timestamp > timestamp).reduce((cash, e) => cash + (e.side === 'buy' ? e.usdValue : -e.usdValue), baseCash)
}

export function profileTradeStats(events:TradeEvent[],timestamp:number) {
  const visible=events.filter(e=>e.timestamp<=timestamp), positions=derivePositions(visible)
  const duration=positions.length?positions.reduce((sum,p)=>sum+Math.max(0,(p.closedAt??timestamp)-p.openedAt),0)/positions.length:0
  const minutes=Math.floor(duration/60000)
  return {count:visible.length,averageHold:positions.length?`${Math.floor(minutes/60)}h ${minutes%60}m`:'—'}
}

export function validateCash(baseCash: number, previous: TradeEvent[], next: TradeEvent[]) {
  if (!Number.isFinite(baseCash) || baseCash < 0) throw new Error('Cash must be finite and nonnegative.')
  let startingCash = baseCash - previous.reduce((sum, e) => sum + (e.side === 'sell' ? e.usdValue : -e.usdValue), 0)
  for (const event of [...next].sort((a, b) => a.timestamp - b.timestamp)) {
    startingCash += event.side === 'sell' ? event.usdValue : -event.usdValue
    if (startingCash < -1e-6) throw new Error('Not enough cash at this point in the timeline. Adjust cash in Backstage.')
  }
  return Math.round(Math.max(0, startingCash) * 1e8) / 1e8
}
