import type { Position, TradeEvent } from './types'

export function calculateFumble(position: Position, trades: TradeEvent[], currentPrice: number, currentTimestamp: number) {
  if (position.status !== 'closed' || position.unitsRemaining !== 0 || position.closedAt === null || currentTimestamp <= position.closedAt || !position.weightedAverageExitUsd || currentPrice <= position.weightedAverageExitUsd) return null
  const sells = trades.filter(t => position.tradeEventIds.includes(t.id) && t.side === 'sell')
  const fullyExitedUnits = sells.reduce((sum, t) => sum + t.units, 0)
  const actualExitProceeds = sells.reduce((sum, t) => sum + t.usdValue, 0)
  const wouldBeWorthNow = fullyExitedUnits * currentPrice
  return {
    fullyExitedUnits,
    actualExitProceeds,
    wouldBeWorthNow,
    missedGain: wouldBeWorthNow - actualExitProceeds,
    fumbleReturnPct: (currentPrice / position.weightedAverageExitUsd - 1) * 100,
    exitMarketCapUsd: sells.every(t => t.marketCapUsd !== null)
      ? sells.reduce((sum, t) => sum + t.units * (t.marketCapUsd ?? 0), 0) / fullyExitedUnits
      : null,
  }
}
