import type { Asset, Holder, Trader } from './market/types'
import type { Position, TradeEvent } from './positions/types'

export type ReplaySpeed = -50 | -10 | -5 | -1 | 0 | 1 | 5 | 10 | 50
export type Timeline = { type: 'live' } | { type: 'replay'; timestamp: number; speed: ReplaySpeed }
export interface QuoteOverride { priceUsd?: number; marketCapUsd?: number }
export interface ProfileState {
  cover?: string
  coverPosition?: number
  avatarPosition?: { x: number; y: number; zoom: number }
  verified?: boolean
  manualStats?: boolean
  avatarKey?: string
  displayName: string
  handle: string
  bio: string
  avatar: string
  followers: number
  following: number
  averageHold: string
  tradeCount: number
  joinedDate: string
}
export interface SearchRecent { type: 'asset' | 'trader'; id: string }
export interface WeeklyTrade { id: string; traderId: string; assetId: string; positionId?: string; pnlUsd: number; pnlPct?: number; enabled?: boolean }
export interface ChartSettings { grid: 'off' | 'sparse' | 'normal'; markers: boolean; compression: boolean; priceLine: boolean; crosshair: boolean; animation: boolean; density: 'comfortable' | 'dense'; marketCapLabels: boolean; eventCount: boolean }
export interface AppearanceSettings { scale: number; gutter: number; navOffset: number; chartHeight: number; rowDensity: 'comfortable' | 'compact'; animations: boolean; reducedMotion: boolean }
export type BackstageTab = 'Overview' | 'Profile' | 'Funds' | 'Tokens' | 'Traders' | 'Weekly' | 'Positions' | 'Replay' | 'Charts' | 'Social' | 'Templates' | 'Data' | 'Appearance' | 'Development'
export interface PortfolioPoint { timestamp: number; valueUsd: number }
export interface ReplaySettings {
  chart?: Partial<ChartSettings>
  appearance?: Partial<AppearanceSettings>
  weeklyMode?: 'auto' | 'manual'
  social?: { showClans: boolean; showFollowers: boolean }
  loadedTemplate?: { id: string; name: string; loadedAt: string; source: string }
  replayAssetId: string
  overrides: Record<string, QuoteOverride>
  chartStyle: 'line' | 'candles'
}
export interface AppState {
  cashAdjustments?: { id: string; recordedAt: number; replayTimestamp: number; mode: 'set'|'add'|'subtract'|'reset'; before: number; after: number }[]
  profile: ProfileState
  cash: number
  assets: Asset[]
  watchlist: string[]
  positions: Position[]
  tradeEvents: TradeEvent[]
  searchRecents: SearchRecent[]
  weeklyTopTrades: WeeklyTrade[]
  traders: Trader[]
  holders: Holder[]
  timeline: Timeline
  portfolioHistory: PortfolioPoint[]
  settings: ReplaySettings
}
