// Session cache: successes are reused across screens; failures expire so a
// temporary CDN outage is recoverable. Explicit Retry clears the asset URLs.
const resolved = new Map<string,string>()
const failed = new Map<string,number>()
export function preferredImage(sources:string[],revision=0) {
  const key=`${revision}:${sources.join('|')}`,hit=resolved.get(key)
  return hit&&sources.includes(hit)&&(failed.get(hit)??0)<Date.now()?hit:sources.find(src=>(failed.get(src)??0)<Date.now())??''
}
export function imageSucceeded(sources:string[],src:string,revision=0) { if(resolved.size>400)resolved.delete(resolved.keys().next().value!);resolved.set(`${revision}:${sources.join('|')}`,src);failed.delete(src) }
export function imageFailed(src:string) {if(failed.size>400)failed.delete(failed.keys().next().value!);failed.set(src,Date.now()+300000)}
export function clearImageCache(sources?:string[]) {if(!sources){resolved.clear();failed.clear();return}sources.forEach(src=>failed.delete(src));for(const [key,src]of resolved)if(sources.includes(src))resolved.delete(key)}
