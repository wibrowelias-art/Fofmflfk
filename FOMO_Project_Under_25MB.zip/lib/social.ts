import type { AppState, WeeklyTrade } from './store-types'
import { selectPositionViews } from './positions/selectors'

export function communityTraders(state: AppState) { return state.traders.filter(t => t.enabled !== false) }
export function weeklyEntries(state: AppState, timestamp: number): WeeklyTrade[] {
  const views = selectPositionViews(state,timestamp), positions=views.map(v=>v.position)
  const traders = communityTraders(state)
  const fromPosition = (id: string, assetId: string) => {
    const view=views.find(v=>v.position.id===id&&v.asset.id===assetId)
    return view&&Number.isFinite(view.metrics.pnlUsd)?view.metrics.pnlUsd:null
  }
  if (state.settings.weeklyMode === 'auto') return positions.flatMap((p,i) => {
    const pnlUsd = fromPosition(p.id,p.assetId)
    const trader = traders.find(t => t.associatedAssets?.includes(p.assetId)) ?? traders[i % traders.length]
    return pnlUsd === null || !trader ? [] : [{ id: p.id, traderId: trader.id, assetId: p.assetId, pnlUsd }]
  }).sort((a,b) => b.pnlUsd-a.pnlUsd).slice(0,12)
  return state.weeklyTopTrades.flatMap(item => {
    if (item.enabled === false || !traders.some(t => t.id === item.traderId) || !state.assets.some(a => a.id === item.assetId)) return []
    const pnlUsd = item.traderId === 'local-practice' && state.settings.weeklyMode !== 'manual' ? fromPosition(item.id,item.assetId) : item.pnlUsd
    return pnlUsd === null ? [] : [{ ...item,pnlUsd }]
  })
}

export function moveItem<T>(items: T[], from: number, to: number) {
  if (from < 0 || from >= items.length || to < 0 || to >= items.length) return items
  const next = [...items], [item] = next.splice(from,1); next.splice(to,0,item); return next
}
