// Large data stays outside the compact localStorage configuration.
export async function database() {
  return new Promise<IDBDatabase>((resolve,reject) => {
    const request = indexedDB.open('fomo-media-market',1)
    request.onupgradeneeded = () => request.result.createObjectStore('cache')
    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result)
  })
}
export async function cachePut(key: string, value: unknown) {
  const db = await database()
  try { await new Promise<void>((resolve,reject) => { const tx = db.transaction('cache','readwrite'); tx.objectStore('cache').put(value,key); tx.oncomplete=()=>resolve(); tx.onerror=()=>reject(tx.error) }) } finally { db.close() }
}
export async function cacheGet<T>(key: string): Promise<T | undefined> {
  const db = await database()
  try { return await new Promise<T | undefined>((resolve,reject) => { const r = db.transaction('cache').objectStore('cache').get(key); r.onsuccess=()=>resolve(r.result as T | undefined); r.onerror=()=>reject(r.error) }) } finally { db.close() }
}
export async function cacheDelete(key: string) {
  const db=await database()
  try { await new Promise<void>((resolve,reject)=>{const tx=db.transaction('cache','readwrite');tx.objectStore('cache').delete(key);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)}) } finally {db.close()}
}
export async function marketCacheInfo(clear=false) {
  const db=await database()
  try{return await new Promise<number>((resolve,reject)=>{const tx=db.transaction('cache',clear?'readwrite':'readonly'),table=tx.objectStore('cache'),request=table.getAllKeys();let count=0;request.onsuccess=()=>{const keys=request.result.filter(k=>typeof k==='string'&&/^(candles:|history-page:|holders:)/.test(k));count=keys.length;if(clear)keys.forEach(k=>table.delete(k))};tx.oncomplete=()=>resolve(count);tx.onerror=()=>reject(tx.error)})}finally{db.close()}
}
export async function blobDataUrl(blob: Blob): Promise<string> { return new Promise((resolve,reject) => { const r = new FileReader(); r.onload=()=>resolve(String(r.result)); r.onerror=()=>reject(r.error); r.readAsDataURL(blob) }) }
export async function prepareAvatar(file: File) {
  if (!['image/jpeg','image/png','image/webp'].includes(file.type)) throw new Error('Choose a JPEG, PNG or WebP image.')
  if (file.size > 30_000_000) throw new Error('Choose an image smaller than 30 MB.')
  const bitmap = await createImageBitmap(file, { imageOrientation:'from-image' })
  const side = Math.min(bitmap.width,bitmap.height)
  const canvas = document.createElement('canvas'); canvas.width=canvas.height=Math.min(512,side)
  const ctx=canvas.getContext('2d'); if (!ctx) throw new Error('Image processing unavailable')
  ctx.drawImage(bitmap,(bitmap.width-side)/2,(bitmap.height-side)/2,side,side,0,0,canvas.width,canvas.height); bitmap.close()
  const blob = await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('Image processing failed')),'image/webp',.82))
  const key = `avatar:${crypto.randomUUID()}`
  try { await cachePut(key,blob); return { avatar:URL.createObjectURL(blob), avatarKey:key } }
  catch { return { avatar:await blobDataUrl(blob), avatarKey:undefined } }
}
