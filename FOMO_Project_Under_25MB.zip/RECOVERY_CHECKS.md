# Recovery checks performed

- All reconstructed `.ts` and `.tsx` files were parsed/transpiled successfully with TypeScript.
- A semantic TypeScript pass over the reconstructed application source completed successfully using local compatibility stubs for external packages.
- Core position math was executed directly and verified for:
  - weighted average entry
  - partial sell remaining open
  - full sell closing the position
  - weighted average exit
  - Fumble calculation after a later higher price
- The exact latest deployed CSS baseline and public art/PWA assets were recovered from the Netlify deploy archive.

A full `pnpm install && pnpm build` could not be executed in the recovery environment because outbound package-registry access was unavailable. The project includes the uploaded lockfile and package manifest so v0/another normal development environment can install and run the real dependency set.
