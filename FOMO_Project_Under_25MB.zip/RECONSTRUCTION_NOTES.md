# Reconstruction notes

This source tree was reconstructed on 2026-09-28 because the only downloadable Netlify artifact available away from the development PC was the compiled deployment output rather than the editable Next.js source.

## Sources used

- the earlier editable `crypto-market-replay-app(1).zip`
- the later project configuration files uploaded after the Codex/Astra refactor
- the latest Netlify deployment bundle and its shipped CSS/assets
- the visible source snippets and implementation progress from the Codex/Astra run
- the current deployed bundle's readable application logic, including its state model, replay logic, position accounting, Backstage controls, chart interactions, position/Fumble sharing, and screen structure

## What is preserved

The reconstruction includes the important behavior visible in the latest deployment:

- Home, Search, Token Detail, Profile, Backstage and Share screens
- local persistent application state
- fixture market provider abstraction
- timestamped OHLC candles and timeframes
- long-press chart selection and draggable selection
- stacked buy/sell event markers
- multiple buys and sells
- weighted average entry and exit
- partial positions and full closing
- replay timeline with pause / 1x / 5x / 10x / 50x
- Fumble calculations
- profile/cash/token/event/replay/data Backstage editors
- import/export/reset setup controls
- position and Fumble share cards
- PWA manifest, icons and service worker from the latest deploy
- the latest deployed public artwork
- the latest deployed visual CSS as a readable source baseline

## Important limitation

This is a best-effort source reconstruction, not a byte-for-byte recovery of the exact unpublished Codex working tree. The Netlify ZIP did not contain `app/`, `components/` or `lib/` source files. The reconstructed source is intentionally organized and editable so another coding/design agent can continue from it.

The fixture token detector remains the same architecture/behavior as the current deployed build. Real contract-address market data was not recoverable because that feature was not actually present in the deployment.
