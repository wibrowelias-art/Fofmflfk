import ReplayApp from '@/components/replay-app'
export default function Page() { return <ReplayApp /> }
