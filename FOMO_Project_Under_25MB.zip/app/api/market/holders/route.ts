import { marketRoute } from '@/lib/market/api'
export async function GET(request: Request) { return marketRoute(request, 'holders') }
