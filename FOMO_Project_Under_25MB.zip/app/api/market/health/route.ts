import { providerHealth } from '@/lib/market/cache'
export const dynamic='force-dynamic'
export function GET() { return Response.json({data:providerHealth()},{headers:{'Cache-Control':'no-store'}}) }
