import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import './globals.css'
import './templates.css'
import './reference-refinements.css'
import './product.css'

export const metadata: Metadata = {
  title: 'fomo — Market Replay',
  description: 'A mobile-first market replay and trading-practice experience.',
  appleWebApp: { capable: true, title: 'fomo', statusBarStyle: 'black-translucent' },
  manifest: '/manifest.webmanifest',
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}
export const viewport: Viewport = { colorScheme: 'dark', themeColor: '#080611' }
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body className="antialiased">{children}{process.env.NODE_ENV === 'production' && process.env.VERCEL === '1' && <Analytics />}</body></html>
}
