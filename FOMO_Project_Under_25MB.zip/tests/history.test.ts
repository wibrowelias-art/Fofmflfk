import test from 'node:test'
import assert from 'node:assert/strict'
import {marketRoute} from '../lib/market/api'
import {normalizeOhlcv} from '../lib/market/normalize'
import {visibleCandles} from '../lib/market/timeline'
test('history cursor passes from route to upstream, with deduped UTC data',async()=>{
 const original=globalThis.fetch,urls:string[]=[]
 const address='0x1111111111111111111111111111111111111111'
 globalThis.fetch=async input=>{const url=String(input);urls.push(url);return Response.json(url.includes('dexscreener')?{pairs:[{chainId:'base',baseToken:{address,name:'History',symbol:'HIST'},priceUsd:'2',pairAddress:'pool-history'}]}:{data:{attributes:{ohlcv_list:[[1700000000,1,3,1,2,4],[1699999940,1,2,1,1.5,5],[1700000000,1,3,1,2,4]]}}})}
 try{const r=await marketRoute(new Request(`https://local.test/api/market/candles?address=${address}&chain=Base&timeframe=1H&before=1700000000123`),'candles');assert.equal(r.status,200);const {data}=await r.json();assert.equal(data.length,2);assert.equal(data[0].timestamp,1699999940000);assert.ok(urls.some(u=>u.includes('before_timestamp=1700000000')));const bad=await marketRoute(new Request(`https://local.test/api/market/candles?address=${address}&chain=Base&before=NaN`),'candles');assert.equal(bad.status,400)}finally{globalThis.fetch=original}
})
test('OHLCV rejects invalid timestamps and inconsistent prices',()=>{assert.equal(normalizeOhlcv({data:{attributes:{ohlcv_list:[[-1,1,3,1,2,0],[1,0,3,0,2,1],[2,1,1,2,3,0]]}}}).length,0)})
test('LIVE and 1H select different real windows',()=>{const candles=Array.from({length:61},(_,i)=>({timestamp:1700000000000+i*60000,open:1,high:2,low:1,close:2}));assert.equal(visibleCandles(candles,'LIVE').length,16);assert.equal(visibleCandles(candles,'1H').length,61)})
