import test from 'node:test'
import assert from 'node:assert/strict'
import {derivePositions,cashAt,validateCash,positionMetrics} from '../lib/positions/calculations'
import {calculateFumble} from '../lib/positions/fumble'
import {fixtureAssets} from '../lib/fixtures/assets'
import {candleAtOrBefore,nearestCandle,quoteAt,stepReplay,visibleCandles} from '../lib/market/timeline'
import {markerLayout,MARKER_GAP} from '../lib/market/markers'
import {parseBackup,makeFixtureState} from '../lib/store'
import type {TradeEvent} from '../lib/positions/types'
const event=(id:string,timestamp:number,side:'buy'|'sell',units:number,priceUsd:number):TradeEvent=>({id,timestamp,side,units,priceUsd,usdValue:units*priceUsd,assetId:'si',marketCapUsd:null})
const events=[event('a',100,'buy',10,2),event('b',200,'buy',20,4),event('c',300,'sell',5,6),event('d',400,'sell',10,8),event('e',500,'sell',15,10)]
test('weighted entry across multiple buys',()=>assert.equal(derivePositions(events,200)[0].weightedAverageEntryUsd,100/30))
test('partial sell remains open',()=>{const p=derivePositions(events,300)[0];assert.equal(p.unitsRemaining,25);assert.equal(p.status,'open')})
test('multiple partial sells and weighted exit',()=>{const p=derivePositions(events,400)[0];assert.equal(p.unitsRemaining,15);assert.equal(p.weightedAverageExitUsd,110/15)})
test('100% close and total metrics',()=>{const p=derivePositions(events)[0];assert.equal(p.status,'closed');assert.equal(p.unitsRemaining,0);assert.equal(p.weightedAverageExitUsd,260/30);assert.equal(positionMetrics(p,12).pnlUsd,160)})
test('oversell rejected',()=>assert.throws(()=>derivePositions([...events,event('bad',600,'sell',1,4)])))
test('nonfinite values and duplicate IDs rejected',()=>{assert.throws(()=>derivePositions([{...events[0],usdValue:NaN}]));assert.throws(()=>derivePositions([events[0],events[0]]))})
test('invalid timestamp and market cap are rejected instead of ignored',()=>{assert.throws(()=>derivePositions([{...events[0],timestamp:NaN}]));assert.throws(()=>derivePositions([{...events[0],marketCapUsd:-1}]))})
test('cash reconstructed in both directions',()=>{const final=validateCash(1000,[],events);assert.equal(final,1160);const times=[0,100,200,300,400,500],cash=[1000,980,900,930,1010,1160];for(const i of [0,1,2,3,4,5,4,3,2,1,0,1,2,3,4,5])assert.equal(cashAt(final,events,times[i]),cash[i])})
test('reverse and forward reconstruct identical positions',()=>{const snapshot=JSON.stringify(events);assert.deepEqual(derivePositions(events,99),[]);assert.equal(derivePositions(events,499)[0].status,'open');const full=derivePositions(events,500);derivePositions(events,99);assert.deepEqual(derivePositions(events,500),full);assert.equal(JSON.stringify(events),snapshot)})
test('fumble disappears before exit',()=>assert.equal(calculateFumble(derivePositions(events,400)[0],events,12,450),null))
test('qualifying fumble',()=>{const f=calculateFumble(derivePositions(events)[0],events,12,600);assert.equal(f?.missedGain,100)})
test('no fumble for lower quote or exit instant',()=>{const p=derivePositions(events)[0];assert.equal(calculateFumble(p,events,8,600),null);assert.equal(calculateFumble(p,events,12,500),null)})
const assets=fixtureAssets(), candles=assets[0].candles
test('fixture regimes remain materially distinct',()=>{for(let i=0;i<assets.length;i++)for(let j=i+1;j<assets.length;j++){const distance=assets[i].candles.reduce((s,c,k)=>s+Math.abs(c.close/assets[i].priceUsd!-assets[j].candles[k].close/assets[j].priceUsd!),0)/candles.length;assert.ok(distance>.05)}})
test('binary search respects historical boundaries',()=>{assert.equal(candleAtOrBefore(candles,candles[0].timestamp-1),undefined);assert.equal(nearestCandle(candles,candles[50].timestamp+1),candles[50]);assert.equal(quoteAt(assets[0],{type:'replay',timestamp:candles[20].timestamp,speed:0}).priceUsd,candles[20].close)})
test('reverse playback clamps and pauses',()=>{assert.equal(stepReplay(candles,candles[2].timestamp,-5).timestamp,candles[0].timestamp);assert.equal(stepReplay(candles,candles[2].timestamp,-5).speed,0);assert.equal(stepReplay(candles,candles[20].timestamp,-5).timestamp,candles[15].timestamp)})
test('timeframes use temporal windows',()=>{assert.ok(visibleCandles(candles,'1H')[0].timestamp>visibleCandles(candles,'7D')[0].timestamp);assert.ok(visibleCandles(candles,'ALL').length<=135)})
test('marker stacking preserves X and avoids overlap',()=>{const es=Array.from({length:8},(_,i)=>event(String(i),candles[10].timestamp,'buy',1,2));const markers=markerLayout(candles,es,t=>(t-candles[0].timestamp)/300000,()=>160,16,308);assert.equal(new Set(markers.map(m=>m.x)).size,1);for(let i=1;i<markers.length;i++)assert.equal(markers[i-1].y-markers[i].y,MARKER_GAP);assert.ok(markers.every(m=>m.y>=28&&m.y<=296))})
test('v1 migration preserves trade history',()=>{const state=makeFixtureState();state.tradeEvents=events;state.cash=1160;const restored=parseBackup(JSON.stringify({version:1,state}));assert.deepEqual(restored.tradeEvents,events);assert.equal(restored.assets[0].source,'fixture')})
test('malformed backup fails safely',()=>{assert.throws(()=>parseBackup('{"version":2,"state":{}}'));const s=makeFixtureState();s.tradeEvents=[{...events[0],assetId:'unknown'}];assert.throws(()=>parseBackup(JSON.stringify({version:2,state:s})))})

test('portfolio does not value remote history using future quote',async()=>{const {portfolioValue}=await import('../lib/store');const s=makeFixtureState();const a=s.assets.find(a=>a.id==='si')!;a.source='remote';a.candles=[];a.lastQuoteUpdate=1000;a.priceUsd=10;s.tradeEvents=[events[0]];s.cash=980;assert.equal(portfolioValue(s),1080);assert.ok(Number.isNaN(portfolioValue(s,500,false)))})
test('datetime-local round trip preserves UTC candle timestamp',()=>{const timestamp=Date.UTC(2026,8,28,14,35);const local=new Date(timestamp-new Date(timestamp).getTimezoneOffset()*60000).toISOString().slice(0,16);assert.equal(new Date(local).getTime(),timestamp)})
