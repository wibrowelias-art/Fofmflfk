import test from 'node:test'
import assert from 'node:assert/strict'
import { makeFixtureState, makeInitialState, mergeMarketAsset, parseBackup } from '../lib/store'
import { tokenChartViewport } from '../lib/market/viewport'
import { quoteAt } from '../lib/market/timeline'
import { selectPositionView, selectPositionViews, selectPortfolioAt, selectProfilePerformance } from '../lib/positions/selectors'
import { imageSources, appearanceDefaults, chartDefaults } from '../lib/customization'
import { preferredImage, imageFailed, imageSucceeded, clearImageCache } from '../lib/image-cache'
import { weeklyEntries } from '../lib/social'
import type { AppState } from '../lib/store-types'
import type { TradeEvent } from '../lib/positions/types'

const start=1700000000000
function setup():AppState {
  const s=makeFixtureState();s.assets=s.assets.slice(0,1);const a=s.assets[0]
  a.source='remote';a.priceUsd=200;a.marketCapUsd=200000;a.lastQuoteUpdate=start+100*3600000
  a.candles=Array.from({length:100},(_,i)=>({timestamp:start+i*3600000,open:10+i,high:12+i,low:9+i,close:11+i,marketCapUsd:(11+i)*1000}))
  s.cash=1000;s.tradeEvents=[];s.positions=[];s.watchlist=[a.id];s.searchRecents=[];s.weeklyTopTrades=[];s.holders=[]
  s.settings.replayAssetId=a.id;return s
}
function event(s:AppState,id:string,side:'buy'|'sell',index:number,units:number):TradeEvent {
  const c=s.assets[0].candles[index];return {id,assetId:s.assets[0].id,side,timestamp:c.timestamp,priceUsd:c.close,units,usdValue:units*c.close,marketCapUsd:null}
}
test('public camera picks the actual rightmost candle, clamps and restores LIVE without mutating state',()=>{
  const s=setup(),before=JSON.stringify(s),a=s.assets[0]
  const v=tokenChartViewport(a.candles,'1D',10.25)
  assert.equal(v.selected.timestamp,a.candles[88].timestamp)
  assert.ok(v.candles.every(c=>c.timestamp<=v.domain.last))
  const q=quoteAt(a,{type:'replay',timestamp:v.selected.timestamp,speed:0})
  assert.equal(q.priceUsd,99);assert.equal(q.marketCapUsd,99000);assert.notEqual(q.priceUsd,a.priceUsd)
  assert.equal(tokenChartViewport(a.candles,'1D',-40).live,true)
  assert.equal(tokenChartViewport(a.candles,'ALL',0).count,100)
  assert.ok(tokenChartViewport(a.candles,'1D',1e6).selected)
  assert.equal(JSON.stringify(s),before)
})
test('unknown historical market cap never uses current supply or current quote',()=>{
  const s=setup();s.assets[0].candles=s.assets[0].candles.map(c=>({...c,marketCapUsd:null}));s.assets[0].supply=999999999
  s.tradeEvents=[event(s,'b','buy',10,10),event(s,'s','sell',30,10)]
  const v=selectPositionView(s,'position-b')!
  assert.equal(v.entryMC,null);assert.equal(v.exitMC,null)
  assert.equal(v.position.weightedAverageEntryUsd,21);assert.equal(v.position.weightedAverageExitUsd,41)
  assert.equal(quoteAt(s.assets[0],{type:'replay',timestamp:start+10*3600000,speed:0}).marketCapUsd,null)
})
test('one projection reconciles partial exits, realized plus unrealized, cash and portfolio',()=>{
  const s=setup();s.tradeEvents=[event(s,'b','buy',10,10),event(s,'b2','buy',20,5),event(s,'s','sell',30,6)]
  const v=selectPositionView(s,'position-b')!,p=selectPortfolioAt(s)
  assert.equal(v.position.unitsRemaining,9)
  assert.ok(Math.abs(v.metrics.pnlUsd-v.realizedPnl-v.unrealizedPnl)<1e-8)
  assert.equal(p.value,p.cash+v.metrics.currentValue)
  assert.equal(selectProfilePerformance(s,'24h').current,p.value)
  assert.equal(selectPositionViews(s),selectPositionViews(s),'immutable-state projections reuse cached rows')
})
test('reversing before exit removes Fumble and future sells from the shared projection',()=>{
  const s=setup();s.tradeEvents=[event(s,'b','buy',10,10),event(s,'s','sell',30,10)]
  assert.ok(selectPositionView(s,'position-b')!.fumble)
  const past={...s,timeline:{type:'replay' as const,timestamp:start+20*3600000,speed:0 as const}}
  const v=selectPositionView(past,'position-b')!
  assert.equal(v.position.status,'open');assert.equal(v.events.length,1);assert.equal(v.fumble,null)
  assert.equal(v.quote.priceUsd,31);assert.equal(selectPortfolioAt(past).cash,590)
})
test('AUTO Weekly uses the shared position result and MANUAL respects visibility and order',()=>{
  const s=setup();s.tradeEvents=[event(s,'b','buy',10,10)];s.settings.weeklyMode='auto'
  assert.equal(weeklyEntries(s,s.assets[0].lastQuoteUpdate!)[0].pnlUsd,selectPositionView(s,'position-b')!.metrics.pnlUsd)
  const manual={...s,settings:{...s.settings,weeklyMode:'manual' as const},weeklyTopTrades:[{id:'x',assetId:s.assets[0].id,traderId:s.traders[0].id,pnlUsd:45},{id:'y',assetId:s.assets[0].id,traderId:s.traders[0].id,pnlUsd:900,enabled:false}]}
  assert.deepEqual(weeklyEntries(manual,Date.now()).map(e=>e.pnlUsd),[45])
})
test('artwork priority, failure cache and explicit retry preserve the manual override',()=>{
  clearImageCache();const a=setup().assets[0];a.manualImageUrl='https://example.com/manual.png';a.iconUrl='https://example.com/provider.png';a.metadataImageUrl='https://example.com/meta.png'
  const sources=imageSources(a);assert.deepEqual(sources,[a.manualImageUrl,a.iconUrl,a.metadataImageUrl])
  assert.equal(preferredImage(sources),a.manualImageUrl);imageFailed(a.manualImageUrl);assert.equal(preferredImage(sources),a.iconUrl)
  imageSucceeded(sources,a.iconUrl);assert.equal(preferredImage(sources),a.iconUrl)
  imageFailed(a.iconUrl);assert.equal(preferredImage(sources),a.metadataImageUrl)
  clearImageCache(sources);assert.equal(preferredImage(sources,1),a.manualImageUrl)
  assert.equal(mergeMarketAsset(a,{...a,manualImageUrl:undefined,imageRevision:0}).manualImageUrl,a.manualImageUrl)
})
test('old v2 backups keep data with safe defaults; new fields roundtrip and invalid imports reject',()=>{
  const s=makeInitialState(),restored=parseBackup(JSON.stringify({version:2,state:s}))
  assert.equal(restored.cash,s.cash);assert.equal({...appearanceDefaults,...restored.settings.appearance}.gutter,16)
  assert.equal({...chartDefaults,...restored.settings.chart}.markers,true)
  s.profile.coverPosition=32;s.cashAdjustments=[{id:'a',recordedAt:start,replayTimestamp:start,mode:'set',before:0,after:20}]
  assert.equal(parseBackup(JSON.stringify({version:2,state:s})).profile.coverPosition,32)
  assert.throws(()=>parseBackup(JSON.stringify({version:2,state:{...s,profile:{...s.profile,coverPosition:200}}})))
  assert.throws(()=>parseBackup(JSON.stringify({version:2,state:{...s,cashAdjustments:[{...s.cashAdjustments![0],after:-1}]}})))
})

test('legacy remote quotes without update timestamps stay LIVE throughout one projection',()=>{
  const s=setup();s.assets[0].lastQuoteUpdate=undefined;s.tradeEvents=[event(s,'b','buy',10,10)]
  const original=Date.now;let clock=start+200*3600000
  Date.now=()=>clock++
  try {assert.equal(selectPositionView(s,'position-b')!.quote.priceUsd,200)} finally {Date.now=original}
})
