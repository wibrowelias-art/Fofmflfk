import test from 'node:test'
import assert from 'node:assert/strict'
import {makeInitialState,makeFixtureState,parseBackup,portfolioValue,activeTimestamp} from '../lib/store'

test('fresh setup contains no automatic market or social fixtures',()=>{
 const state=makeInitialState()
 for(const key of ['assets','watchlist','positions','tradeEvents','searchRecents','weeklyTopTrades','holders','traders'] as const)assert.deepEqual(state[key],[])
 assert.equal(state.cash,0);assert.equal(portfolioValue(state),0);assert.ok(Number.isFinite(activeTimestamp(state)))
 assert.equal(state.settings.replayAssetId,'')
})
test('empty backup survives export/import shape and reload',()=>{
 const state=makeInitialState()
 assert.deepEqual(parseBackup(JSON.stringify({version:2,packed:true,state})),state)
})
test('fixture dataset remains explicit and separate from normal state',()=>{
 const fixture=makeFixtureState();assert.ok(fixture.assets.length>0)
 fixture.assets.pop();assert.deepEqual(makeInitialState().assets,[])
})
test('backup rejects duplicate assets and missing collections',()=>{
 const state=makeFixtureState();state.assets.push(state.assets[0]);assert.throws(()=>parseBackup(JSON.stringify({version:2,state})))
 const bad={...makeInitialState(),watchlist:null};assert.throws(()=>parseBackup(JSON.stringify({version:2,state:bad})))
})
