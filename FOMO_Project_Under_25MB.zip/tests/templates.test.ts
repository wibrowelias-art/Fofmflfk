import test from 'node:test'
import assert from 'node:assert/strict'
import { makeInitialState, parseBackup, prepareSetup, portfolioValue } from '../lib/store'
import { templates, createCandidate, summarize, buildTemplate } from '../lib/templates'
import { templateAssets } from '../qa/template-fixtures'
import { derivePositions, cashAt, profileTradeStats } from '../lib/positions/calculations'
import { calculateFumble } from '../lib/positions/fumble'
import { quoteAt, visibleCandles } from '../lib/market/timeline'
import { markerLayout, MARKER_GAP } from '../lib/market/markers'
import { normalizeDiscovery } from '../lib/market/providers/discovery'

for(const def of templates)test(`${def.name}: schema, accounting, counts and roundtrip`,()=>{
  const current=makeInitialState();current.profile.displayName='Preserved';current.profile.bio='A bio';current.settings.chartStyle='line'
  const state=createCandidate(def,current,templateAssets(),'Controlled QA response'), totals=summarize(state)
  assert.equal(totals.assets,def.assets);assert.equal(totals.events,def.events);assert.equal(totals.open,def.open);assert.equal(totals.closed,def.closed);assert.equal(totals.cash,def.startingCash)
  assert.equal(state.profile.displayName,'Preserved');assert.equal(state.profile.bio,'A bio');assert.equal(state.settings.chartStyle,'line')
  const restored=prepareSetup(state,text=>{assert.deepEqual(summarize(parseBackup(text)),totals)})
  assert.deepEqual(restored.positions,derivePositions(state.tradeEvents));assert.deepEqual(restored.assets[0]?.candles,state.assets[0]?.candles)
  if(state.tradeEvents.length){const timestamp=state.tradeEvents[0].timestamp-1;assert.equal(derivePositions(state.tradeEvents,timestamp).length,0);assert.equal(profileTradeStats(state.tradeEvents,timestamp).count,0);assert.equal(portfolioValue({...state,timeline:{type:'replay',timestamp,speed:0}},timestamp,false),cashAt(state.cash,state.tradeEvents,timestamp))}
})
test('Fumble uses the normal engine and disappears before exit',()=>{
  const state=createCandidate(templates.find(d=>d.id==='fumble')!,makeInitialState(),templateAssets(),'QA')
  assert.equal(state.positions.filter(p=>calculateFumble(p,state.tradeEvents,3.2,Date.now())).length,3)
  for(const p of state.positions){const timestamp=p.closedAt!-1;const historical=derivePositions(state.tradeEvents,timestamp).find(v=>v.id===p.id)!;assert.equal(calculateFumble(historical,state.tradeEvents,3.2,timestamp),null)}
})
test('failed discovery and failed persistence leave the original setup intact',async()=>{
  const state=makeInitialState();state.cash=42;const before=JSON.stringify(state)
  await assert.rejects(buildTemplate(templates[0],state,{discovery:async()=>{throw Error('offline')},resolve:async a=>a,candles:async a=>a.candles}),/offline/)
  assert.throws(()=>prepareSetup(createCandidate(templates.find(d=>d.id==='clean')!,state,[],'QA'),()=>{throw Error('quota')}),/quota/)
  assert.equal(JSON.stringify(state),before)
})
test('one failed token is skipped; insufficient history does not create fake candles',async()=>{
  const assets=templateAssets(), current=makeInitialState()
  const result=await buildTemplate(templates.find(d=>d.id==='trending')!,current,{discovery:async()=>({assets,source:'QA',updatedAt:Date.now()}),resolve:async a=>{if(a===assets[0])throw Error('missing');return a},candles:async()=>[]})
  assert.equal(result.warnings.length,1);assert.equal(result.state.assets.length,12)
  await assert.rejects(buildTemplate(templates[0],current,{discovery:async()=>({assets:assets.map(a=>({...a,candles:[]})),source:'QA',updatedAt:Date.now()}),resolve:async a=>a,candles:async()=>[]}),/valid tokens/)
})
test('manual overrides never leak into historical price or market cap',()=>{
  const asset=templateAssets()[0],timestamp=asset.candles[20].timestamp
  assert.deepEqual(quoteAt(asset,{type:'replay',timestamp,speed:0},{priceUsd:999,marketCapUsd:999}),quoteAt(asset,{type:'replay',timestamp,speed:0}))
})
test('aggregated first-candle events stay visible; columns preserve X and avoid neighbors',()=>{
  const asset=templateAssets()[0],candles=visibleCandles(asset.candles,'ALL'),first=candles[0]
  const events=Array.from({length:18},(_,i)=>({id:`m${i}`,assetId:asset.id,side:'buy' as const,timestamp:i<9?first.timestamp:candles[1].timestamp,priceUsd:2,units:1,usdValue:2,marketCapUsd:null}))
  const layout=markerLayout(candles,events,t=>(t-first.timestamp)/3600000*20+15,()=>100,16,308)
  for(const p of layout){assert.equal(p.x,p.event.timestamp===first.timestamp?15:35);assert.ok(p.y>=28&&p.y<=82)}
  assert.equal(layout.reduce((count,p)=>count+1+p.overflow,0),events.length)
  for(const [i,a] of layout.entries())for(const b of layout.slice(i+1))assert.ok(Math.abs(a.x-b.x)>=MARKER_GAP||Math.abs(a.y-b.y)>=MARKER_GAP)
  const aggregated=visibleCandles([...asset.candles,...asset.candles.map(c=>({...c,timestamp:c.timestamp+100*3600000}))],'ALL')
  assert.ok(markerLayout(aggregated,[events[0]],()=>15,()=>100,16,308).length)
})
test('discovery filters unsupported networks and deduplicates exact base tokens',()=>{
  const address='0x1111111111111111111111111111111111111111',pool={id:'base_pool',attributes:{address,base_token_price_usd:'1'},relationships:{network:{data:{id:'base'}},base_token:{data:{id:'base_token'}}}}
  const data=normalizeDiscovery({data:[pool,pool,{...pool,relationships:{...pool.relationships,network:{data:{id:'unsupported'}}}}],included:[{id:'base_token',attributes:{address,name:'Actual metadata',symbol:'ACT'}}]},123)
  assert.equal(data.assets.length,1);assert.equal(data.assets[0].priceUsd,1);assert.equal(data.assets[0].marketCapUsd,null);assert.equal(data.updatedAt,123)
})
