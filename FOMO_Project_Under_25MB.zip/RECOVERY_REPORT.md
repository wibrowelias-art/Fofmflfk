# Fomo Replay — source audit and implementation report

Verified 30 September 2026. The authoritative project is `C:\Users\elias\Desktop\Fomo-Source`, extracted separately from the user-supplied editable archive `6abc2ecc12e1e86b93078732-d1fde8c334c566ef.zip`.

Original editable archive SHA-256: `6341d6c120013703d7493f137896a80cc33503d431a9db3b79e93f1ad597835d`.

The compiled deployment recovery remains separate in `C:\Users\elias\Desktop\Fomo-Recovery`: `original-deploy`, `recovered-source`, and `DEPLOY_INVENTORY.csv`. It was not used as the new codebase. No further minified-bundle reconstruction was performed after the editable source arrived. The user's four attached specifications were adopted as implementation requirements after their explicit confirmation; historical assertions in those documents were checked against the recovered source.

## Audit before feature work

Read the editable source, its Next.js agent guidance, `RECONSTRUCTION_NOTES.md`, `RECOVERY_CHECKS.md`, provider implementations, API routes, accounting engine, persistence, and existing tests. The historical notes describe an earlier recovery lineage; they are not an accurate inventory of all current provider capabilities.

Required baseline, before feature edits: `pnpm install --frozen-lockfile`, `pnpm typecheck`, `pnpm test` (37 passed), and `pnpm build` all passed. The app was then run and inspected. The editable package and lockfile were retained.

## A–R status

| Item | Result |
| --- | --- |
| **A. Original source in Netlify archive** | The earlier compiled deployment archive did not supply this editable project. The later user-supplied source ZIP does contain editable Next.js routes, components, providers, tests, and assets. It is now authoritative. This does not establish that it is the unpublished source of the native Fomo product. |
| **B. Exact recovery** | All 374 original non-directory archive entries remain present locally. SHA-256 comparison: 279 identical, 95 modified, zero missing. These counts include historical QA screenshots and generated build/test metadata. All `public/` assets, `package.json`, `pnpm-lock.yaml`, `tsconfig.json`, `next.config.mjs`, `netlify.toml`, the five API route wrappers, and `lib/market/providers/dex.ts` remain byte-identical. See `qa/source-comparison.json` for every entry. |
| **C. Reconstruction** | The earlier experiment is preserved separately. Current changes are typed edits and additions to the recovered editable source. No reconstructed route/component tree replaced the recovered implementation. New work adds Templates, actual discovery, accounting-derived demo histories, replay/persistence corrections, and measured visual refinements. |
| **D. Market providers** | Preserved DEX metadata/quotes, Pons/Blockscout metadata and holders, GeckoTerminal historical OHLCV, provider routing, bounded server caches, cooldowns, and pagination. Added supported-network trending pool discovery, Robinhood OHLCV, and an optional authenticated Blockscout holder fallback. No wallet or transaction provider was added. |
| **E. Home** | Empty state, tracked tokens, filters, watchlist, portfolio balance, Deposit entry and Weekly Top Trades work. Local template weekly results derive from events and the selected time. Real Rich Demo production capture shows roughly $1.62 million total practice value, including $550,555.55 cash; current quotes continue to change. |
| **F. Token Detail** | Exact-contract metadata, artwork where available, current quotes, historical candles, timeframes, older-history cursor, favorites, tracking, tabs, chart controls, positions, and replay remain usable. Missing historical market cap remains unknown. Robinhood holders currently depend on blocked upstream access; other networks retain the source's original holder coverage. |
| **G. Profile** | Cash, open/closed positions and performance derive from the accounting engine. Portfolio at T uses `cashAt(T) + sum(unitsAt(T) × quoteAt(T))`. Trade count and average holding time derive from events. Identity, uploaded avatar, bio and existing profile controls are retained. Nonfinite unavailable valuation points are excluded from saved history. |
| **H. Replay/scrub** | Pointer scrubbing updates quotes, chart and positions while held; release commits once. Forward/reverse speeds, single steps, clamping, pause and Jump Live remain. Historical quotes ignore current manual overrides. Instrumented browser check confirms no persistence writes or extra market requests during the held pointer moves. |
| **I. Backstage** | Profile, Funds, Tokens, Positions, Replay, Data and Development sections preserved. Event editing/deletion still validates chronological holdings and cash. Export, Import and Reset remain alongside Templates. Complete compact backup retains real candle history; replacement persists successfully before swapping in-memory state. |
| **J. Templates** | All seven presets implemented, including optional Portfolio Showcase. Cards open a preview, preparation leaves existing data intact, exact loaded collections/counts are shown, existing data requires overwrite confirmation, and Export current setup first/Cancel are available. Loaded badge survives reload. All seven passed both controlled browser checks and read-only preparation against actual providers. |
| **K. Tracking/Search** | Empty-install contract discovery, Auto Detect, metadata preview, open, Track token, favorite, reload, export/import and removal retained. Supported source networks remain Solana, Ethereum, Base, BNB Chain and Robinhood Chain. Chain/address identity controls matching; symbol equality does not merge distinct tokens. |
| **L. Positions/Fumble** | Existing weighted entries/exits, partial sells and full exits retained. Fumble uses fully exited units and weighted exit against the selected quote; it disappears before exit. Share exports retain visible `Replay · Learning` and omit referral advertising. Markers keep the displayed candle's X and stack only vertically, with bounded overflow counts; trade timestamps are unchanged. |
| **M. PWA** | Existing branding, manifest, icons, standalone metadata and service worker retained. Final production browser check passed online load, registration, reload and offline shell reload without runtime, console or network errors. Static cache is bounded and does not intercept market APIs. Physical iOS/Android installation was not tested; real market data still requires network access. |
| **N. Typecheck** | `pnpm typecheck`: passed. Production build's TypeScript check also passed after the final avatar and chart corrections. |
| **O. Unit tests** | `pnpm test`: **51 passed**, zero failed. Includes template schema/counts/accounting, backup round trips, error preservation, real-data normalization, Blockscout holder normalization, first aggregated candle markers and historical override isolation. |
| **P. E2E** | **14 deterministic Playwright tests passed** after the final avatar and chart corrections. Two original live-provider tests were run earlier and remain failing because Robinhood holder data cannot be retrieved in this environment. They were retained, not changed into fixture passes. See provider details below. |
| **Q. Production build** | Final `pnpm build`: passed with Next.js 16.3.3, all five dynamic market routes included. `ignoreBuildErrors` is not enabled. Production is running locally on port 3001. |
| **R. Screenshot differences** | Two measured refinement passes completed, followed by final avatar loading correction. The layout, dark surfaces, blue/orange cards, chart dots, marker colors, profile overlap and floating navigation follow supplied references. Native phone status bars, screenshot-detection notices, native-only exact typography, original community identities/rankings and referral ads are not copied. The Deposit sheet describes local practice funds. Live artwork can be unavailable and then falls back to initials. This is an independent practice app, not a pixel-identical native product or a verified wallet portfolio. |

## Template contents and real-data provenance

| Template | Local cash | Tracked tokens | TradeEvents | Open | Closed |
| --- | ---: | ---: | ---: | ---: | ---: |
| Rich Demo | $550,555.55 | 12 | 80 | 8 | 4 |
| Trending Tokens | $0 | 12 | 0 | 0 | 0 |
| Active Trader | $75,000 | 7 | 32 | 5 | 2 |
| Fumble Showcase | $50,000 | 4 | 12 | 0 | 4 |
| Chart Stress Test | $100,000 | 2 | 48 | 2 | 0 |
| Clean Start | $0 | 0 | 0 | 0 | 0 |
| Portfolio Showcase | $250,000 | 7 | 28 | 7 | 0 |

The UI labels the discovery source **GeckoTerminal · trending market pools**. It does not assert that these are trending on Fomo. Discovery queries the provider at preparation time and filters its actual ranking to supported networks. Trading presets can reuse currently tracked real tokens and their cached historical candles. The opt-in integration run similarly reused previously fetched actual candle history and refreshed discovery/metadata; it used no controlled fixtures.

Trade prices and timestamps come from historical OHLCV. Unknown historical market cap stays null. Cash amounts are final local practice balances; historical funding is reconstructed by the existing `cashAt` engine. Trade sizes may be reduced to keep chronology solvent. Rich Demo also includes three later historical entries so steep declines in older markets do not leave a cash-only-looking portfolio. No final PnL or Fumble dollar amount is hardcoded.

Rich Demo includes wins, losses, a qualifying closed Fumble, repeated buys, partial exits, full exits, dense buy/sell columns and a buy/partial sell/buy/partial sell/full exit sequence. Fumble Showcase has three qualifying closed examples and one nonqualifying example, checked by the normal engine. Stress uses 12 buys and 12 partial sells per token on shared and adjacent candles. All saved performance points are engine-derived.

If metadata, history or required scenarios cannot be obtained, the preview reports the failure and keeps the original setup. Provider cooldowns are paced and cancellable. No production template injects synthetic candles. `qa/template-fixtures.ts` is used only by deterministic tests.

Preview and loading tests cover every template through Home, Token Detail, Profile, Open/Closed, Replay, Share/Fumble where applicable, browser reload, and switching to the next template. Cancellation, provider failure and storage quota failure preserve the previous saved setup.

## Provider access limitation

The original live tests `exact QA address resolves via real local API` and `real contract discovery in Search and Backstage` resolve the PONS QA contract and obtain its quote, but fail when they require actual holder rows. Observed upstream conditions:

- `api.ponsportal.fun` requests time out (`UND_ERR_CONNECT_TIMEOUT`).
- The public Robinhood Blockscout instance returns HTTP 403 with an access challenge.
- The Blockscout PRO endpoint returns HTTP 402 without its required API key.

No challenge was bypassed and no holder rows were invented. The existing server-side `BLOCKSCOUT_API_KEY` option was preserved and extended to holder pagination. That authenticated fallback has normalization unit coverage but could not be verified live without a configured credential. Blockscout documents its current instance/PRO API distinction in [its official API guide](https://docs.blockscout.com/devs/apis).

The complete live suite therefore must not be described as fully passing. The final deterministic command was:

```powershell
pnpm exec playwright test --grep-invert 'exact QA address|real contract discovery'
```

The two live tests remain in `e2e/app.spec.ts` and should be rerun when upstream holder access is available. Read-only quotes, trending discovery and historical candle preparation were successfully verified separately.

## Visual verification and evidence

All major screens and Backstage tabs were checked at **375×812, 390×844, 393×852, 412×915 and 430×932**. Position, Share, Fumble, Deposit, dense buy/sell columns, chart pill bounds, navigation and sheet overflow were exercised. Keyboard replay steps and direct profile editing are included in the regression suite.

First refinement: compact profile header/metadata, avatar overlap, position metrics/share surface hierarchy and consistent colors. Second refinement: deposit sheet hierarchy/backdrop, bounded price/metadata alignment, stable weekly card height, safe sheet scrolling and chart marker bounds. Final corrections hide pending artwork and reserve bounded chart headroom so marker columns remain above the displayed candle's wick; dense overflow uses counts instead of extending below candles. The browser test checks this relation against the actual rendered candle geometry.

Shared measurements include a 16 px page gutter, floating navigation at the existing safe-bottom offset with 60 px height, 28 px upper sheet corners, a 66 px profile avatar with 30 px cover overlap, 24 px token marker diameter and 27 px vertical spacing. Same displayed candle retains the exact X; neighboring columns use vacant Y slots and bounded overflow indicators.

Evidence files in `qa/`:

- `source-comparison.json`: per-entry original/current SHA-256 inventory.
- `live-template-results.json` and `live-template-*.json`: actual-provider preparation results and local practice backups.
- `current-live-rich-audit.json`: production demo, 80 events, 8 open/4 closed, approximately $1.62m total value at prepared quotes, no browser runtime errors.
- `current-live-rich-{home,profile,data}-390.png`: actual-provider-backed production screenshots.
- `current-template-preview-390.png`: complete browser preview test using clearly labeled controlled QA data.
- `current-marker-buys-position-390.png`, `current-marker-sells-position-*.png`: dense chart geometry at requested sizes.
- `current-final-*.png`, `final-*-{375,390,393,412,430}.png`, `current-compare-*.jpg`: current application renders and supplied-reference comparisons. Historical `pass*` files came with the archive; use the `current-*`/fresh `final-*` evidence for this implementation.
- `audit-*.json`: browser runtime, console and request observations per E2E case, including the live holder failure.
- `production-audit.json`, `production-offline.png`: final production PWA/offline shell verification.

## Delivery

The updated editable archive excludes dependencies, build output, browser binaries, generated test reports and environment files. It retains source, providers, public assets, unit/E2E tests, QA evidence, lockfile and deployment configuration. The local source retains original generated files for audit purposes; see the archive inventory for packaging details.

`officialfomo.netlify.app` has **not** been redeployed. Publishing the edited source is a separate action; the provided compiled deploy ZIP should not be drag-dropped as a replacement for this source-based Next.js project. Use the preserved source build settings and a server-capable Netlify Next.js deployment when publishing.
