# Fomo Replay — editable source handoff

## Authoritative workspace

Use `C:\Users\elias\Desktop\Fomo-Source`. It comes from `C:\Users\elias\Downloads\6abc2ecc12e1e86b93078732-d1fde8c334c566ef.zip`. Do not continue reconstructing bundles. The prior compiled-deploy experiment is preserved in `C:\Users\elias\Desktop\Fomo-Recovery` and should stay separate.

`RECONSTRUCTION_NOTES.md` and `RECOVERY_CHECKS.md` are historical archive files. Read `RECOVERY_REPORT.md` for the current capabilities and validation. This is a local replay/practice app. Keep `Replay · Learning` visible on generated exported cards.

## Run

Node 24.19 and pnpm 12.3.4 were used. The package and lockfile are unchanged.

```powershell
cd C:\Users\elias\Desktop\Fomo-Source
pnpm install --frozen-lockfile
pnpm typecheck
pnpm test
pnpm build
pnpm start --port 3001
```

Development: `pnpm dev` (port 3000). The delivered local production preview is `http://127.0.0.1:3001`. The agent-created preview tab contains the actual-provider Rich Demo; unrelated browser origins remain independent. A fresh browser starts at $0 with no assets.

Open Profile → settings → Data → Templates, or hold the portfolio balance to enter Backstage. Choose a template, Prepare preview, review counts/source, optionally export your old setup, confirm replacement if needed, and Load template. Market-backed previews can take minutes when providers require pacing. Cancel stays available. Clean Start clears practice/market data while preserving identity and chart style.

## What changed

- `lib/templates/`: typed definitions and candidate construction for Rich, Trending, Active Trader, Fumble, Stress, Clean and Portfolio Showcase. Uses normal trade/accounting/Fumble calculations; no hardcoded PnL or chart.
- `components/replay/templates-browser.tsx`, `app/templates.css`: template cards, preview, exact summary, progress, warnings, overwrite confirmation, optional export, cancel, persistent badge.
- `lib/market/providers/discovery.ts`: actual supported-network GeckoTerminal trending pools and bounded current discovery cache. Source label never says “Trending on Fomo”.
- `lib/market/api.ts`, `providers/historical.ts`: discovery branch, validated pool hint and Robinhood OHLCV. Five recovered API route wrappers remain unchanged.
- `lib/market/providers/server-router.ts`, `router.ts`: fresh discovery fallback and reuse of recently fetched real history. Original DEX/Pons routing retained; failed requests are not replaced with fixture data.
- `lib/store.tsx`: atomic persisted replacement, complete candle backup, stronger validation, merged market snapshots for saved history, finite valuation guard and scrub/write/poll separation.
- `components/replay/replay-dock.tsx`, `lib/market/timeline.ts`: visible state updates during a held drag, single commit on finish, historical override isolation, aggregate bucket start.
- `lib/market/markers.ts`, `chart.tsx`, `trade-marker.tsx`: exact candle X, Y-only stacking above the displayed candle's wick, bounded headroom, neighboring-column spacing and overflow counts. The accounting engine's event timestamps are unchanged.
- `lib/positions/calculations.ts`, Profile/Home/social components: derived profile statistics and local-practice results at the selected time. Existing weighted accounting behavior retained.
- `components/replay/sheets.tsx`: actual-symbol quantities, token navigation/controls, share layout and practice Deposit sheet hierarchy. Existing Position/Fumble export flow retained.
- `app/reference-refinements.css`, `common.tsx`: mobile reference refinements and clean avatar fallback while remote artwork loads.
- `lib/market/providers/pons.ts`, `normalize.ts`, `cache.ts`: optional server-key holder fallback with true decimals/cursors and explicit provider access errors.

The source comparison lists all modified original entries. Public assets, package/lockfile, core configuration and DEX provider remain exact. New files include the Templates module, discovery provider, styles and QA/tests. No directory from the compiled reconstruction replaced the source tree.

## Validation

Baseline before edits: install/typecheck/37 unit tests/build passed, then app inspected.

Final: typecheck passed; 51 unit tests passed; build passed; 14 deterministic E2E tests passed after final avatar and marker refinements. All seven template preparations also passed against actual metadata/history. Production PWA offline shell test passed with no runtime/console/network errors. Five requested mobile sizes are covered. Physical mobile installation was not exercised.

```powershell
pnpm exec playwright install chromium
pnpm exec playwright test
```

The full suite includes two real-network tests which currently fail at Robinhood holder access. To reproduce the passing deterministic regression separately:

```powershell
pnpm exec playwright test --grep-invert 'exact QA address|real contract discovery'
```

In this workspace the downloaded official Chromium is cached under `.cache/playwright`; set `PLAYWRIGHT_BROWSERS_PATH` to that absolute directory if reusing it. It is excluded from the deliverable ZIP. The E2E webServer launches `pnpm dev` on port 3000 and reuses an existing server. Production tests expect port 3001.

Opt-in actual-provider checks:

```powershell
# Start pnpm dev on port 3000 first.
pnpm exec tsx qa/live-template-check.ts --all
# Start the production build on port 3001 first.
pnpm exec tsx qa/capture-live-demo.ts
node qa/production-check.cjs
```

`live-template-check.ts` queries current discovery and metadata; it can reuse saved actual candle history from its prior QA artifact, as the app can reuse tracked real history. It does not modify browser state. The generated backups are local practice events on real market candles, not verified holdings. `capture-live-demo.ts` uses an isolated browser and the actual generated backup; it does not mock API responses. Controlled `qa/template-fixtures.ts` is imported only by tests.

## Provider limitation to retain in reports

PONS QA contract: `0x39dbed3a2bd333467115de45665cc57f813c4571` on Robinhood Chain. Exact discovery and quote work. Pons holder API times out; the public Blockscout instance blocks API requests; PRO requires a server API key. The optional `BLOCKSCOUT_API_KEY` fallback is implemented and unit tested but unverified live here. Keep the credential server-side and out of backups/source control. Do not bypass upstream challenges or fabricate holders. Retain the two original failing integration tests.

No real wallet, deposit, payment, financial execution or externally verified ownership is involved. Current quotes can change after preparation. Missing historical market cap remains null. A preview can legitimately fail if provider history cannot construct its required scenario; cancellation/failure must preserve existing saved data.

## UI evidence

See current production screenshots `qa/current-live-rich-*.png`; dense marker screenshots `qa/current-marker-*.png`; reference comparisons `qa/current-compare-*.jpg`; template preview and each-template captures `qa/current-template-*.png`; and the final mobile matrix `qa/final-*.png`. `qa/audit-*.json` contains runtime/request observations. Use current evidence, not the original archive's historical `pass*` screenshots.

Known differences: native phone chrome and font, public profiles/rankings, provider-dependent artwork, and intentionally explicit local practice deposit wording. Referral advertising remains removed. This source is not asserted to be a pixel-identical or official native Fomo client.

## Deployment status

The live `https://officialfomo.netlify.app` site has not been changed. `netlify.toml` still uses `pnpm run build` with `.next`; use a normal source-based Next.js deployment with its server/API support. Do not upload the source archive as if it were static compiled HTML, and do not merge files from the prior reconstructed bundle tree.
