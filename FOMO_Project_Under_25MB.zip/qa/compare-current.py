"""Create labeled QA comparisons from the user's exact references and app renders.

This does not modify either input image. References are normalized to a 390 px
width and retain their aspect ratios; native phone chrome remains visible.
"""
from pathlib import Path
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parent
references = Path('C:/Users/elias/Downloads')
pairs = {
    'home': ('09_09_49 PM.jpg', 'current-final-home.png'),
    'search': ('09_10_14 PM.jpg', 'current-final-search.png'),
    'profile': ('09_10_08 PM.jpg', 'current-final-profile.png'),
    'leaderboard': ('09_10_11 PM.jpg', 'current-final-leaderboard.png'),
    'token': ('09_09_35 PM.jpg', 'current-final-token.png'),
    'deposit': ('09_09_44 PM.jpg', 'current-final-deposit.png'),
    'position-share': ('09_09_27 PM.jpg', 'current-final-share.png'),
    'fumble': ('09_09_31 PM.jpg', 'current-final-fumble.png'),
    'marker-buys': ('09_09_38 PM.jpg', 'current-marker-buys-position-390.png'),
    'marker-sells': ('09_09_41 PM.jpg', 'current-marker-sells-position-390.png'),
}
for name, (reference, current) in pairs.items():
    images = [Image.open(references / f'ChatGPT Image Sep 30, 2026, {reference}').convert('RGB'), Image.open(root / current).convert('RGB')]
    resized = [im.resize((390, round(im.height * 390 / im.width)), Image.Resampling.LANCZOS) for im in images]
    canvas = Image.new('RGB', (800, 32 + max(im.height for im in resized)), '#15121f')
    draw = ImageDraw.Draw(canvas)
    draw.text((10, 8), 'Supplied reference (scaled to 390 px)', fill='white')
    draw.text((410, 8), 'Current app (390 x 844 browser)', fill='white')
    for x, im in zip((5, 405), resized):
        canvas.paste(im, (x, 32))
    canvas.save(root / f'current-compare-{name}.jpg', quality=90)
print(f'Created {len(pairs)} comparisons')
