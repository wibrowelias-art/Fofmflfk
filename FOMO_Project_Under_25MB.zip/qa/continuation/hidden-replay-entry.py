from pathlib import Path
r=Path(__file__).resolve().parents[2]
p=r/'components/replay/token.tsx';s=p.read_text(encoding='utf-8');target='''<button onClick={()=>{setOptionsOpen(false);setUI({screen:'backstage',backstageTab:'Replay',sheet:null})}}>Open replay <span>↶</span></button>''';assert target in s;s=s.replace(target,'');p.write_text(s,encoding='utf-8')
old="await page.getByRole('button',{name:'Chart options'}).click();await page.getByRole('button',{name:'Open replay',exact:false}).click()"
new="await page.getByRole('button',{name:'Back',exact:true}).click();await page.getByRole('button',{name:'Portfolio balance. Hold to open Backstage',exact:true}).press('Enter');await page.getByRole('tab',{name:'Replay',exact:true}).click()"
for p in (r/'e2e').glob('*.ts'):
 s=p.read_text(encoding='utf-8')
 if old in s:p.write_text(s.replace(old,new),encoding='utf-8')
p=r/'components/replay/share.tsx';s=p.read_text(encoding='utf-8').replace("isFumble ? 'Fumble' : metrics.pnlUsd >= 0 ? 'Profit' : 'Loss'", "isFumble ? 'Fumble' : !Number.isFinite(metrics.pnlUsd)?'Unavailable':metrics.pnlUsd >= 0 ? 'Profit' : 'Loss'")
s=s.replace("`${metrics.pnlUsd >= 0 ? '+' : '−'}${money(Math.abs(metrics.pnlUsd))}`","Number.isFinite(metrics.pnlUsd)?`${metrics.pnlUsd >= 0 ? '+' : '−'}${money(Math.abs(metrics.pnlUsd))}`:'Unavailable'")
p.write_text(s,encoding='utf-8')
