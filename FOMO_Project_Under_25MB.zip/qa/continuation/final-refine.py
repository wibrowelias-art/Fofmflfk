from pathlib import Path
r=Path.cwd()
p=r/'components/replay/share.tsx';s=p.read_text(encoding='utf-8').replace('chartHeight={isFumble?225:145}','chartHeight={150}');p.write_text(s,encoding='utf-8')
p=r/'components/replay/backstage/positions.tsx';s=p.read_text(encoding='utf-8').replace('Hold a token chart to add an entry.','Create a practice buy or open Backstage Replay to choose a historical entry.');p.write_text(s,encoding='utf-8')
p=r/'components/replay/token.tsx';s=p.read_text(encoding='utf-8').replace("quote.unavailable?'—'","quote.unavailable?'Unavailable'").replace("asset.supply===undefined?'—'","asset.supply===undefined?'Unavailable'").replace("??'—'","??'Unavailable'").replace("dateTime(asset.pairCreatedAt):'—'","dateTime(asset.pairCreatedAt):'Unavailable'");p.write_text(s,encoding='utf-8')
p=r/'components/replay/backstage.tsx';s=p.read_text(encoding='utf-8').replace("{block:'nearest',inline:'nearest'}", "{block:'nearest',inline:'nearest',behavior:state.settings.appearance?.reducedMotion||state.settings.appearance?.animations===false||matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'}");p.write_text(s,encoding='utf-8')
p=r/'public/sw.js';s=p.read_text(encoding='utf-8').replace('replay-shell-v4','replay-shell-v5');p.write_text(s,encoding='utf-8')
