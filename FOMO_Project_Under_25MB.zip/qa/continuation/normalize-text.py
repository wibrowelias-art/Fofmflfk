from pathlib import Path
r=Path.cwd()
for folder in ['app','components','lib']:
 for p in (r/folder).rglob('*'):
  if not p.is_file():continue
  try:p.read_bytes().decode('utf-8')
  except UnicodeDecodeError:
   s=p.read_bytes().decode('utf-8','surrogateescape')
   s=''.join(bytes([ord(c)-0xdc00]).decode('cp1252') if 0xdc80<=ord(c)<=0xdcff else c for c in s)
   p.write_text(s,encoding='utf-8');print('Normalized UTF-8:',p.name)
p=r/'lib/customization.ts'
s=p.read_text(encoding='utf-8').replace('!bool(t.enabled)||!finite(t.pnlPct) || !range(t.rank,1,100000)','!bool(t.enabled)||!finite(t.pnlPct)')
p.write_text(s,encoding='utf-8')
