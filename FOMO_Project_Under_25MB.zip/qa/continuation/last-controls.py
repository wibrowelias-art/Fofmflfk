from pathlib import Path
r=Path.cwd()
p=r/'components/replay/backstage/weekly.tsx';s=p.read_text(encoding='utf-8').replace("import { moveItem, weeklyEntries }", "import { selectPositionViews } from '@/lib/positions/selectors'\nimport { moveItem, weeklyEntries }")
s=s.replace('      <div className="form-grid">', '''      <Picker label={`Weekly position ${i+1}`} value={item.positionId??''} options={[{value:'',label:'Custom displayed result'},...selectPositionViews(state).filter(v=>v.asset.id===item.assetId).map(v=>({value:v.position.id,label:`${v.position.status} · ${new Date(v.position.openedAt).toLocaleDateString()}`}))]} onChange={positionId=>{const view=selectPositionViews(state).find(v=>v.position.id===positionId);update(s=>({...s,weeklyTopTrades:s.weeklyTopTrades.map(w=>w.id===item.id?{...w,positionId:positionId||undefined,...(view?{pnlUsd:view.metrics.pnlUsd,pnlPct:view.metrics.pnlPct}:{})}:w)}))}}/>
      <div className="form-grid">''').replace('{...w,assetId}:w','{...w,assetId,positionId:undefined}:w')
p.write_text(s,encoding='utf-8')
p=r/'components/replay/backstage/tokens.tsx';s=p.read_text(encoding='utf-8').replace('[["Market cap",money(a.marketCapUsd,true)]','[["Market cap",money(a.marketCapUsd,true)],["FDV",money(a.fdvUsd,true)]');p.write_text(s,encoding='utf-8')
p=r/'e2e/product-completion.spec.ts';s=p.read_text(encoding='utf-8').replace('money(v.metrics.pnlUsd)', 'money(Math.abs(v.metrics.pnlUsd))');p.write_text(s,encoding='utf-8')
