from pathlib import Path
r=Path(__file__).resolve().parents[2]
p=r/'components/replay/chart.tsx';s=p.read_text(encoding='utf-8')
s=s.replace('  onTrade,\n','').replace("  onTrade?: (side: 'buy' | 'sell', candle: Candle) => void\n",'')
s=s.replace("import { nearestCandle, lowerBound }", "import { lowerBound }")
for line in ["  const holdRef = useRef<ReturnType<typeof setTimeout> | null>(null)\n","  const dragging = useRef(false)\n","  const [selected, setSelected] = useState<Candle | null>(null)\n","  const [draftSide, setDraftSide] = useState<'buy' | 'sell' | null>(null)\n","  useEffect(() => () => { if (holdRef.current) clearTimeout(holdRef.current) }, [])\n"]:s=s.replace(line,'')
start=s.index('  const selectable=');end=s.index('  const finishGesture=',start);s=s[:start]+s[end:]
s=s.replace(';clearHold();dragging.current=false','')
s=s.replace('<div className={`chart-wrap ${selected ? \'selecting\' : \'\'}`}>','<div className="chart-wrap">')
s=s.replace("role={onTrade||pan||scrub ? 'slider' : 'img'}","role={pan||scrub ? 'slider' : 'img'}").replace('onTrade||pan||scrub','pan||scrub')
s=s.replace(":onTrade ? 'Price chart. Hold to select a candle; arrow keys move; Enter opens trade options.' : 'Price history'",": 'Price history'")
s=s.replace('selected?.timestamp ?? scale.last','cursor?.timestamp ?? scale.last')
s=s.replace('      aria-valuetext={selected ? `${dateTime(selected.timestamp)} ${price(selected.close)}` : undefined}\n','')
start=s.index('      onContextMenu=');end=s.index('      onPointerMove=',start)
s=s[:start]+'''      onPointerDown={e => {if(pan||scrub){startRef.current={x:e.clientX,y:e.clientY};gesture.current='pending';pan?.begin();scrub?.begin()}}}
'''+s[end:]
start=s.index('        if (!onTrade) return',s.index('      onPointerMove='));end=s.index('      }}',start);s=s[:start]+s[end:]
start=s.index('        if (!onTrade) return',s.index('      onKeyDown='));end=s.index('      }}',start);s=s[:start]+s[end:]
start=s.index('      {selected && <g');end=s.index('    </svg>',start);s=s[:start]+s[end:]
start=s.index('    {selected && onTrade');end=s.index('  </div>',start);s=s[:start]+s[end:]
p.write_text(s,encoding='utf-8')
p=r/'components/replay/home-search.tsx';s=p.read_text(encoding='utf-8').replace("import { derivePositions, positionMetrics } from '@/lib/positions/calculations'","import { selectProfilePerformance } from '@/lib/positions/selectors'")
s=s.replace('  const current = useMemo(() => portfolioValue(state, timestamp), [state, timestamp])\n  const previous = useMemo(() => portfolioValue(state, timestamp - 86_400_000, false), [state, timestamp])',"  const {current,previous} = useMemo(() => selectProfilePerformance(state,'24h',timestamp), [state, timestamp])")
p.write_text(s,encoding='utf-8')
p=r/'components/replay/token.tsx';s=p.read_text(encoding='utf-8').replace('const positions=derivePositions(state.tradeEvents,globalReplayTimestamp).filter(p=>p.assetId===asset.id)','const positions=useMemo(()=>derivePositions(state.tradeEvents,globalReplayTimestamp).filter(p=>p.assetId===asset.id),[state.tradeEvents,globalReplayTimestamp,asset.id])').replace('const availableCash=cashAt(state.cash,state.tradeEvents,globalReplayTimestamp)','const availableCash=useMemo(()=>cashAt(state.cash,state.tradeEvents,globalReplayTimestamp),[state.cash,state.tradeEvents,globalReplayTimestamp])');p.write_text(s,encoding='utf-8')
p=r/'e2e/product-completion.spec.ts';s=p.read_text(encoding='utf-8').replace("page.getByRole('alert')","page.locator('.backstage-panel .form-error')").replace("page.locator('.position-value')).toContainText", "page.locator('.position-sheet .position-value')).toContainText");p.write_text(s,encoding='utf-8')
print('Removed unused chart hold/trade-popup implementation; shared Home performance and memoized public accounting.')
