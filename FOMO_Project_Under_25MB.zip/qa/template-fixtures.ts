// Controlled historical market responses for QA only. Never imported by the app.
import type { Asset } from '../lib/market/types'
export function templateAssets():Asset[] {
  const start=Date.now()-120*3600000
  return Array.from({length:18},(_,index)=>{
    const candles=Array.from({length:100},(_,i)=>{const close=2+Math.sin(i/8)+i*.009;return {timestamp:start+i*3600000,open:close*.99,high:close*1.03,low:close*.97,close,marketCapUsd:null}})
    return {id:`base:0x${(index+1).toString(16).padStart(40,'0')}`,source:'remote',chainId:'8453',chain:'Base',contractAddress:`0x${(index+1).toString(16).padStart(40,'0')}`,name:index===0?'A long token name for mobile layout':'Controlled market '+index,symbol:'QA'+index,iconUrl:'/art/si.svg',provider:'Controlled QA response',priceUsd:3.2,marketCapUsd:null,fdvUsd:null,liquidityUsd:null,volume24hUsd:null,holders:null,priceChange24hPct:null,lastQuoteUpdate:Date.now(),candles}
  })
}
