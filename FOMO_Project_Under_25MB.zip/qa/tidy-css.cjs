const fs=require('fs'),postcss=require('postcss');
const path='app/globals.css',root=postcss.parse(fs.readFileSync(path,'utf8'));let removed=0;
// Only remove declarations overridden by the exact same selector in the same
// conditional scope; preserve rule order, shorthand interactions and media rules.
function prune(container){const seen=new Set();for(const node of [...container.nodes].reverse()){
 if(node.type==='atrule'&&node.nodes)prune(node);
 if(node.type!=='rule')continue;
 for(const declaration of [...node.nodes].reverse())if(declaration.type==='decl'){
  const key=node.selector+'|'+declaration.prop+'|'+Boolean(declaration.important);
  if(seen.has(key)){declaration.remove();removed++}else seen.add(key);
 }
 if(!node.nodes.length)node.remove();
}}
prune(root);
function format(container,depth=0){for(const node of container.nodes){node.raws.before='\n'+'  '.repeat(depth);if(node.type==='decl'){node.raws.between=': ';}if(node.nodes){node.raws.between=' ';node.raws.after='\n'+'  '.repeat(depth);node.raws.semicolon=true;format(node,depth+1)}}}
format(root);fs.writeFileSync(path,root.toString().trim()+'\n');console.log(`Removed ${removed} superseded CSS declarations.`);
