"""Compare editable source with the preserved pre-interruption source delivery."""
from pathlib import Path
import zipfile, hashlib, json
root=Path(__file__).resolve().parents[1]
archive=root.parent/'Fomo-Source-Updated.zip'
report=root/'qa'/'continuation'
report.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
    previous={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
    prefix=next((n[:-len('package.json')] for n in previous if n.endswith('package.json')), '')
    previous={n[len(prefix):]:data for n,data in previous.items() if n.startswith(prefix)}
    changes=[]
    for folder in ['app','components','lib','e2e','tests']:
        for p in sorted((root/folder).rglob('*')):
            if not p.is_file(): continue
            name=p.relative_to(root).as_posix(); data=p.read_bytes()
            if previous.get(name)!=data:
                changes.append({'file':name,'status':'added' if name not in previous else 'modified','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    (report/'interrupted-files.json').write_text(json.dumps(changes,indent=2),encoding='utf-8')
    print(f'{len(changes)} changed source/test files compared with {archive.name}; inventory saved.')
