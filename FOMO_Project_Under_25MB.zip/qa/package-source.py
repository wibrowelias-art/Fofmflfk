"""Package editable source and QA evidence, excluding generated runtimes/secrets.

Run from the project: python qa/package-source.py
Writes a ZIP and external SHA-256 inventory in the parent Desktop directory.
"""
import hashlib
import json
import os
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
destination = root.parent / 'Fomo-Source-Updated.zip'
manifest = root.parent / 'Fomo-Source-Updated.manifest.json'
excluded = {'node_modules', '.next', '.cache', '.git', 'playwright-report', 'test-results', '__pycache__'}
files = []
for directory, subdirectories, names in os.walk(root):
    subdirectories[:] = [name for name in subdirectories if name not in excluded]
    for name in names:
        if name.startswith('.env') or name.endswith(('.tsbuildinfo', '.pyc')):
            continue
        path = Path(directory) / name
        if path.is_symlink():
            continue
        files.append(path)
rows = []
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(files):
        relative = path.relative_to(root).as_posix()
        archive.write(path, f'Fomo-Source/{relative}')
        rows.append({'path': relative, 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
with zipfile.ZipFile(destination) as archive:
    bad_entry = archive.testzip()
    if bad_entry:
        raise ValueError(f'ZIP integrity failed: {bad_entry}')
result = {'archive': str(destination), 'bytes': destination.stat().st_size, 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'fileCount': len(rows), 'excludedDirectories': sorted(excluded), 'excludesEnvironmentFiles': True, 'files': rows}
manifest.write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({key: value for key, value in result.items() if key != 'files'}, indent=2))
