// Opt-in, read-only integration check. Writes a local QA artifact, never app state.
import {writeFile,readFile} from 'node:fs/promises'
import {buildTemplate,templates,summarize} from '../lib/templates'
import {makeInitialState} from '../lib/store'
import type {Asset,Candle} from '../lib/market/types'
import type {Discovery} from '../lib/market/providers/discovery'
import type {TemplateMarket} from '../lib/templates/types'
const request=async<T>(kind:string,params:Record<string,string>):Promise<T>=>{const r=await fetch(`http://127.0.0.1:3000/api/market/${kind}?${new URLSearchParams(params)}`);const body=await r.json();if(!r.ok||body.error)throw new Error(body.error?.message??'Unavailable');return body.data}
const history=new Map<string,Candle[]>(),resolved=new Map<string,Asset>();let nextHistory=0
const market:TemplateMarket={discovery:async()=>{for(let attempt=0;;attempt++){try{return await request<Discovery>('search',{discovery:'trending'})}catch(error){if(attempt===1||!(error instanceof Error)||!/rate limit|budget|cooling/i.test(error.message))throw error;console.log('Discovery cooldown · retry in 65 seconds');await new Promise(r=>setTimeout(r,65000))}}},resolve:async a=>{if(resolved.has(a.id))return resolved.get(a.id)!;const r=await request<Asset>('resolve',{address:a.contractAddress,chain:a.chain});resolved.set(a.id,r);return r},candles:async a=>{if(history.has(a.id))return history.get(a.id)!;if(Date.now()<nextHistory)await new Promise(r=>setTimeout(r,nextHistory-Date.now()));nextHistory=Date.now()+8000;for(let attempt=0;;attempt++){try{const c=await request<Candle[]>('candles',{address:a.contractAddress,chain:a.chain,timeframe:'ALL',...(a.poolAddress?{pool:a.poolAddress}:{})});history.set(a.id,c);return c}catch(error){if(attempt===1||!(error instanceof Error)||!/rate limit|budget|cooling/i.test(error.message))throw error;console.log('Provider cooldown · retry in 65 seconds');await new Promise(r=>setTimeout(r,65000))}}}}
async function main(){
const current=makeInitialState()
try{current.assets=JSON.parse(await readFile('qa/live-template-rich.json','utf8')).state.assets}catch{}
const results:unknown[]=[]
for(const def of templates.filter(d=>process.argv.includes('--all')||['trending','rich'].includes(d.id))){try{const candidate=await buildTemplate(def,current,market,text=>console.log(`${def.name}: ${text}`));results.push({id:def.id,status:'passed',source:candidate.source,summary:summarize(candidate.state),warnings:candidate.warnings});await writeFile(`qa/live-template-${def.id}.json`,JSON.stringify({version:2,state:candidate.state},null,2));console.log(`${def.name}: PASSED`)}catch(error){results.push({id:def.id,status:'unavailable',error:error instanceof Error?error.message:String(error)});console.log(`${def.name}: UNAVAILABLE`)}}
await writeFile('qa/live-template-results.json',JSON.stringify({checkedAt:new Date().toISOString(),results},null,2))
}
main().catch(error=>{console.error(error);process.exitCode=1})
