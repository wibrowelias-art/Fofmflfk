// Opt-in production screenshot check using the actual provider-backed template
// prepared by live-template-check.ts. This runner never mocks market responses.
import { chromium, expect } from '@playwright/test'
import { readFile, writeFile } from 'node:fs/promises'
import { derivePositions } from '../lib/positions/calculations'
import { portfolioValue } from '../lib/store'

async function main() {
  const backup = JSON.parse(await readFile('qa/live-template-rich.json', 'utf8'))
  const browser = await chromium.launch({headless:true})
  const context = await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,serviceWorkers:'block'})
  await context.addInitScript(value => {
    if (!localStorage.getItem('replay:setup:v1')) localStorage.setItem('replay:setup:v1',JSON.stringify(value))
  }, backup)
  const page = await context.newPage(), errors:string[] = [], network:string[] = []
  page.on('pageerror', e => errors.push(e.message))
  page.on('response', r => {if(r.status()>=400)network.push(`${r.status()} ${r.url()}`)})
  try {
    await page.goto('http://localhost:3001')
    await expect(page.locator('.token-row')).toHaveCount(12)
    await page.waitForTimeout(2000)
    await page.screenshot({path:'qa/current-live-rich-home-390.png',animations:'disabled'})
    await page.getByRole('button',{name:'Profile',exact:true}).click()
    await expect(page.getByRole('heading',{name:'Positions (12)',exact:true})).toBeVisible()
    await page.screenshot({path:'qa/current-live-rich-profile-390.png',animations:'disabled'})
    await page.getByRole('button',{name:'Profile settings'}).click()
    await page.getByRole('tab',{name:'Data',exact:true}).click()
    await expect(page.locator('.loaded-template')).toContainText('Rich Demo')
    await page.screenshot({path:'qa/current-live-rich-data-390.png',animations:'disabled'})
    const state=backup.state, positions=derivePositions(state.tradeEvents)
    const result={checkedAt:new Date().toISOString(),source:state.settings.loadedTemplate.source,cash:state.cash,portfolioAtPreparedQuotes:portfolioValue(state,Date.now(),true),assets:state.assets.length,events:state.tradeEvents.length,open:positions.filter(p=>p.status==='open').length,closed:positions.filter(p=>p.status==='closed').length,errors,network}
    await writeFile('qa/current-live-rich-audit.json',JSON.stringify(result,null,2))
    console.log(JSON.stringify(result,null,2))
    expect(errors,'Production browser runtime errors').toEqual([])
  } finally {await browser.close()}
}
main().catch(error=>{console.error(error);process.exitCode=1})
