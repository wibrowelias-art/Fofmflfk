"""Build labeled QA comparisons without modifying any reference or screenshot."""
from pathlib import Path
import sys
from PIL import Image, ImageDraw
root=Path(__file__).resolve().parents[1]
stage=sys.argv[1] if len(sys.argv)>1 else 'continuation-pass1'
target=root/'qa'/'master-pass'/stage
refs={'home':'09_09_49','search':'09_10_14','token':'09_10_01','profile':'09_10_08','open-position':'09_09_38','position-share':'09_09_27','fumble':'09_09_31'}
for name,stamp in refs.items():
    files=[root.parent.parent/'Downloads'/f'ChatGPT Image Sep 30, 2026, {stamp} PM.jpg',root/'qa/master-pass/continuation-baseline'/f'{name}-390.png',target/f'{name}-390.png']
    canvas=Image.new('RGB',(1170,884),'#171421');draw=ImageDraw.Draw(canvas)
    for i,(p,label) in enumerate(zip(files,['SUPPLIED REFERENCE','INTERRUPTED BASELINE',stage.upper()])):
        im=Image.open(p).convert('RGB');im.thumbnail((390,844))
        canvas.paste(im,(i*390+(390-im.width)//2,40));draw.text((i*390+12,12),label,fill='white')
    canvas.save(target/f'compare-{name}.jpg')
print('Saved seven side-by-side reference comparisons.')
