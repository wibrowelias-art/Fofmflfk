"""Compare original editable archive entries with the authoritative workspace.

Usage: python qa/compare-source.py C:/path/to/original.zip
No archive code is executed. No original files are removed or modified.
"""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
rows = []
with zipfile.ZipFile(sys.argv[1]) as archive:
    for entry in archive.infolist():
        if entry.is_dir():
            continue
        destination = (root / entry.filename).resolve()
        if not destination.is_relative_to(root):
            raise ValueError(f"Archive entry outside workspace: {entry.filename}")
        original = hashlib.sha256(archive.read(entry)).hexdigest()
        current = hashlib.sha256(destination.read_bytes()).hexdigest() if destination.is_file() else None
        rows.append({"path": entry.filename, "status": "missing" if current is None else "identical" if original == current else "modified", "originalSha256": original, "currentSha256": current})
(root / 'qa/source-comparison.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
counts = {status: sum(row['status'] == status for row in rows) for status in ('identical', 'modified', 'missing')}
print(json.dumps(counts))
print('Modified source/configuration files:')
for row in rows:
    if row['status'] == 'modified' and not row['path'].startswith('qa/'):
        print(row['path'])
