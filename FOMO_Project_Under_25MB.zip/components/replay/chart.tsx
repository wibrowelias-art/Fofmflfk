'use client'

import { useEffect, useId, useMemo, useRef, useState } from 'react'
import { Activity, CandlestickChart, SlidersHorizontal } from 'lucide-react'
import type { Candle, ChartTimeframe } from '@/lib/market/types'
import type { TradeEvent } from '@/lib/positions/types'
import { markerLayout, MARKER_GAP } from '@/lib/market/markers'
import type { ChartSettings } from '@/lib/store-types'
import { chartDefaults } from '@/lib/customization'
import { TradeMarker } from './trade-marker'
import { lowerBound } from '@/lib/market/timeline'
import { dateTime, money, price } from '@/lib/formatting/numbers'

export function PriceChart({
  candles,
  rawCandles = candles,
  events,
  currentPrice,
  style = 'candles',
  showMarkers = true,
  chartHeight = 330,
  showQuote = true,
  settings: preferences, domain, pan, scrub, cursor, smallMarkers = false, marketCap, interactiveMarkers = true,
}: {
  candles: Candle[]
  rawCandles?: Candle[]
  events: TradeEvent[]
  currentPrice: number
  style?: 'candles' | 'line'
  showMarkers?: boolean
  chartHeight?: number
  showQuote?: boolean
  settings?: Partial<ChartSettings>
  domain?: { first: number; last: number }
  pan?: { begin:()=>void; move:(fraction:number)=>void; finish:()=>void }
  scrub?: { begin:()=>void; move:(fraction:number)=>void; finish:()=>void }
  cursor?: {timestamp:number;price:number}
  marketCap?: number|null
  smallMarkers?: boolean
  interactiveMarkers?: boolean
}) {
  const settings={...chartDefaults,...preferences}
  showMarkers=showMarkers&&settings.markers;showQuote=showQuote&&settings.priceLine
  const [inspected,setInspected]=useState<TradeEvent[]>([])
  const gesture=useRef<'pending'|'horizontal'|'vertical'|null>(null)
  const uid = useId().replace(/:/g, '')
  const svgRef = useRef<SVGSVGElement | null>(null)
  const startRef = useRef({ x: 0, y: 0 })


  // Reserve bounded headroom for visible marker columns. The candle domain
  // stays real; changing the plot scale never changes event timestamps/prices.
  const CHART_W = 390
  const CHART_H = chartHeight
  const PLOT_LEFT = 15
  const pillWidth = Math.max(56, Math.min(104, price(currentPrice).length * 6.4 + 18))
  const PLOT_RIGHT = showQuote ? pillWidth + 18 : 15
  const PLOT_TOP = useMemo(()=>{
    if(!showMarkers||!candles.length)return 16
    const first=candles[0].startTimestamp??candles[0].timestamp,last=candles.at(-1)!.timestamp,counts=new Map<number,number>()
    for(const event of events){if(event.timestamp<first||event.timestamp>last)continue;const index=Math.min(candles.length-1,lowerBound(candles,event.timestamp));counts.set(index,(counts.get(index)??0)+1)}
    const tallest=Math.max(0,...counts.values())
    return tallest?Math.max(16,Math.min(CHART_H*.25,26+(Math.min(tallest,settings.compression?4:tallest)-1)*(smallMarkers?19:MARKER_GAP))):16
  },[candles,events,showMarkers,CHART_H,settings.compression,smallMarkers])
  const PLOT_BOTTOM = 22

  const scale = useMemo(() => {
    const first = domain?.first ?? candles[0]?.timestamp ?? 0
    const last = domain?.last ?? candles.at(-1)?.timestamp ?? 1
    const rawLow = Math.min(...candles.map(c => c.low), ...(showQuote ? [currentPrice] : []))
    const rawHigh = Math.max(...candles.map(c => c.high), ...(showQuote ? [currentPrice] : []))
    const verticalPad = Math.max((rawHigh - rawLow) * 0.14, rawHigh * 0.015, 1e-10)
    const low = rawLow - verticalPad
    const high = rawHigh + verticalPad
    const span = Math.max(high - low, 1e-10)
    const plotWidth = CHART_W - PLOT_LEFT - PLOT_RIGHT
    const plotHeight = CHART_H - PLOT_TOP - PLOT_BOTTOM
    return {
      x: (timestamp: number) => PLOT_LEFT + ((timestamp - first) / Math.max(last - first, 1)) * plotWidth,
      y: (value: number) => PLOT_TOP + (1 - (value - low) / span) * plotHeight,
      first, last, low, high,
    }
  }, [candles, currentPrice, PLOT_RIGHT, PLOT_TOP, CHART_H, showQuote,domain?.first,domain?.last])

  const markerPositions = useMemo(() => markerLayout(candles,events,scale.x,scale.y,16,CHART_H-PLOT_BOTTOM,{compression:settings.compression,small:smallMarkers}),[candles,events,scale,CHART_H,settings.compression,smallMarkers])
  const finishGesture=()=>{if(gesture.current==='horizontal')pan?.finish();if(gesture.current)scrub?.finish();gesture.current=null}
  const fraction=(clientX:number)=>{const rect=svgRef.current!.getBoundingClientRect();return Math.max(0,Math.min(1,(clientX-rect.left-rect.width*PLOT_LEFT/CHART_W)/(rect.width*(CHART_W-PLOT_LEFT-PLOT_RIGHT)/CHART_W)))}
  if (!candles.length) return <div className="price-chart empty">No candles at this time.</div>

  return <div className="chart-wrap">
    <svg
      ref={svgRef}
      viewBox={`0 0 ${CHART_W} ${CHART_H}`}
      className={`price-chart ${pan?'pan-chart':scrub?'scrub-chart':''}`}
      data-candle-count={candles.length}
      data-last-candle={candles.at(-1)?.timestamp}
      data-domain-first={scale.first}
      data-domain-last={scale.last}
      role={pan||scrub ? 'slider' : 'img'}
      aria-label={pan?'Historical token chart. Drag horizontally to browse.':scrub?'Global replay chart. Drag horizontally to scrub.': 'Price history'}
      tabIndex={pan||scrub ? 0 : undefined}
      aria-valuemin={pan||scrub ? scale.first : undefined}
      aria-valuemax={pan||scrub ? scale.last : undefined}
      aria-valuenow={pan||scrub ? cursor?.timestamp ?? scale.last : undefined}
      onPointerDown={e => {if(pan||scrub){startRef.current={x:e.clientX,y:e.clientY};gesture.current='pending';pan?.begin();scrub?.begin()}}}
      onPointerMove={e => {
        if(pan||scrub){if(!gesture.current||gesture.current==='vertical')return;const dx=e.clientX-startRef.current.x,dy=e.clientY-startRef.current.y;if(gesture.current==='pending'){if(Math.abs(dy)>8&&Math.abs(dy)>Math.abs(dx)){gesture.current='vertical';scrub?.finish();return}if(Math.abs(dx)<7||Math.abs(dx)<Math.abs(dy)*1.15)return;gesture.current='horizontal';e.currentTarget.setPointerCapture(e.pointerId)}const rect=e.currentTarget.getBoundingClientRect();pan?.move(dx/(rect.width*(CHART_W-PLOT_LEFT-PLOT_RIGHT)/CHART_W));scrub?.move(fraction(e.clientX));return}
      }}
      onPointerUp={finishGesture}
      onPointerCancel={finishGesture}
      onKeyDown={e => {
        if(pan&&(e.key==='ArrowLeft'||e.key==='ArrowRight'||e.key==='Home'||e.key==='End')){e.preventDefault();pan.begin();pan.move(e.key==='Home'?100:e.key==='End'?-100:e.key==='ArrowLeft'?.08:-.08);pan.finish();return}
        if(scrub&&(e.key==='ArrowLeft'||e.key==='ArrowRight'||e.key==='Home'||e.key==='End')){e.preventDefault();scrub.begin();scrub.move(e.key==='Home'?0:e.key==='End'?1:Math.max(0,Math.min(1,((cursor?.timestamp??scale.last)-scale.first)/Math.max(1,scale.last-scale.first)+(e.key==='ArrowLeft'?-.01:.01))));scrub.finish();return}
      }}
    >
      <defs>
        <clipPath id={`plot${uid}`}><rect x="0" y="0" width={CHART_W-PLOT_RIGHT+3} height={CHART_H}/></clipPath><pattern id={`grid${uid}`} width={settings.grid==='sparse'?14:8} height={settings.grid==='sparse'?14:8} patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r=".6" fill="#302c41" opacity=".35" /></pattern>
        <radialGradient id={`fade${uid}`}><stop stopColor="white"/><stop offset="1" stopColor="white" stopOpacity=".04"/></radialGradient><mask id={`gridmask${uid}`}><rect width={CHART_W} height={CHART_H} fill={`url(#fade${uid})`}/></mask>
        <linearGradient id={`fill${uid}`} x1="0" y1="0" x2="0" y2="1"><stop stopColor="#04bf52" stopOpacity=".14" /><stop offset="1" stopColor="#04bf52" stopOpacity="0" /></linearGradient>
      </defs>
      {settings.grid!=='off'&&<rect width={CHART_W} height={CHART_H} fill={`url(#grid${uid})`} mask={`url(#gridmask${uid})`} />}
      <g clipPath={`url(#plot${uid})`}>
      {style === 'line' ? <>
        <path d={`M${candles.map(c => `${scale.x(c.timestamp)},${scale.y(c.close)}`).join(' L')} L${scale.x(scale.last)},${CHART_H-PLOT_BOTTOM} L${scale.x(scale.first)},${CHART_H-PLOT_BOTTOM} Z`} fill={`url(#fill${uid})`} />
        <polyline points={candles.map(c => `${scale.x(c.timestamp)},${scale.y(c.close)}`).join(' ')} fill="none" stroke="#03c653" strokeWidth="2" />
      </> : candles.map(c => {
        const up = c.close >= c.open
        const interval=candles.length>1?(candles.at(-1)!.timestamp-candles[0].timestamp)/(candles.length-1):60000
        const width = Math.max(.85, Math.min(7, (CHART_W-PLOT_LEFT-PLOT_RIGHT)*.7*interval/Math.max(interval,scale.last-scale.first)))
        return <g key={c.timestamp} data-candle-time={c.timestamp} fill={up ? '#08bf54' : '#fb572e'} stroke={up ? '#08bf54' : '#fb572e'}>
          <line x1={scale.x(c.timestamp)} x2={scale.x(c.timestamp)} y1={scale.y(c.high)} y2={scale.y(c.low)} strokeWidth=".8" />
          <rect x={scale.x(c.timestamp) - width / 2} y={Math.min(scale.y(c.open), scale.y(c.close))} width={width} height={Math.max(1, Math.abs(scale.y(c.open) - scale.y(c.close)))} strokeWidth="0" />
        </g>
      })}
      </g>
      {showQuote && <><line x1="0" x2={CHART_W} y1={scale.y(currentPrice)} y2={scale.y(currentPrice)} stroke="#0cc75e" strokeDasharray="4 4" opacity=".45" />
      {(() => {
        const label = price(currentPrice)
        const pillW = pillWidth
        const pillX = CHART_W - pillW - 3
        return <>
          <rect x={pillX} y={scale.y(currentPrice) - 9} width={pillW} height="18" rx="6" fill="#03bf51" />
          <text x={pillX + pillW / 2} y={scale.y(currentPrice) + 3.5} textAnchor="middle" fill="white" fontSize="11" fontWeight="600">{label}</text>
        </>
      })()}</>}
      <g clipPath={`url(#plot${uid})`}>{showMarkers && markerPositions.map(marker=><TradeMarker key={marker.event.id} {...marker} onInspect={interactiveMarkers?()=>setInspected(marker.events):undefined}/>)}</g>
      {cursor&&settings.crosshair&&<line className="replay-cursor" x1={scale.x(cursor.timestamp)} x2={scale.x(cursor.timestamp)} y1="12" y2={CHART_H-16} stroke="#858cff" strokeWidth="1" strokeDasharray="3 4"/>}
      {settings.marketCapLabels&&marketCap!==undefined&&marketCap!==null&&<text x="16" y={CHART_H-4} fill="#93909f" fontSize="10">{money(marketCap,true)} MC</text>}
    </svg>
    {settings.eventCount&&<div className="chart-event-count">{events.length} events in this context</div>}
    {inspected.length>0&&<div className="marker-inspector" role="region" aria-label="Grouped trade events"><div className="section-heading"><h3>{inspected.length} trade events</h3><button className="text-accent" onClick={()=>setInspected([])}>Close events</button></div>{inspected.map(e=><div key={e.id}><span className={e.side==='buy'?'positive':'negative'}>{e.side} · {money(e.usdValue)}</span><span>{dateTime(e.timestamp)} · {price(e.priceUsd)}</span><small>{e.units.toLocaleString(undefined,{maximumSignificantDigits:8})} units</small></div>)}</div>}
  </div>
}

export function Timeframes({ value, onChange, style = 'candles', onStyle, onOptions }: { value: ChartTimeframe; onChange: (v: ChartTimeframe) => void; style?: 'candles' | 'line'; onStyle?: () => void; onOptions?:()=>void }) {
  const values: ChartTimeframe[] = ['LIVE', '1H', '4H', '1D', '7D', 'ALL']
  return <div className="timeframes" role="group" aria-label="Chart timeframe">{values.map(v => <button key={v} aria-pressed={value === v} className={value === v ? 'active' : ''} onClick={() => onChange(v)}>{v}{v === 'LIVE' && <i />}</button>)}{onStyle && <button className="chart-style" aria-label="Toggle chart style" onClick={onStyle}>{style === 'candles' ? <Activity /> : <CandlestickChart />}</button>}{onOptions&&<button className="chart-options" aria-label="Chart options" onClick={onOptions}><SlidersHorizontal size={21}/></button>}</div>
}
