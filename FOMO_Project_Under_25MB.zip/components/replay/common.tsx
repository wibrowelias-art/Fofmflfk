'use client'

import React, { useEffect, useRef, useState } from 'react'
import { Home, Search, Users, BadgeCheck, SlidersHorizontal, Star } from 'lucide-react'
import { useReplayStore } from '@/lib/store'
import { APP_MARK, APP_NAME } from '@/lib/branding'
import type { Asset } from '@/lib/market/types'
import { imageSources } from '@/lib/customization'
import { preferredImage, imageFailed, imageSucceeded } from '@/lib/image-cache'

export function Avatar({ src, name, size = '', verified = false, fallbacks=[], revision=0, position }: { src: string; name: string; size?: string; verified?: boolean; fallbacks?: string[]; revision?: number; position?:{x:number;y:number;zoom:number} }) {
  const sources=[...new Set([src,...fallbacks].filter(Boolean))],key=`${revision}:${sources.join('|')}`
  const [attempt,setAttempt]=useState({key:'',src:''}),[loaded,setLoaded]=useState('')
  const current=attempt.key===key?attempt.src:preferredImage(sources,revision)
  return <span className={`avatar ${size} ${current&&loaded!==current?'loading':''}`}>
    {current && <span className="avatar-image"><img key={`${key}:${current}`} src={current} alt={name} draggable={false} style={position?{objectPosition:`${position.x}% ${position.y}%`,transform:`translate(${(50-position.x)*(position.zoom-1)}%, ${(50-position.y)*(position.zoom-1)}%) scale(${position.zoom})`}:undefined} onLoad={()=>{setLoaded(current);imageSucceeded(sources,current,revision)}} onError={()=>{imageFailed(current);setAttempt({key,src:preferredImage(sources.filter(s=>s!==current),revision)})}} /></span>}
    {!current&&<span className="avatar-fallback" aria-hidden="true">{name.trim().slice(0, 2).toUpperCase()}</span>}
    {verified && <span className="verified"><BadgeCheck size={10} strokeWidth={4} /></span>}
  </span>
}
export function AssetAvatar({asset,size='',verified=asset.verified}:{asset:Asset;size?:string;verified?:boolean}) { const {ui}=useReplayStore();const [src='',...fallbacks]=ui.qaMode==='image-failure'?[]:imageSources(asset);return <Avatar src={src} fallbacks={fallbacks} revision={asset.imageRevision} name={asset.name} size={size} verified={verified}/> }

export function Brand({ small = false }: { small?: boolean }) {
  return <span className={`brand ${small ? 'small' : ''}`} aria-label={APP_NAME}>
    <img src={APP_MARK} alt="" draggable={false} />
  </span>
}

export function Segmented<T extends string>({ values, value, onChange, label, variant = '' }: { values: readonly T[]; value: T; onChange: (v: T) => void; label: string; variant?: string }) {
  return <div className={`segmented ${variant}`} role="tablist" aria-label={label}>{values.map(v => <button key={v} role="tab" aria-selected={value === v} className={value === v ? 'active' : ''} onClick={() => onChange(v)}>{v}</button>)}</div>
}

export function BottomNav() {
  const { ui, navigate, state } = useReplayStore()
  const items = [
    { id: 'home' as const, label: 'Home', icon: <Home /> },
    { id: 'search' as const, label: 'Search', icon: <Search /> },
    { id: 'center' as const, label: 'Replay hub', icon: <Brand small /> },
    { id: 'people' as const, label: 'People', icon: <Users /> },
    { id: 'profile' as const, label: 'Profile', icon: <Avatar src={state.profile.avatar} name={state.profile.displayName} size="small" /> },
  ]
  return <nav className="bottom-nav" aria-label="Main navigation"><span className="nav-active-bubble" style={{transform:`translateX(${Math.max(0,items.findIndex(item=>item.id===ui.screen))*100}%)`}}/>{items.map(item => <button key={item.id} aria-label={item.label} aria-current={ui.screen === item.id ? 'page' : undefined} className={ui.screen === item.id ? 'active' : ''} onClick={() => navigate(item.id)}>{item.icon}</button>)}</nav>
}

export function EmptyState({ title, children }: { title: string; children?: React.ReactNode }) {
  return <div className="empty"><span className="empty-orbit">↗</span><h3>{title}</h3>{children && <p>{children}</p>}</div>
}

export function useLongPress(callback: () => void) {
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const start = useRef({ x: 0, y: 0 })
  const clear = () => { if (timer.current) clearTimeout(timer.current); timer.current = null }
  useEffect(() => clear, [])
  return {
    onPointerDown: (e: React.PointerEvent) => { start.current = { x: e.clientX, y: e.clientY }; timer.current = setTimeout(callback, 550) },
    onPointerUp: clear, onPointerCancel: clear, onPointerLeave: clear,
    onPointerMove: (e: React.PointerEvent) => { if (Math.hypot(e.clientX - start.current.x, e.clientY - start.current.y) > 10) clear() },
    onContextMenu: (e: React.MouseEvent) => { e.preventDefault(); clear(); callback() },
  }
}

export function FilterIcon({ active }: { active?: boolean }) { return active ? <BadgeCheck /> : <SlidersHorizontal /> }
export { Star }
