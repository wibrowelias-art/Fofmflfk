'use client'
import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, Grid2X2 } from 'lucide-react'
import { useReplayStore } from '@/lib/store'
import type { BackstageTab } from '@/lib/store-types'
import { BottomSheet } from './sheets'
import { TemplatesBrowser } from './templates-browser'
import { OverviewEditor } from './backstage/overview'
import { ProfileEditor } from './backstage/profile'
import { FundsEditor } from './backstage/funds'
import { TokensEditor } from './backstage/tokens'
import { TradersEditor } from './backstage/traders'
import { WeeklyEditor } from './backstage/weekly'
import { PositionsEditor } from './backstage/positions'
import { ReplayEditor } from './backstage/replay'
import { ChartsEditor, AppearanceEditor, SocialEditor } from './backstage/settings'
import { DataEditor } from './backstage/data'
import { DevelopmentEditor } from './backstage/development'
const sections:BackstageTab[]=['Overview','Profile','Funds','Tokens','Traders','Weekly','Positions','Replay','Charts','Social','Templates','Data','Appearance','Development']
export function BackstageScreen() {
  const {navigate,setUI,state,ui}=useReplayStore(),[menu,setMenu]=useState(false),bar=useRef<HTMLDivElement>(null)
  const [tab,setTab]=useState<BackstageTab>(()=>{if(ui.backstageTab)return ui.backstageTab;try{const saved=localStorage.getItem('replay:backstage-section');if(sections.includes(saved as BackstageTab))return saved as BackstageTab}catch{}return 'Overview'})
  const select=(next:BackstageTab)=>{setTab(next);setUI({backstageTab:next});try{localStorage.setItem('replay:backstage-section',next)}catch{}setMenu(false);window.scrollTo({top:0})}
  useEffect(()=>{
    const strip=bar.current,active=strip?.querySelector<HTMLElement>('[aria-selected="true"]')
    if(!strip||!active)return
    const parent=strip.getBoundingClientRect(),child=active.getBoundingClientRect()
    const left=child.left<parent.left+12?child.left-parent.left-12:child.right>parent.right-20?child.right-parent.right+20:0
    strip.scrollBy({left,behavior:state.settings.appearance?.reducedMotion||state.settings.appearance?.animations===false||matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'})
  },[tab])
  return <div className="screen backstage-screen"><div className="backstage-sticky"><header className="page-header"><button className="icon" aria-label="Back to app" onClick={()=>navigate('home')}><ArrowLeft/></button><div><small>LOCAL WORKSPACE</small><h2>Backstage</h2></div><button className="icon" aria-label="Choose Backstage section" onClick={()=>setMenu(true)}><Grid2X2 size={21}/></button></header><div ref={bar} className="backstage-tabs carousel" role="tablist" aria-label="Backstage sections">{sections.map(v=><button key={v} role="tab" aria-selected={tab===v} className={tab===v?'active':''} onClick={()=>select(v)}>{v}</button>)}</div></div>
    {menu&&<BottomSheet title="Control center" close={()=>setMenu(false)}><div className="section-menu">{sections.map((v,i)=><button key={v} className={tab===v?'active':''} onClick={()=>select(v)}><small>{String(i+1).padStart(2,'0')}</small>{v}<span>↗</span></button>)}</div></BottomSheet>}
    {tab==='Overview'&&<OverviewEditor open={select}/>} {tab==='Profile'&&<ProfileEditor/>} {tab==='Funds'&&<FundsEditor/>} {tab==='Tokens'&&<TokensEditor/>} {tab==='Traders'&&<TradersEditor/>} {tab==='Weekly'&&<WeeklyEditor/>} {tab==='Positions'&&<PositionsEditor/>} {tab==='Replay'&&<ReplayEditor/>} {tab==='Charts'&&<ChartsEditor/>} {tab==='Social'&&<SocialEditor openTraders={()=>select('Traders')}/>} {tab==='Templates'&&<div className="backstage-panel"><TemplatesBrowser/></div>} {tab==='Data'&&<DataEditor/>} {tab==='Appearance'&&<AppearanceEditor/>} {tab==='Development'&&<DevelopmentEditor/>}

  </div>
}
