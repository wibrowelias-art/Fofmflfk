'use client'

import { useRef, useState } from 'react'
import { X, Eye, EyeOff, Copy, Share2, Play } from 'lucide-react'
import { toBlob } from 'html-to-image'
import { useReplayStore } from '@/lib/store'
import { derivePositions, positionMetrics } from '@/lib/positions/calculations'
import { calculateFumble } from '@/lib/positions/fumble'
import { quoteAt, visibleCandles } from '@/lib/market/timeline'
import { selectPositionView } from '@/lib/positions/selectors'
import { money, percent, price } from '@/lib/formatting/numbers'
import { AssetAvatar, Avatar, Brand, Segmented } from './common'
import { PriceChart } from './chart'

function ShareCard({ position, kind, style, showMarkers, notional }: {
  position: ReturnType<typeof derivePositions>[number]
  kind: 'position' | 'fumble'
  style: 'line' | 'candles'
  showMarkers: boolean
  notional: boolean
}) {
  const { state } = useReplayStore()
  const view=selectPositionView(state,position.id)!
  const {asset,quote,metrics,events,fumble}=view
  const isFumble = kind === 'fumble' && !!fumble
  return <article className={`position-share-card ${isFumble ? 'fumble-card' : ''}`}>
    <header><Avatar src={state.profile.avatar} name={state.profile.displayName}/><div><strong>{state.profile.displayName}</strong><span className={`share-badge ${isFumble ? 'fumble' : metrics.pnlUsd >= 0 ? 'positive' : 'negative'}`}>{isFumble ? 'Fumble' : !Number.isFinite(metrics.pnlUsd)?'Unavailable':metrics.pnlUsd >= 0 ? 'Profit' : 'Loss'}</span></div><aside><time>{new Date(position.closedAt ?? position.openedAt).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}</time><Brand small/></aside></header>
    <PriceChart showQuote={false} smallMarkers interactiveMarkers={false} chartHeight={150} candles={visibleCandles(asset.candles, 'ALL', quote.timestamp)} events={events} currentPrice={quote.priceUsd} style={style} showMarkers={showMarkers} />
    <div className="share-summary"><div className="share-token"><AssetAvatar asset={asset} /><div><strong>{asset.name}</strong><span>{asset.symbol}</span></div></div>
    <div className={`share-result ${isFumble ? 'negative' : metrics.pnlUsd >= 0 ? 'positive' : 'negative'}`}>{notional && <h1>{isFumble ? money(fumble!.missedGain) : Number.isFinite(metrics.pnlUsd)?`${metrics.pnlUsd >= 0 ? '+' : '−'}${money(Math.abs(metrics.pnlUsd))}`:'Unavailable'}</h1>}<strong className={isFumble?'positive':''}>{percent(isFumble ? fumble!.fumbleReturnPct : metrics.pnlPct)}</strong></div>
    <dl className="share-stats">{(isFumble ? view.exitMC!==null&&quote.marketCapUsd!==null?[['Sold at', `${money(view.exitMC,true)} MC`],['Current MC', `${money(quote.marketCapUsd,true)} MC`]]:[['Sold at',price(position.weightedAverageExitUsd)],['Current price',price(quote.priceUsd)]] : [['Invested',money(position.totalInvestedUsd)],['Avg. entry',view.entryMC!==null?`${money(view.entryMC,true)} MC`:price(position.weightedAverageEntryUsd)],...(position.weightedAverageExitUsd!==null?[['Avg. exit',view.exitMC!==null?`${money(view.exitMC,true)} MC`:price(position.weightedAverageExitUsd)]]:[])]).map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl></div>
    <footer className={isFumble ? 'fumble-footer' : ''}><img src="/brand/fomo-wordmark.svg" alt="fomo" /><span>Replay · Learning</span></footer>
  </article>
}

export function ShareScreen() {
  const { state, ui, navigate, update, notify, setUI } = useReplayStore()
  const ref = useRef<HTMLDivElement | null>(null)
  const [style, setStyle] = useState<'Line' | 'Candles'>('Candles')
  const [showMarkers, setShowMarkers] = useState(true)
  const [notional, setNotional] = useState(true)
  const [busy, setBusy] = useState(false)
  const position = derivePositions(state.tradeEvents, state.timeline.type === 'replay' ? state.timeline.timestamp : Number.POSITIVE_INFINITY).find(p => p.id === ui.positionId)
  if (!position) return <div className="screen"><button onClick={() => navigate('profile')}>Back to profile</button><p>This position is not available at the selected time.</p></div>

  const exportImage = async (copyOnly: boolean) => {
    setBusy(true)
    try {
      await document.fonts.ready
      await Promise.all(Array.from(ref.current?.querySelectorAll('img') ?? []).map(img=>img.decode().catch(()=>{})))
      const blob = await toBlob(ref.current!, { pixelRatio: 2, backgroundColor: '#080611', cacheBust: false, imagePlaceholder: '/art/profile.svg' })
      if (!blob) throw new Error('Could not render image')
      if (copyOnly && navigator.clipboard && typeof ClipboardItem !== 'undefined') {
        try { await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]); notify('Image copied'); return } catch {}
      }
      const file = new File([blob], `replay-${ui.shareKind}.png`, { type: 'image/png' })
      if (!copyOnly && navigator.canShare?.({ files: [file] })) {
        try { await navigator.share({ files: [file], title: `Replay ${ui.shareKind}` }); return } catch (e) { if (e instanceof Error && e.name === 'AbortError') return }
      }
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a'); a.href = url; a.download = file.name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); notify('Image downloaded')
    } catch (e) { notify(e instanceof Error ? e.message : 'Image export failed') } finally { setBusy(false) }
  }

  return <div className="screen share-screen"><header className="page-header"><button className="icon" aria-label="Back to profile" onClick={() => navigate('profile')}><X /></button><h2>{ui.shareKind === 'fumble' ? 'Fumble' : 'Position'}</h2><span /></header><div><ShareCard position={position} kind={ui.shareKind} style={style === 'Line' ? 'line' : 'candles'} showMarkers={showMarkers} notional={notional} /></div><div className="export-renderer" aria-hidden="true" ref={ref}><ShareCard position={position} kind={ui.shareKind} style={style === 'Line' ? 'line' : 'candles'} showMarkers={showMarkers} notional={notional}/></div><button className="replay-trade" onClick={() => { update(s => ({...s,settings:{...s.settings,replayAssetId:position.assetId}}));setUI({screen:'backstage',backstageTab:'Replay',assetId:position.assetId,sheet:null,replayStart:position.openedAt}) }}><Play size={21} fill="currentColor"/> Replay trade</button><div className="share-controls">{([['Notional PnL', notional, setNotional], ['Buy/Sell', showMarkers, setShowMarkers]] as const).map(([label, value, setter]) => <button key={label} role="switch" aria-checked={value} onClick={() => setter(!value)}>{value?<Eye size={17}/>:<EyeOff size={17}/>} {label}</button>)}</div><Segmented values={['Line', 'Candles'] as const} value={style} onChange={setStyle} label="Share chart style" /><div className="share-buttons"><button className="primary" disabled={busy} onClick={() => exportImage(false)}><Share2 /> <span>{busy ? 'Preparing…' : 'Share'}</span></button><button className="secondary" disabled={busy} onClick={() => exportImage(true)}><Copy /><span>Copy image</span></button></div></div>
}
