'use client'
import { useDetection } from '@/lib/market/use-detection'
import { isContract } from '@/lib/market/normalize'
import { PerpsPractice } from './social'

import { weeklyEntries, communityTraders } from '@/lib/social'
import { WeeklyCard } from './weekly-card'
import { useMemo, useState } from 'react'
import { Lightbulb, Users, X, Star } from 'lucide-react'
import { useReplayStore, activeTimestamp, portfolioValue } from '@/lib/store'
import { selectProfilePerformance } from '@/lib/positions/selectors'
import { quoteAt } from '@/lib/market/timeline'
import { money, percent, price, quantity, signedMoney } from '@/lib/formatting/numbers'
import type { Asset } from '@/lib/market/types'
import { AssetAvatar, Avatar, Brand, EmptyState, FilterIcon, Segmented, useLongPress } from './common'

function PortfolioHeader({ deposit = true }: { deposit?: boolean }) {
  const { state, setUI, navigate } = useReplayStore()
  const timestamp = activeTimestamp(state)
  const {current,previous} = useMemo(() => selectProfilePerformance(state,'24h',timestamp), [state, timestamp])
  const hold = useLongPress(() => navigate('backstage'))
  const [whole, decimals = '00'] = money(current).split('.')
  return <section className="portfolio-header">
    <div {...hold} className="portfolio-touch" tabIndex={0} role="button" aria-label="Portfolio balance. Hold to open Backstage" onKeyDown={e => { if (e.key === 'Enter') navigate('backstage') }}>
      <h1>{whole}{Number.isFinite(current)&&<span>.{decimals}</span>}</h1>
      <p className={current - previous >= 0 ? 'positive' : 'negative'}>{signedMoney(current - previous)} <span className="muted">24h</span></p>
    </div>
    {deposit && <button className="primary deposit-button" onClick={() => setUI({ sheet: 'deposit' })}>Deposit</button>}
  </section>
}

function WeeklyTrades() {
  const { state, openAsset } = useReplayStore()
  const items=weeklyEntries(state,activeTimestamp(state))
  if (!items.length) return null
  return <section className="weekly">
    <h2><Lightbulb size={18} />Weekly Top Trades</h2>
    <div className="carousel weekly-carousel">{items.map(item=><WeeklyCard key={item.id} item={item} onOpen={()=>{const a=state.assets.find(a=>a.id===item.assetId);if(a)openAsset(a)}}/>)}</div>
  </section>
}

export function TokenRow({ asset, removable = false, onRemove }: { asset: Asset; removable?: boolean; onRemove?: () => void }) {
  const { state, openAsset } = useReplayStore()
  const quote = quoteAt(asset, state.timeline, state.settings.overrides[asset.id])
  const change = state.timeline.type === 'live' ? asset.priceChange24hPct : quote.priceChange24hPct
  return <button className="token-row" onClick={() => openAsset(asset)} aria-label={`Open ${asset.symbol}`}>
    <AssetAvatar asset={asset} verified={asset.verified} />
    <span className="token-meta"><strong>{asset.symbol}{asset.launchpad && <span className="network-badge">≋</span>}</strong><span>{quote.marketCapUsd===null?'MC unavailable':`${money(quote.marketCapUsd,true)} MC`}</span></span>
    <span className="token-quote"><strong>{quote.unavailable ? 'Unavailable' : price(quote.priceUsd)}</strong><span className={(change ?? 0) >= 0 ? 'positive' : 'negative'}>{percent(change)}</span></span>
    {removable && <span role="button" className="remove-token" onClick={e => { e.stopPropagation(); onRemove?.() }}><X /></span>}
  </button>
}

export function HomeScreen() {
  const { state, navigate } = useReplayStore()
  const [tab, setTab] = useState<'Watchlist' | 'Tokens' | 'Perps'>('Tokens')
  const [filter, setFilter] = useState<'Crypto' | 'Trending' | 'Most held' | 'Graduated' | 'Bonding'>('Trending')
  const [verifiedOnly, setVerifiedOnly] = useState(false)
  let assets = state.assets.filter(a => !a.transient && (tab !== 'Watchlist' || state.watchlist.includes(a.id)) && (!verifiedOnly || a.verified))
  if (filter === 'Most held') assets = [...assets].sort((a, b) => (b.holders ?? 0) - (a.holders ?? 0))
  if (filter === 'Graduated' || filter === 'Bonding') assets = assets.filter(a => a.category === filter.toLowerCase())

  return <div className="screen home-screen">
    <header className="home-brand"><Brand /></header>
    <PortfolioHeader />
    <WeeklyTrades />
    <div className="discovery-tabs" role="tablist" aria-label="Markets">{(['Watchlist', 'Tokens', 'Perps'] as const).map(v => <button key={v} role="tab" aria-selected={tab === v} className={tab === v ? 'active' : ''} onClick={() => setTab(v)}>{v === 'Watchlist' && <Star size={20} />} {v}{v === 'Perps' && <span className="new-badge">New</span>}</button>)}</div>
    {tab === 'Perps' ? <PerpsPractice/> : <>
      <div className="filter-row carousel"><button className={`filter icon ${verifiedOnly ? 'active' : ''}`} aria-label="Filter verified tokens" aria-pressed={verifiedOnly} onClick={() => setVerifiedOnly(v => !v)}><FilterIcon active={verifiedOnly} /></button>{(['Crypto', 'Trending', 'Most held', 'Graduated', 'Bonding'] as const).map(v => <button key={v} className={`filter ${filter === v ? 'active' : ''}`} onClick={() => setFilter(v)}>{v}</button>)}</div>
      <div className="token-list">{assets.map(a => <TokenRow key={a.id} asset={a} />)}{!assets.length && <div className="market-empty"><EmptyState title={state.assets.some(a=>!a.transient) ? tab==='Watchlist'?'No starred tokens':'No matching tokens' : 'No tokens yet'}>{state.assets.some(a=>!a.transient) ? tab==='Watchlist'?'Star a tracked token to see it here.':'Try another filter or add a token.' : 'Search or paste a contract to start tracking.'}</EmptyState><button className="primary" onClick={()=>navigate('search')}>Add token</button></div>}</div>
    </>}
  </div>
}

export function SearchScreen() {
  const { state, update, notify } = useReplayStore()
  const [tab, setTab] = useState<'All' | 'Tokens' | 'Perps' | 'Traders'>('All')
  const [query, setQuery] = useState('')
  const remote=useDetection(isContract(query.trim()) && !state.assets.some(a=>a.contractAddress===query.trim())?query:'')
  const matches = (...values: string[]) => values.some(v => v.toLowerCase().includes(query.toLowerCase().trim()))
  const recentTraders = state.searchRecents.filter(r => r.type === 'trader').map(r => state.traders.find(t => t.id === r.id)).filter(Boolean) as typeof state.traders
  const traders = (query ? communityTraders(state) : recentTraders.length?recentTraders:communityTraders(state).slice(0,8)).filter(t => t.enabled!==false&&matches(t.displayName, t.handle))
  const recentAssets = state.searchRecents.filter(r => r.type === 'asset').map(r => state.assets.find(a => a.id === r.id)).filter(Boolean) as Asset[]
  const assets = (query ? state.assets : recentAssets.slice(0,12)).filter(a => matches(a.name, a.symbol, a.contractAddress))
  const remove = (type: 'asset' | 'trader', id: string) => update(s => ({ ...s, searchRecents: s.searchRecents.filter(r => r.id !== id || r.type !== type) }))

  return <div className="screen search-screen">
    <Segmented values={['All', 'Tokens', 'Perps', 'Traders'] as const} value={tab} onChange={setTab} label="Search categories" variant="chips" />
    {tab === 'Perps' ? <PerpsPractice/> : <>
      {(tab === 'All' || tab === 'Traders') && <>
        <div className="section-heading"><h2>{query ? 'Traders' : 'Recents'}</h2>{!query && <button className="text-accent" onClick={() => update(s => ({ ...s, searchRecents: [] }))}>Clear all</button>}</div>
        <div className="carousel recent-carousel">{traders.map(t => <article key={t.id} className="recent-card">
          <button className="remove-recent" aria-label={`Remove ${t.displayName}`} onClick={() => remove('trader', t.id)}><X size={16} /></button>
          <Avatar src={t.avatar} name={t.displayName} />
          <strong>{t.displayName}</strong>
          {state.settings.social?.showFollowers!==false&&<span className="recent-stats"><Users size={12} />{quantity(t.followers)} · <b className={t.pnlUsd >= 0 ? 'positive' : 'negative'}>{t.pnlUsd >= 0 ? '+' : ''}{money(t.pnlUsd, true)}</b></span>}
          <button className={`primary ${t.following ? 'following' : ''}`} onClick={() => update(s => ({ ...s, traders: s.traders.map(x => x.id === t.id ? { ...x, following: !x.following } : x) }))}>{t.following ? 'Following' : 'Follow'}</button>
        </article>)}</div>
      </>}
      {(tab === 'All' || tab === 'Tokens') && <div className="search-token-list">{assets.map(a => <TokenRow key={a.id} asset={a} removable={!query} onRemove={() => remove('asset', a.id)} />)}</div>}
    </>}
    {(tab==='All'||tab==='Tokens')&&<div className="market-result">{remote.busy&&<p role="status">Detecting token…</p>}{remote.error&&<p className="form-error">{remote.error}</p>}{remote.result&&<><h2>Market result <small>{remote.result.chain}</small></h2><TokenRow asset={remote.result}/></>}</div>}
    {!query && !state.searchRecents.length && <EmptyState title="Find your first token">Paste a contract address below to discover its market.</EmptyState>}
    <div className="search-dock"><input aria-label="Search for anything" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search or paste a contract..." /><button onClick={async () => { try { const text = await navigator.clipboard.readText(); setQuery(text) } catch { notify('Paste unavailable. Touch and hold the search field to paste.') } }}>Paste</button></div>
  </div>
}
