'use client'

import { useMemo, useState, useRef } from 'react'
import { CalendarDays, Clock3, Gift, History, MoreHorizontal, Pencil, Plus, Settings, Share2, ArrowUpDown } from 'lucide-react'
import { useReplayStore, activeTimestamp, portfolioValue } from '@/lib/store'
import { derivePositions, cashAt, positionMetrics, profileTradeStats } from '@/lib/positions/calculations'
import { selectProfilePerformance, selectPositionView, type PerformanceRange } from '@/lib/positions/selectors'
import { quoteAt } from '@/lib/market/timeline'
import { dateTime, money, percent, signedMoney } from '@/lib/formatting/numbers'
import { prepareAvatar } from '@/lib/storage'
import { BottomSheet } from './sheets'
import { AssetAvatar, Avatar, EmptyState, Segmented, useLongPress } from './common'

function PortfolioHeaderInline({range}:{range:PerformanceRange}) {
  const { state, navigate } = useReplayStore()
  const timestamp = activeTimestamp(state)
  const {current,previous}=useMemo(()=>selectProfilePerformance(state,range,timestamp),[state,range,timestamp])
  const hold = useLongPress(() => navigate('backstage'))
  const [whole, decimals = '00'] = money(current).split('.')
  return <div {...hold} className="portfolio-touch" tabIndex={0} role="button" aria-label="Portfolio balance. Hold to open Backstage" onKeyDown={e => { if (e.key === 'Enter') navigate('backstage') }}><h1>{whole}{Number.isFinite(current)&&<span>.{decimals}</span>}</h1><p className={current - previous >= 0 ? 'positive' : 'negative'}>{signedMoney(current - previous)} <span className="muted">{range}</span></p></div>
}

function PortfolioChart({ range }: { range: '24h' | '7d' | '30d' | 'All' }) {
  const { state } = useReplayStore()
  const values=useMemo(()=>selectProfilePerformance(state,range).series,[state,range])
  if(values.some(v=>!Number.isFinite(v.valueUsd))) return <div className="portfolio-chart empty">Historical portfolio value unavailable</div>
  const series = values.map(v => v.valueUsd)
  const min = Math.min(...series)
  const max = Math.max(...series)
  const span = Math.max(max - min, .02 * max, 1)
  const points = series.map((value, i) => [i / (series.length - 1) * 390, 115 - ((value - min) / span) * 80] as const)
  const pointString = points.map(([x, y]) => `${x},${y}`).join(' ')
  const color = series.at(-1)! >= series[0] ? '#0bc25a' : '#ff572d'
  const last = points.at(-1)!
  return <svg className="portfolio-chart" viewBox="0 0 390 160" role="img" aria-label="Portfolio value history">
    <defs><linearGradient id="portfolio-fill" x1="0" x2="0" y1="0" y2="1"><stop stopColor={color} stopOpacity=".14" /><stop offset="1" stopColor={color} stopOpacity="0" /></linearGradient><pattern id="portfolio-grid" width="8" height="8" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r=".6" fill="#302c41" opacity=".4" /></pattern></defs>
    <rect width="390" height="160" fill="url(#portfolio-grid)" />
    <path d={`M${pointString.replaceAll(' ', ' L')} L390,160 L0,160 Z`} fill="url(#portfolio-fill)" />
    <polyline points={pointString} stroke={color} fill="none" strokeWidth="3" />
    <circle cx={last[0] - 6} cy={last[1]} r="10" fill={color} opacity=".2" /><circle cx={last[0] - 6} cy={last[1]} r="5" fill={color} />
  </svg>
}

export function ProfileScreen() {
  const { state, setUI, navigate, notify, update } = useReplayStore()
  const fileRef=useRef<HTMLInputElement>(null)
  const [editingBio,setEditingBio]=useState(false)
  const [rewardsOpen,setRewardsOpen]=useState(false)
  const [bio,setBio]=useState(state.profile.bio)
  const profile = state.profile
  const [range, setRange] = useState<'24h' | '7d' | '30d' | 'All'>('24h')
  const [status, setStatus] = useState<'Open' | 'Closed'>('Open')
  const [type, setType] = useState<'All' | 'Tokens' | 'Perps'>('All')
  const [recent, setRecent] = useState(true)
  const timestamp = activeTimestamp(state)
  const positions = derivePositions(state.tradeEvents, timestamp)
  const cash = cashAt(state.cash, state.tradeEvents, timestamp)
  const stats = profileTradeStats(state.tradeEvents,timestamp)
  const hold = useLongPress(() => navigate('backstage'))
  const visible = positions.filter(p => p.status === status.toLowerCase() && type !== 'Perps').sort((a, b) => recent ? b.openedAt - a.openedAt : a.openedAt - b.openedAt)

  return <div className="profile-screen"><input ref={fileRef} aria-label="Avatar image" hidden type="file" accept="image/jpeg,image/png,image/webp" onChange={async e=>{const file=e.target.files?.[0];if(!file)return;try{const image=await prepareAvatar(file);update(s=>({...s,profile:{...s.profile,...image}}));notify('Avatar updated')}catch(e){notify(e instanceof Error?e.message:'Image failed')}e.target.value=''}}/>{editingBio&&<BottomSheet title="Edit bio" close={()=>setEditingBio(false)}><label className="field">Bio<textarea aria-label="Bio" maxLength={200} value={bio} onChange={e=>setBio(e.target.value)}/></label><button className="primary full" onClick={()=>{update(s=>({...s,profile:{...s.profile,bio}}));setEditingBio(false)}}>Save bio</button></BottomSheet>}
    {rewardsOpen&&<BottomSheet title="Your milestones" close={()=>setRewardsOpen(false)}><p className="muted">Practice at your own pace.</p><ul className="milestone-list"><li>{state.assets.some(a=>!a.transient)?'✓':'○'} Track your first token</li><li>{state.tradeEvents.some(e=>e.side==='buy')?'✓':'○'} Make a practice entry</li><li>{positions.some(p=>p.status==='closed')?'✓':'○'} Complete a position</li></ul></BottomSheet>}<div className="profile-cover" style={profile.cover?{backgroundImage:`url("${profile.cover}")`,backgroundPosition:`center ${profile.coverPosition??50}%`}:undefined}><div className="profile-actions"><button className="icon" aria-label="Share profile" onClick={async () => { try { const text = `${profile.displayName} @${profile.handle} on fomo`; if (navigator.share) await navigator.share({ text }); else { await navigator.clipboard.writeText(text); notify('Profile copied') } } catch { notify('Sharing unavailable') } }}><Share2 /></button><button className="icon" aria-label="Position history" onClick={() => { setStatus('Closed'); document.getElementById('positions')?.scrollIntoView({ behavior: 'smooth' }) }}><History /></button><button className="icon" aria-label="Profile settings" onClick={() => navigate('backstage')}><Settings /></button></div></div>
    <section className="profile-info"><div className="profile-info-top"><button className="profile-avatar" aria-label="Edit avatar" onClick={()=>fileRef.current?.click()}><Avatar src={profile.avatar} name={profile.displayName} size="large" verified={profile.verified} position={profile.avatarPosition} /><span className="avatar-edit"><Pencil size={12} /></span></button><button className="rewards-pill" onClick={()=>setRewardsOpen(true)}><Gift size={16}/>Rewards</button></div><h1>{profile.displayName}</h1><p className="profile-handle">@{profile.handle}</p>{profile.bio ? <button className="profile-bio" onClick={()=>setEditingBio(true)}>{profile.bio}</button> : <button className="add-bio" onClick={() => setEditingBio(true)}><Plus size={19} /> Add a bio</button>}<div className="profile-stats"><span><b>{profile.following}</b> Following</span><span><b>{profile.followers}</b> Followers</span></div><div className="profile-meta"><span><Clock3 />{profile.manualStats?profile.averageHold:stats.averageHold==='—'?'No trades':stats.averageHold} avg. hold</span><span><ArrowUpDown />{profile.manualStats?profile.tradeCount:stats.count} trades</span><span><CalendarDays />Joined {new Date(`${profile.joinedDate}T12:00:00`).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}</span></div></section>
    <section className="profile-performance"><div className="profile-value-row"><PortfolioHeaderInline range={range} /><Segmented values={['24h', '7d', '30d', 'All'] as const} value={range} onChange={setRange} label="Portfolio range" /></div><PortfolioChart range={range} /></section>
    <section className="profile-lower">
      <div className="cash-row"><div className="cash-value" {...hold} role="button" tabIndex={0} aria-label="Total cash. Hold to open Backstage" onKeyDown={e => { if (e.key === 'Enter') navigate('backstage') }}><span className="cash-icon">$</span><div><span>Total cash</span><strong>{money(cash)}</strong></div></div><button className="square-button" aria-label="Add cash" onClick={() => setUI({ sheet: 'deposit' })}><Plus /></button><button className="square-button" aria-label="Cash options" onClick={() => navigate('backstage')}><MoreHorizontal /></button></div>
      <div id="positions" className="section-heading"><h2>Positions ({positions.length})</h2><Segmented values={['Open', 'Closed'] as const} value={status} onChange={setStatus} label="Position status" /></div>
      <div className="position-filters"><Segmented values={['All', 'Tokens', 'Perps'] as const} value={type} onChange={setType} label="Position type" variant="chips" /><button className="muted" onClick={() => setRecent(v => !v)}>{recent ? 'Recent' : 'Oldest'} <ArrowUpDown size={15} /></button></div>
      <div className="position-list">{visible.map(position => {
        const asset = state.assets.find(a => a.id === position.assetId)!
        const metrics = selectPositionView(state,position.id,timestamp)!.metrics
        return <button key={position.id} className="position-row" onClick={() => setUI({ assetId: asset.id, positionId: position.id, sheet: 'position' })}><AssetAvatar asset={asset} /><span className="token-meta"><strong>{asset.symbol}</strong><span>{dateTime(position.closedAt ?? position.openedAt)}</span></span><span className={`token-quote ${metrics.pnlUsd >= 0 ? 'positive' : 'negative'}`}><strong>{signedMoney(metrics.pnlUsd)}</strong><span>{percent(metrics.pnlPct)}</span></span></button>
      })}{!visible.length && <EmptyState title={type === 'Perps' ? 'No practice perps positions' : `No ${status.toLowerCase()} positions`}>{status === 'Open' ? 'Your positions will appear here after your first buy.' : 'Fully sold positions will appear here.'}</EmptyState>}</div>
    </section>
  </div>
}
