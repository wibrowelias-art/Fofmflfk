'use client'

import { useEffect, type CSSProperties } from 'react'
import { appearanceDefaults } from '@/lib/customization'
import { StoreProvider, useReplayStore } from '@/lib/store'
import { PeopleScreen, ReplayHub } from './social'
import { BottomNav } from './common'
import { HomeScreen, SearchScreen } from './home-search'
import { TokenScreen } from './token'
import { ProfileScreen } from './profile'
import { BackstageScreen } from './backstage'
import { ShareScreen } from './share'
import { DepositSheet, PositionSheet, TradeSheet } from './sheets'
import { dateTime } from '@/lib/formatting/numbers'

function AppInner() {
  const { ui,state,update } = useReplayStore()
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      if (process.env.NODE_ENV === 'production') navigator.serviceWorker.register('/sw.js').catch(() => {})
      else {
        // Development chunk URLs are reused by HMR; an old offline cache must
        // not serve a previous build. Keep persisted user data untouched.
        navigator.serviceWorker.getRegistrations().then(registrations=>Promise.all(registrations.filter(r=>r.active?.scriptURL===`${location.origin}/sw.js`).map(r=>r.unregister()))).catch(()=>{})
        caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('replay-shell-')).map(k=>caches.delete(k)))).catch(()=>{})
      }
    }
    const viewport = window.visualViewport
    const checkKeyboard = () => { document.documentElement.classList.toggle('keyboard-open', !!viewport && window.innerHeight - viewport.height > 120); document.documentElement.style.setProperty('--visual-height',`${viewport?.height ?? window.innerHeight}px`) }
    viewport?.addEventListener('resize', checkKeyboard)
    return () => { viewport?.removeEventListener('resize', checkKeyboard); document.documentElement.classList.remove('keyboard-open') }
  }, [])
  const appearance={...appearanceDefaults,...state.settings.appearance}
  const withNav = ['home', 'search', 'profile', 'center', 'people'].includes(ui.screen)
  return <main className={`replay-app ${withNav ? 'with-nav' : ''}`} data-screen={ui.screen} data-density={appearance.rowDensity} data-reduced-motion={appearance.reducedMotion||!appearance.animations} style={{'--ui-scale':appearance.scale,'--gutter':`${appearance.gutter}px`,'--page-gutter':`${appearance.gutter}px`,'--nav-offset':`${appearance.navOffset}px`,'--chart-height':`${appearance.chartHeight}px`} as CSSProperties}>
    {state.timeline.type==='replay'&&ui.screen!=='backstage'&&ui.screen!=='share'&&<div className="global-replay-notice" role="status"><span>Replay · {dateTime(state.timeline.timestamp)}</span><button onClick={()=>update(s=>({...s,timeline:{type:'live'}}))}>Jump Live</button></div>}
    {ui.screen === 'home' && <HomeScreen />}
    {ui.screen === 'search' && <SearchScreen />}
    {ui.screen === 'token' && <TokenScreen />}
    {ui.screen === 'profile' && <ProfileScreen />}
    {ui.screen === 'backstage' && <BackstageScreen />}
    {ui.screen === 'share' && <ShareScreen />}
    {ui.screen === 'center' && <ReplayHub/>}
    {ui.screen === 'people' && <PeopleScreen/>}
    {withNav && <BottomNav />}
    {ui.sheet === 'deposit' && <DepositSheet />}
    {ui.sheet === 'trade' && ui.tradeDraft && <TradeSheet />}
    {ui.sheet === 'position' && <PositionSheet />}
    {ui.toast && <div className="toast" role="status">{ui.toast}</div>}
  </main>
}

export default function ReplayApp() { return <StoreProvider><AppInner /></StoreProvider> }
