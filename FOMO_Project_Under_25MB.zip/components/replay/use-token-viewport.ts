'use client'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { Candle, ChartTimeframe } from '@/lib/market/types'
import { tokenChartViewport } from '@/lib/market/viewport'
export function useTokenViewport(candles:Candle[],frame:ChartTimeframe,dense=false,motion=true) {
  const [offset,setOffset]=useState(0),start=useRef(0),pending=useRef(0),raf=useRef<number|null>(null)
  const viewport=useMemo(()=>tokenChartViewport(candles,frame,offset,dense),[candles,frame,offset,dense])
  const sample=useRef({time:0,offset:0,velocity:0}),previous=useRef(candles),anchor=useRef<number|undefined>(undefined)
  useEffect(()=>{
    if(previous.current!==candles&&offset>0&&anchor.current!==undefined){const index=candles.findIndex(c=>c.timestamp===anchor.current);if(index>=0){pending.current=candles.length-1-index;setOffset(pending.current)}}
    previous.current=candles;anchor.current=viewport.selected?.timestamp
  },[candles,offset,viewport.selected?.timestamp])
  useEffect(()=>{if(raf.current!==null)cancelAnimationFrame(raf.current);raf.current=null;setOffset(0);pending.current=0},[frame])
  useEffect(()=>()=>{if(raf.current!==null)cancelAnimationFrame(raf.current)},[])
  const stop=()=>{if(raf.current!==null)cancelAnimationFrame(raf.current);raf.current=null}
  const begin=()=>{stop();start.current=viewport.offset;pending.current=viewport.offset;sample.current={time:performance.now(),offset:viewport.offset,velocity:0}}
  const pan=(fraction:number)=>{const next=Math.max(0,Math.min(viewport.maxOffset,start.current+fraction*Math.max(1,viewport.count-1))),now=performance.now(),dt=now-sample.current.time;sample.current={time:now,offset:next,velocity:dt>=5&&dt<100?(next-sample.current.offset)/dt:0};pending.current=next;if(raf.current===null)raf.current=requestAnimationFrame(()=>{raf.current=null;setOffset(pending.current)})}
  const finish=()=>{
    stop();setOffset(pending.current<.35?0:pending.current)
    const v=sample.current.velocity,started=performance.now()
    if(!motion||matchMedia('(prefers-reduced-motion: reduce)').matches||started-sample.current.time>70||Math.abs(v)<.015)return
    const origin=pending.current,travel=Math.max(-viewport.count*.16,Math.min(viewport.count*.16,v*85))
    const tick=(now:number)=>{const progress=Math.min(1,(now-started)/220),next=Math.max(0,Math.min(viewport.maxOffset,origin+travel*(1-(1-progress)**3)));pending.current=next;setOffset(next<.35?0:next);raf.current=progress<1&&next>0&&next<viewport.maxOffset?requestAnimationFrame(tick):null}
    raf.current=requestAnimationFrame(tick)
  }
  const jumpLive=useCallback(()=>{if(raf.current!==null)cancelAnimationFrame(raf.current);raf.current=null;pending.current=0;setOffset(0)},[])
  return {viewport,begin,pan,finish,jumpLive}
}
