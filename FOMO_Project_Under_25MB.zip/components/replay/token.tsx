'use client'

import { useEffect, useMemo, useState } from 'react'
import { ArrowLeft, Copy, History, Share2, Star } from 'lucide-react'
import { useTokenViewport } from './use-token-viewport'
import { viewportDiagnostics } from '@/lib/market/viewport-diagnostics'
import { chartDefaults, appearanceDefaults } from '@/lib/customization'
import { selectPositionView } from '@/lib/positions/selectors'
import { activeTimestamp, useReplayStore } from '@/lib/store'
import { quoteAt, visibleCandles } from '@/lib/market/timeline'
import { cashAt, derivePositions, positionMetrics } from '@/lib/positions/calculations'
import { dateTime, money, percent, price, quantity } from '@/lib/formatting/numbers'
import type { Asset, ChartTimeframe, Holder, MarketQuote } from '@/lib/market/types'
import { AssetAvatar, Avatar, EmptyState } from './common'
import { ReplayDock } from './replay-dock'
import { BottomSheet } from './sheets'
import { PriceChart, Timeframes } from './chart'

function TokenHeader({ asset }: { asset: Asset }) {
  const { state, update, navigate, setUI, notify } = useReplayStore()
  const watched = state.watchlist.includes(asset.id)
  return <header className="token-header">
    <button className="icon back" aria-label="Back" onClick={() => navigate('home')}><ArrowLeft /></button>
    <AssetAvatar asset={asset} verified={asset.verified} />
    <div className="token-heading">
      <strong>{asset.symbol}<span className="network-badge" title={asset.chain}>≋</span></strong>
      <button onClick={async () => { try { await navigator.clipboard.writeText(asset.contractAddress); notify('Contract copied') } catch { notify(asset.contractAddress) } }} aria-label="Copy contract">{asset.name}<Copy size={12} /></button>
    </div>
    <div className="token-actions">
      <button className="icon" aria-label="Trade history" onClick={() => setUI({ sheet: 'position' })}><History /></button>
      <button className={`icon ${watched ? 'text-accent' : ''}`} aria-label="Watch token" aria-pressed={watched} onClick={() => update(s => ({ ...s, watchlist: watched ? s.watchlist.filter(id => id !== asset.id) : [...s.watchlist, asset.id] }))}><Star fill={watched ? 'currentColor' : 'none'} /></button>
      <button className="icon" aria-label="Share token" onClick={async () => { try { const text = `${asset.symbol} · ${asset.contractAddress}`; if (navigator.share) await navigator.share({ title: `${asset.name} on fomo`, text }); else { await navigator.clipboard.writeText(text); notify('Token details copied') } } catch { notify('Share cancelled or unavailable') } }}><Share2 /></button>
    </div>
  </header>
}

function TokenDetails({ asset, contextQuote }: { asset: Asset; contextQuote?:MarketQuote }) {
  const { state, provider } = useReplayStore()
  const [tab, setTab] = useState<'Holders' | 'Feed' | 'About'>('Holders')
  const [friendsOnly, setFriendsOnly] = useState(false)
  const [holders, setHolders] = useState<Holder[]>([])
  const [cursor,setCursor]=useState<string|null>(null)
  const [error,setError]=useState('')
  const [busy,setBusy]=useState(false)
  useEffect(() => { const controller=new AbortController(); setHolders([]);setCursor(null);setError('');setBusy(true); provider.getHolderPage(asset,'',controller.signal).then(page=>{if(!controller.signal.aborted){setHolders(page.items);setCursor(page.cursor)}}).catch(e=>{if(!controller.signal.aborted)setError(e instanceof Error?e.message:'Holders unavailable')}).finally(()=>{if(!controller.signal.aborted)setBusy(false)}); return ()=>controller.abort() }, [provider, asset.id])

  const quote = contextQuote ?? quoteAt(asset, state.timeline, state.settings.overrides[asset.id])
  const activity = state.tradeEvents.filter(e => e.assetId === asset.id && e.timestamp <= quote.timestamp).sort((a, b) => b.timestamp - a.timestamp)
  return <section className="token-details">
    <div className="detail-tabs" role="tablist" aria-label="Token information">{(['Holders', 'Feed', 'About'] as const).map(v => <button key={v} role="tab" aria-selected={tab === v} className={tab === v ? 'active' : ''} onClick={() => setTab(v)}>{v}{v === 'Holders' && (asset.holders === null ? '' : ` (${quantity(asset.holders)})`)}</button>)}</div>
    {tab === 'Holders' && <>
      {asset.source!=='remote'&&<button className="friends-toggle" role="switch" aria-checked={friendsOnly} onClick={() => setFriendsOnly(v => !v)}><span className={`switch ${friendsOnly ? 'on' : ''}`} /><span>Friends</span></button>}
      {holders.filter(h => !friendsOnly || state.traders.find(t => t.id === h.traderId)?.following).map(holder => {
        if(holder.address)return <article key={holder.id} className="holder wallet-holder"><span className="wallet-glyph">◈</span><div><strong>{holder.address.slice(0,6)}…{holder.address.slice(-4)}</strong><span>{quantity(holder.units)} {asset.symbol}</span></div><b>{quote.unavailable?'Unavailable':money(holder.units*quote.priceUsd)}</b></article>
        const trader = state.traders.find(t => t.id === holder.traderId)
        if(!trader||trader.enabled===false)return null
        const pnl = (quote.priceUsd / holder.entryPriceUsd - 1) * 100
        return <article key={holder.id} className="holder">
          <Avatar src={trader.avatar} name={trader.displayName} size="small" />
          <div className="holder-main"><div className="holder-title"><strong>{trader.displayName}</strong><b>{money(holder.units * quote.priceUsd)}</b></div><div className="holder-sub"><span>Avg. entry: {money(holder.entryMarketCapUsd, true)} MC</span><span className={pnl >= 0 ? 'positive' : 'negative'}>{percent(pnl)}</span></div>{holder.thesis && <p className="thesis">{holder.thesis}</p>}</div>
        </article>
      })}
    </>}
    {tab==='Holders'&&<div className="holder-status">{busy&&<p role="status">Loading holders…</p>}{error&&<p className="form-error">{error}</p>}{!busy&&!error&&!holders.length&&<p>Holder data unavailable</p>}{cursor&&<button className="secondary full" disabled={busy} onClick={async()=>{setBusy(true);try{const page=await provider.getHolderPage(asset,cursor);setHolders(prev=>[...prev,...page.items.filter(h=>!prev.some(p=>p.id===h.id))]);setCursor(page.cursor)}catch(e){setError(e instanceof Error?e.message:'Unable to load holders')}finally{setBusy(false)}}}>Load more</button>}</div>}
    {tab === 'Feed' && <div className="activity-feed">
      {activity.map(event => <article key={event.id} className="activity"><Avatar src={state.profile.avatar} name={state.profile.displayName} size="small" /><div><strong>{state.profile.displayName}</strong><p><span className={event.side === 'buy' ? 'positive' : 'negative'}>{event.side === 'buy' ? 'Bought' : 'Sold'} {money(event.usdValue)}</span> of {asset.symbol}</p><span className="muted">{money(event.marketCapUsd, true)} MC · {dateTime(event.timestamp)}</span></div></article>)}
      {holders.filter(h=>!h.address&&state.traders.some(t=>t.id===h.traderId&&t.enabled!==false)).slice(0, 2).map((holder, i) => { const trader = state.traders.find(t => t.id === holder.traderId)!; return <article key={`fixture-${holder.id}`} className="activity"><Avatar src={trader.avatar} name={trader.displayName} size="small" /><div><strong>{trader.displayName}</strong><p><span className="positive">Bought {money(holder.units * holder.entryPriceUsd)}</span> of {asset.symbol}</p><span className="muted">{money(holder.entryMarketCapUsd, true)} MC · {dateTime(quote.timestamp - (i + 1) * 3_600_000)}</span><p className="thesis">{holder.thesis ?? 'Building a position, one entry at a time.'}</p></div></article> })}
      {!activity.length && !holders.length && <EmptyState title="No activity yet" />}
    </div>}
    {tab === 'About' && <div className="about-token"><p>{asset.description}</p><dl>{[
      ['Network', asset.chain], ['Contract', asset.contractAddress], ['Market cap', money(quote.marketCapUsd, true)], ['FDV', money(asset.fdvUsd, true)], ['Liquidity', money(asset.liquidityUsd, true)], ['24h volume', money(asset.volume24hUsd, true)], ['Supply', asset.supply===undefined?'Unavailable':quantity(asset.supply)], ['Pool',asset.poolAddress??'Unavailable'], ['Pair',asset.pairTokenSymbol??'Unavailable'], ['Created',asset.pairCreatedAt?dateTime(asset.pairCreatedAt):'Unavailable'],
    ].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl><div className="social-links">{([['Website', asset.website], ['X', asset.x], ['Telegram', asset.telegram]] as const).map(([label, href]) => href?.startsWith('https://') ? <a key={label} href={href} target="_blank" rel="noreferrer">{label} ↗</a> : null)}</div></div>}
  </section>
}

function PositionPreview({ position, currentPrice, compact = false }: { position: ReturnType<typeof derivePositions>[number]; currentPrice: number; compact?: boolean }) {
  const {state}=useReplayStore()
  const symbol=state.assets.find(a=>a.id===position.assetId)?.symbol??'tokens'
  const view=selectPositionView(state,position.id)
  if(!view)return null
  const metrics = view.metrics
  return <div className={`position-card ${compact ? 'compact' : ''}`}><div className="position-value"><div><strong>{money(position.status === 'closed' ? position.realizedProceedsUsd : metrics.currentValue)}</strong><span>{position.status === 'closed' ? 'Total proceeds' : `${quantity(position.unitsRemaining)} ${symbol}`}</span></div><div className={metrics.pnlUsd >= 0 ? 'positive' : 'negative'}><strong>{Number.isFinite(metrics.pnlUsd)?(metrics.pnlUsd>=0?'+':'−'):''}{money(Math.abs(metrics.pnlUsd))}</strong><span>{percent(metrics.pnlPct)}</span></div></div>{!compact && <div className="position-cost"><span>Invested <b>{money(position.totalInvestedUsd)}</b></span><span>Avg. entry <b>{price(position.weightedAverageEntryUsd ?? 0)}</b></span></div>}</div>
}

export function TokenScreen() {
  const {state,ui,navigate}=useReplayStore()
  const asset=state.assets.find(a=>a.id===ui.assetId)??state.assets[0]
  return asset?<TokenContent key={asset.id} asset={asset}/>:<div className="screen"><EmptyState title="No token selected"/><button className="primary full" onClick={()=>navigate('search')}>Add token</button></div>
}

function TokenContent({asset}:{asset:Asset}) {
  const {state,ui,setUI,update,provider,setHistory,marketStatus}=useReplayStore()
  const [optionsOpen,setOptionsOpen]=useState(false),[timeframe,setTimeframe]=useState<ChartTimeframe>('ALL')
  const [historyError,setHistoryError]=useState(''),[historyBusy,setHistoryBusy]=useState(false),[historyEnded,setHistoryEnded]=useState(false)
  const chartSettings={...chartDefaults,...state.settings.chart},appearance={...appearanceDefaults,...state.settings.appearance}
  const globalReplayTimestamp=activeTimestamp(state)
  const globalQuote=quoteAt(asset,state.timeline,state.settings.overrides[asset.id])
  const availableHistory=useMemo(()=>state.timeline.type==='replay'?asset.candles.filter(c=>c.timestamp<=globalReplayTimestamp):asset.candles,[asset.candles,state.timeline.type,globalReplayTimestamp])
  const camera=useTokenViewport(availableHistory,timeframe,chartSettings.density==='dense',state.settings.appearance?.animations!==false&&!state.settings.appearance?.reducedMotion&&chartSettings.animation)
  const tokenChartViewport=camera.viewport
  useEffect(()=>{Object.assign(viewportDiagnostics,{assetId:asset.id,first:tokenChartViewport.domain.first,last:tokenChartViewport.domain.last,selected:tokenChartViewport.selected?.timestamp,live:tokenChartViewport.live,candles:tokenChartViewport.candles.length})},[asset.id,tokenChartViewport])
  const baseQuote=tokenChartViewport.live||!tokenChartViewport.selected?globalQuote:quoteAt(asset,{type:'replay',timestamp:tokenChartViewport.selected.timestamp,speed:0})
  const quote=ui.qaMode==='quote-unavailable'?{...baseQuote,unavailable:true,marketCapUsd:null}:baseQuote
  const events=useMemo(()=>state.tradeEvents.filter(e=>e.assetId===asset.id&&e.timestamp<=quote.timestamp),[state.tradeEvents,asset.id,quote.timestamp])
  const positions=useMemo(()=>derivePositions(state.tradeEvents,globalReplayTimestamp).filter(p=>p.assetId===asset.id),[state.tradeEvents,globalReplayTimestamp,asset.id])
  const position=positions.find(p=>p.status==='open')??positions.at(-1)
  const availableCash=useMemo(()=>cashAt(state.cash,state.tradeEvents,globalReplayTimestamp),[state.cash,state.tradeEvents,globalReplayTimestamp])
  useEffect(()=>{if(asset.source!=='remote')return;const controller=new AbortController();setHistoryBusy(true);setHistoryError('');setHistoryEnded(false);provider.getCandles(asset.id,timeframe,undefined,controller.signal).then(c=>{if(!controller.signal.aborted)setHistory(asset.id,c)}).catch(err=>{if(!controller.signal.aborted)setHistoryError(err instanceof Error?err.message:'History unavailable')}).finally(()=>{if(!controller.signal.aborted)setHistoryBusy(false)});return()=>controller.abort()},[asset.id,asset.source,timeframe,provider,setHistory])
  const loadOlder=async()=>{setHistoryBusy(true);try{const before=asset.candles[0]?.timestamp;const rows=await provider.getCandles(asset.id,timeframe,before?before-1:undefined);setHistory(asset.id,rows);setHistoryEnded(!rows.some(c=>!before||c.timestamp<before));setHistoryError('')}catch(err){setHistoryError(err instanceof Error?err.message:'History unavailable')}finally{setHistoryBusy(false)}}
  const trade=(side:'buy'|'sell')=>{if(side==='buy'&&availableCash<=0&&!position){setUI({sheet:'deposit'});return}const candle=asset.candles.filter(c=>c.timestamp<=globalQuote.timestamp).at(-1)??(!globalQuote.unavailable?{timestamp:globalQuote.timestamp,open:globalQuote.priceUsd,high:globalQuote.priceUsd,low:globalQuote.priceUsd,close:globalQuote.priceUsd}:undefined);if(candle)setUI({sheet:'trade',tradeDraft:{side,candle:{...candle,close:globalQuote.priceUsd,marketCapUsd:globalQuote.marketCapUsd}}})}
  const prior=quote.priceChange24hPct===null?null:quote.priceUsd-quote.priceUsd/(1+quote.priceChange24hPct/100)
  return <div className="screen token-screen" data-chart-context={tokenChartViewport.live?state.timeline.type:'historical'} data-context-timestamp={quote.timestamp}>
    <TokenHeader asset={asset}/>
    {ui.qaMode&&ui.qaMode!=='none'&&<p className="market-status">QA preview · {ui.qaMode==='rate-limit'?'Provider rate limit. Retry after cooldown.':ui.qaMode.replaceAll('-',' ')}</p>}
    {optionsOpen&&<BottomSheet title="Chart options" close={()=>setOptionsOpen(false)}><div className="chart-settings"><button role="switch" aria-checked={chartSettings.markers} onClick={()=>update(s=>({...s,settings:{...s.settings,chart:{...s.settings.chart,markers:!chartSettings.markers}}}))}><span>Buy / sell markers</span><span className={`switch ${chartSettings.markers?'on':''}`}/></button><button onClick={()=>update(s=>({...s,settings:{...s.settings,chartStyle:s.settings.chartStyle==='line'?'candles':'line'}}))}>Chart style <strong>{state.settings.chartStyle==='line'?'Line':'Candles'}</strong></button></div></BottomSheet>}
    <section className="quote-hero"><div><h1 data-testid="token-context-price">{quote.unavailable?'Unavailable':price(quote.priceUsd)}</h1><p className={(prior??0)>=0?'positive':'negative'}>{prior===null?'Change unavailable':`${prior>=0?'▴':'▾'} ${price(Math.abs(prior))}`} {quote.priceChange24hPct!==null&&<span>({percent(quote.priceChange24hPct).replace(/[▴▾] /,'')})</span>}</p></div><div className="market-cap"><strong data-testid="token-context-mc">{quote.marketCapUsd===null?'Unavailable':money(quote.marketCapUsd,true)}</strong><span>Market cap</span></div></section>
    <div className="chart-context"><span className={tokenChartViewport.live&&state.timeline.type==='live'?'is-live':''}>{tokenChartViewport.live?(state.timeline.type==='live'?'LIVE':'REPLAY'):dateTime(quote.timestamp)}</span>{!tokenChartViewport.live&&<button className="text-accent" onClick={camera.jumpLive}>Latest ↗</button>}</div>
    {asset.transient&&<button className="secondary full" onClick={()=>update(s=>({...s,assets:s.assets.map(a=>a.id===asset.id?{...a,transient:false}:a)}))}>Track token</button>}
    {!availableHistory.length||ui.qaMode==='candles-unavailable'?<div className="price-chart empty">Historical chart unavailable</div>:<PriceChart candles={tokenChartViewport.candles} rawCandles={availableHistory} domain={tokenChartViewport.domain} events={events} currentPrice={quote.priceUsd} marketCap={quote.marketCapUsd} settings={chartSettings} style={state.settings.chartStyle} chartHeight={appearance.chartHeight} pan={{begin:camera.begin,move:camera.pan,finish:camera.finish}}/>}
    <Timeframes onOptions={()=>setOptionsOpen(true)} value={timeframe} onChange={v=>{setTimeframe(v);camera.jumpLive()}} style={state.settings.chartStyle} onStyle={()=>update(s=>({...s,settings:{...s.settings,chartStyle:s.settings.chartStyle==='line'?'candles':'line'}}))}/>
    {(historyError||marketStatus[asset.id]?.error)&&<p className="market-status">{historyError||'Using the last available quote. Refresh in token settings.'}</p>}
    {asset.source==='remote'&&<div className="history-pagination"><span>{asset.candles.length.toLocaleString()} candles cached</span>{historyEnded?<span>No earlier history available</span>:<button className="text-accent" disabled={historyBusy} onClick={loadOlder}>{historyBusy?'Loading history…':'Load older history'}</button>}</div>}
    {position&&<button className="position-preview" aria-label="Open position" onClick={()=>setUI({sheet:'position',positionId:position.id})}><PositionPreview position={position} currentPrice={globalQuote.priceUsd} compact/></button>}
    <TokenDetails asset={asset} contextQuote={quote}/><div className="token-cta"><button className="primary" disabled={globalQuote.unavailable} onClick={()=>trade('buy')}>{availableCash<=0&&!position?'Deposit to buy':`Buy ${asset.symbol}`}</button>{position?.status==='open'&&<button className="secondary" onClick={()=>trade('sell')}>Sell</button>}</div>
  </div>
}
export { PositionPreview }
