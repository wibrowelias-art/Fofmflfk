'use client'
import { useEffect, useRef, useState } from 'react'
import { ArrowRight, Check, Download, Layers, LoaderCircle } from 'lucide-react'
import { useReplayStore, exportPackedState } from '@/lib/store'
import { templates, buildTemplate, summarize } from '@/lib/templates'
import { templateMarket } from '@/lib/templates/market'
import type { TemplateCandidate, TemplateDefinition } from '@/lib/templates/types'
import { money } from '@/lib/formatting/numbers'
import { BottomSheet } from './sheets'
import { Avatar } from './common'
export function TemplatesBrowser() {
  const {state,replace,notify}=useReplayStore()
  const [selected,setSelected]=useState<TemplateDefinition|null>(null)
  const [candidate,setCandidate]=useState<TemplateCandidate|null>(null)
  const [progress,setProgress]=useState(''), [error,setError]=useState(''), [busy,setBusy]=useState(false), [confirmed,setConfirmed]=useState(false)
  const controller=useRef<AbortController|null>(null)
  useEffect(()=>()=>controller.current?.abort(),[])
  const close=()=>{controller.current?.abort();controller.current=null;setBusy(false);setSelected(null);setCandidate(null);setError('');setProgress('');setConfirmed(false)}
  const preview=(definition:TemplateDefinition)=>{setSelected(definition);setCandidate(null);setError('');setConfirmed(false)}
  const prepare=async()=>{
    if(!selected)return
    const request=new AbortController();controller.current=request;setBusy(true);setError('')
    try{const result=await buildTemplate(selected,state,templateMarket(setProgress),setProgress,request.signal);if(!request.signal.aborted)setCandidate(result)}
    catch(error){if(!request.signal.aborted)setError(error instanceof Error?error.message:'Template could not be prepared. Your setup is unchanged.')}
    finally{if(!request.signal.aborted)setBusy(false)}
  }
  const exportCurrent=async()=>{
    try{const text=await exportPackedState(state),url=URL.createObjectURL(new Blob([text],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='replay-setup-before-template.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
    catch(error){setError(error instanceof Error?error.message:'Export failed')}
  }
  const hasData=state.cash!==0||state.assets.length>0||state.tradeEvents.length>0||state.watchlist.length>0||state.searchRecents.length>0
  const totals=candidate?summarize(candidate.state):null
  const badge=state.settings.loadedTemplate
  return <section className="templates-section" aria-label="Templates"><div className="templates-heading"><Layers size={21}/><div><h3>Templates</h3><p>A different market story, ready to replay.</p></div></div>
    {badge&&<div className="loaded-template"><Check size={15}/><span>Loaded template: <strong>{badge.name}</strong><small>Loaded {new Date(badge.loadedAt).toLocaleString()}</small></span></div>}
    <p className="small muted">Local practice portfolios. Discovery and historical prices come from read-only market providers.</p>
    <div className="template-grid">{templates.map(def=><button className={`template-card template-${def.id}`} key={def.id} aria-label={`Preview ${def.name}`} onClick={()=>preview(def)}><span className="template-category">{def.category}</span><h4>{def.name}</h4><p>{def.description}</p><div className="template-numbers"><strong>{money(def.startingCash,true)}<small>Local cash</small></strong><span>≈{def.assets} tokens · {def.events} trades<small>{def.open} open · {def.closed} closed</small></span></div><span className="template-preview-link">Load template <ArrowRight size={16}/></span></button>)}</div>
    {selected&&<BottomSheet title={selected.name} close={close}><div className="template-preview"><p>{selected.description}</p><div className="template-practice-label">Replay · Learning · local practice</div><p className="small muted">Keeps your name, handle, avatar, bio, social counts, joined date and chart style. Trade statistics are derived from the new history. Manual quote overrides are cleared.</p>
      {!candidate&&<><p className="small">Preview first: find current tokens and available candles, build practice events, then check the complete setup. Your current setup stays in place while this runs.</p><button className="primary full" disabled={busy} onClick={prepare}>{busy?<><LoaderCircle size={17} className="template-spinner"/>Preparing…</>:'Prepare preview'}</button></>}
      {progress&&<p className="template-progress" role="status" aria-live="polite">{progress}</p>}
      {totals&&candidate&&<><p className="template-source">{candidate.source}</p><div className="template-avatars">{candidate.state.assets.filter((a,i,all)=>a.iconUrl&&all.findIndex(b=>b.iconUrl===a.iconUrl)===i).slice(0,7).map(a=><Avatar key={a.id} src={a.iconUrl} name={a.symbol}/>)}</div><dl className="template-summary">{[['Cash',money(totals.cash)],['Tracked assets',totals.assets],['Watchlist',totals.watchlist],['TradeEvents',totals.events],['Open positions',totals.open],['Closed positions',totals.closed],['Replay history',`${totals.history.toLocaleString()} candles`],['Profile performance history',`${totals.performance} derived points`],['Search recents',totals.recents],['Weekly Top Trades',`${totals.weekly} practice entries`],['Favorites',totals.favorites]].map(([name,value])=><div key={name}><dt>{name}</dt><dd>{value}</dd></div>)}</dl>
        <p className="small muted">Portfolio value, PnL, average entries/exits and Fumble are calculated from these practice events. Historical market cap stays unavailable where the provider supplies no history.</p>
        {candidate.warnings.length>0&&<details className="template-warnings"><summary>{candidate.warnings.length} unavailable markets skipped</summary>{candidate.warnings.map((w,i)=><p key={i}>{w}</p>)}</details>}
        {hasData&&<label className="template-confirm"><input type="checkbox" checked={confirmed} onChange={e=>setConfirmed(e.target.checked)}/><span>Replace my current local cash, assets, watchlist, events and replay history with this setup.</span></label>}
        <button className="primary full" disabled={hasData&&!confirmed} onClick={()=>{try{replace(candidate.state);notify(`${selected.name} loaded`);close()}catch(error){setError(error instanceof Error?error.message:'Could not save template. Current setup preserved.')}}}>Load template</button></>}
      {error&&<p className="form-error" role="alert">{error}</p>}<button className="secondary full template-export" onClick={exportCurrent}><Download size={17}/>Export current setup first</button><button className="text-accent full" onClick={close}>Cancel</button>
    </div></BottomSheet>}
  </section>
}
