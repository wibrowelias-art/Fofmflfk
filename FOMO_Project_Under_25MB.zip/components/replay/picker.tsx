'use client'
import { useState } from 'react'
import { BottomSheet } from './sheets'
export function Picker({label,value,options,onChange}:{label:string;value:string;options:{value:string;label:string}[];onChange:(v:string)=>void}) {
  const [open,setOpen]=useState(false)
  return <><button className="picker-button" aria-label={label} aria-haspopup="dialog" onClick={()=>setOpen(true)}>{options.find(o=>o.value===value)?.label ?? value}<span>⌄</span></button>{open&&<BottomSheet title={label} close={()=>setOpen(false)}><div className="picker-options">{options.map(o=><button key={o.value} aria-pressed={value===o.value} onClick={()=>{onChange(o.value);setOpen(false)}}>{o.label}<span>{value===o.value?'✓':''}</span></button>)}</div></BottomSheet>}</>
}
