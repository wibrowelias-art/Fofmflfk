'use client'
import { useEffect, useState } from 'react'
import { useReplayStore } from '@/lib/store'
import { Avatar } from '../common'
import { ImageEditor, Toggle } from './controls'
export function ProfileEditor() {
  const {state,update,notify}=useReplayStore(),[draft,setDraft]=useState(state.profile),[error,setError]=useState('')
  useEffect(()=>{
    if(!draft.displayName.trim()||!draft.handle.trim()||!Number.isFinite(Date.parse(draft.joinedDate)))return
    const timer=setTimeout(()=>update(s=>s.profile===draft?s:{...s,profile:draft}),180)
    return()=>clearTimeout(timer)
  },[draft,update])
  const crop=draft.avatarPosition??{x:50,y:50,zoom:1}
  return <section className="backstage-panel"><div className="control-heading"><div><small>IDENTITY</small><h2>Your profile</h2></div><span className="control-tag">Live preview</span></div>
    <div className="profile-live-preview"><div className="preview-cover" style={draft.cover?{backgroundImage:`url("${draft.cover}")`,backgroundPosition:`center ${draft.coverPosition??50}%`}:undefined}/><Avatar src={draft.avatar} name={draft.displayName} size="large" verified={draft.verified} position={crop}/><h3>{draft.displayName||'Your name'}</h3><p>@{draft.handle}</p>{draft.bio&&<p>{draft.bio}</p>}<small>{draft.following} Following · {draft.followers} Followers</small></div>
    <ImageEditor value={draft.avatar} onChange={avatar=>setDraft(d=>({...d,avatar,avatarKey:undefined}))}/>
    <details className="control-disclosure"><summary>Avatar crop & position</summary>{([['Horizontal','x',0,100],['Vertical','y',0,100],['Zoom','zoom',1,3]] as const).map(([label,key,min,max])=><label className="field" key={key}>{label}<input aria-label={`Avatar ${label.toLowerCase()}`} type="range" min={min} max={max} step={key==='zoom'?.05:1} value={crop[key]} onChange={e=>setDraft(d=>({...d,avatarPosition:{...crop,[key]:Number(e.target.value)}}))}/></label>)}</details>
    <ImageEditor label="Cover" cover value={draft.cover??''} onChange={cover=>setDraft(d=>({...d,cover}))}/>
    <label className="field">Cover position<input aria-label="Cover position" type="range" min="0" max="100" value={draft.coverPosition??50} onChange={e=>setDraft(d=>({...d,coverPosition:Number(e.target.value)}))}/></label>
    <div className="form-grid">{(['displayName','handle'] as const).map(key=><label className="field" key={key}>{key==='displayName'?'Display name':'Handle'}<input value={draft[key]} maxLength={60} onChange={e=>setDraft({...draft,[key]:e.target.value})}/></label>)}</div>
    <label className="field">Bio<textarea value={draft.bio} maxLength={200} rows={2} onChange={e=>setDraft({...draft,bio:e.target.value})}/></label>
    <label className="field">Cover position<input aria-label="Cover position" type="range" min="0" max="100" value={draft.coverPosition??50} onChange={e=>setDraft(d=>({...d,coverPosition:Number(e.target.value)}))}/></label>
    <div className="form-grid">{(['followers','following'] as const).map(key=><label className="field" key={key}>{key==='followers'?'Followers':'Following'}<input type="number" min="0" step="1" value={draft[key]} onChange={e=>setDraft({...draft,[key]:Math.max(0,Math.floor(Number(e.target.value)))})}/></label>)}<label className="field">Joined date<input type="date" value={draft.joinedDate} onChange={e=>setDraft({...draft,joinedDate:e.target.value})}/></label></div>
    <Toggle label="Verified appearance" value={!!draft.verified} onChange={verified=>setDraft({...draft,verified})}/><Toggle label="Manual statistics" value={!!draft.manualStats} onChange={manualStats=>setDraft({...draft,manualStats})}/>
    <p className="small muted">Statistics follow your trades unless manual display is enabled. Editing an override enables manual display.</p>
    <label className="field">Cover position<input aria-label="Cover position" type="range" min="0" max="100" value={draft.coverPosition??50} onChange={e=>setDraft(d=>({...d,coverPosition:Number(e.target.value)}))}/></label>
    <div className="form-grid"><label className="field">Average hold<input value={draft.averageHold} onChange={e=>setDraft({...draft,manualStats:true,averageHold:e.target.value})}/></label><label className="field">Base trade count<input type="number" min="0" value={draft.tradeCount} onChange={e=>setDraft({...draft,manualStats:true,tradeCount:Math.max(0,Math.floor(Number(e.target.value)))})}/></label></div>
    {error&&<p className="form-error" role="alert">{error}</p>}<button className="primary full" onClick={()=>{if(!draft.displayName.trim()||!draft.handle.trim()||!Number.isFinite(Date.parse(draft.joinedDate)))return setError('Name, handle and joined date are required.');update(s=>({...s,profile:draft}));setError('');notify('Profile saved')}}>Save profile</button>
  </section>
}
