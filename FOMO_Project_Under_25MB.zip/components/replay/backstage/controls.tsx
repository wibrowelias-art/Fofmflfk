'use client'
import { useState } from 'react'
import { Avatar } from '../common'
import { avatarGallery, validImage } from '@/lib/customization'
import { blobDataUrl, cacheGet, cacheDelete, prepareAvatar } from '@/lib/storage'

export function Toggle({label,value,onChange}:{label:string;value:boolean;onChange:(v:boolean)=>void}) { return <button className="control-toggle" role="switch" aria-checked={value} onClick={()=>onChange(!value)}><span>{label}</span><span className={`switch ${value?'on':''}`}/></button> }
export function StatGrid({items}:{items:Array<[string,string|number]>}) { return <dl className="control-stats">{items.map(([label,value])=><div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl> }
export function ImageEditor({value,onChange,label='Avatar',cover=false}:{value:string;onChange:(v:string)=>void;label?:string;cover?:boolean}) {
  const [url,setUrl]=useState(value.startsWith('https:')?value:''),[error,setError]=useState('')
  return <details className="control-disclosure"><summary>{label} controls</summary><div className="image-editor-controls">
    <label className="secondary file-button">Upload {label.toLowerCase()}<input type="file" accept="image/png,image/jpeg,image/webp" onChange={async e=>{const file=e.target.files?.[0];if(!file)return;try{if(cover){if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>3000000)throw new Error('Choose a PNG, JPEG or WebP smaller than 3 MB.');onChange(await blobDataUrl(file))}else{const result=await prepareAvatar(file);const blob=result.avatarKey?await cacheGet<Blob>(result.avatarKey):null;onChange(blob?await blobDataUrl(blob):result.avatar);if(result.avatar.startsWith('blob:'))URL.revokeObjectURL(result.avatar);if(result.avatarKey)await cacheDelete(result.avatarKey)}setError('')}catch(err){setError(err instanceof Error?err.message:'Image unavailable')}e.target.value=''}}/></label>
    <label className="field">{label} URL<input type="url" value={url} placeholder="https://…" onChange={e=>setUrl(e.target.value)}/></label><button className="secondary" onClick={()=>{if(!validImage(url))return setError('Use an HTTPS image URL.');onChange(url);setError('')}}>Apply {label.toLowerCase()} URL</button>
    {!cover&&<div className="avatar-gallery" aria-label="Authorized avatar gallery">{avatarGallery.map((src,i)=><button key={src} aria-label={`Choose avatar ${i+1}`} aria-pressed={value===src} onClick={()=>onChange(src)}><Avatar src={src} name={`Avatar ${i+1}`}/></button>)}</div>}
    <button className="text-accent" onClick={()=>{onChange(cover?'':'/art/profile.svg');setUrl('');setError('')}}>Reset {label.toLowerCase()}</button>{error&&<p className="form-error" role="alert">{error}</p>}
  </div></details>
}
