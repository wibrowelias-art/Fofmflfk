'use client'
import { useState } from 'react'
import { Download, Upload, RotateCcw } from 'lucide-react'
import { activeTimestamp, makeInitialState, parseBackup, useReplayStore } from '@/lib/store'
import type { AppState } from '@/lib/store-types'
import { summarize } from '@/lib/templates'
import { money, dateTime } from '@/lib/formatting/numbers'
import { BottomSheet } from '../sheets'
import { TemplatesBrowser } from '../templates-browser'
import { StatGrid } from './controls'
import { downloadSetup, useSavedState } from './overview'
export function DataEditor() {
  const {state,replace,notify}=useReplayStore(),[candidate,setCandidate]=useState<AppState|null>(null),[error,setError]=useState(''),saved=useSavedState(),summary=summarize(state)
  return <section className="backstage-panel"><div className="control-heading"><div><small>BACKUP & RESTORE</small><h2>Your setup, everywhere</h2></div><span className="control-tag">Schema v2</span></div><StatGrid items={[["Saved size",`${(saved.bytes/1024).toFixed(1)} KB`],["Tracked assets",summary.assets],["Open / closed",`${summary.open} / ${summary.closed}`],["TradeEvents",summary.events],["Replay state",state.timeline.type],["Cached candles",summary.history]]}/><p className="small muted">Last save: {saved.last}<br/>{dateTime(activeTimestamp(state))} · {state.settings.loadedTemplate?.name??'Custom setup'}</p>
    <button className="data-action" onClick={()=>downloadSetup(state).catch(err=>setError(err.message))}><Download/><span><strong>Export setup</strong><span>Portable versioned backup</span></span></button><label className="data-action"><Upload/><span><strong>Import setup</strong><span>Preview before replacing your data</span></span><input aria-label="Import setup" type="file" accept="application/json,.json" onChange={async e=>{const file=e.target.files?.[0];if(!file)return;try{if(file.size>15000000)throw new Error('File is too large.');setCandidate(parseBackup(await file.text()));setError('')}catch(err){setError(err instanceof Error?err.message:'Import failed')}e.target.value=''}}/></label><button className="data-action negative" onClick={()=>{if(confirm('Reset your local setup? Export a backup first to keep your trades.'))try{replace(makeInitialState());notify('Fresh setup ready')}catch(err){setError(err instanceof Error?err.message:'Reset failed')}}}><RotateCcw/><span><strong>Reset setup</strong><span>Empty portfolio and $0 cash</span></span></button>{error&&<p className="form-error" role="alert">{error}</p>}
    {candidate&&<BottomSheet title="Import preview" close={()=>setCandidate(null)}><p>Replace the saved setup with this validated backup?</p><StatGrid items={[["Profile",`${state.profile.displayName} → ${candidate.profile.displayName}`],["Cash",`${money(state.cash)} → ${money(candidate.cash)}`],["Assets",`${state.assets.length} → ${candidate.assets.length}`],["TradeEvents",`${state.tradeEvents.length} → ${candidate.tradeEvents.length}`],["Positions",`${state.positions.length} → ${candidate.positions.length}`],["Timeline",candidate.timeline.type]]}/><button className="primary full" onClick={()=>{try{replace(candidate);setCandidate(null);notify('Setup imported')}catch(err){setError(err instanceof Error?err.message:'Import failed')}}}>Replace with imported setup</button><button className="text-accent full" onClick={()=>setCandidate(null)}>Cancel import</button></BottomSheet>}
    <TemplatesBrowser/><div className="about-replay"><h3>About Replay</h3><p>Independent local market replay and learning. Practice trades stay on this device. No wallets or real payments are connected.</p></div>
  </section>
}
