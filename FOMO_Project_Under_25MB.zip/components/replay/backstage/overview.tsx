'use client'
import { useEffect, useState } from 'react'
import { activeTimestamp, exportPackedState, useReplayStore } from '@/lib/store'
import type { BackstageTab } from '@/lib/store-types'
import { selectPortfolioAt } from '@/lib/positions/selectors'
import { dateTime, money, signedMoney } from '@/lib/formatting/numbers'
import { StatGrid } from './controls'
export async function downloadSetup(state:Parameters<typeof exportPackedState>[0]) {
  const text=await exportPackedState(state),url=URL.createObjectURL(new Blob([text],{type:'application/json'})),link=document.createElement('a')
  link.href=url;link.download='replay-setup.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000)
}
export function useSavedState() {
  const [saved,setSaved]=useState({bytes:0,last:'Not saved yet'})
  useEffect(()=>{const read=()=>{const text=localStorage.getItem('replay:setup:v1')??'';try{const data=JSON.parse(text||'{}');setSaved({bytes:new Blob([text]).size,last:data.savedAt?new Date(data.savedAt).toLocaleString():'Previous version'})}catch{setSaved({bytes:text.length,last:'Unreadable backup'})}};read();const id=setInterval(read,1500);return()=>clearInterval(id)},[])
  return saved
}
export function OverviewEditor({open}:{open:(tab:BackstageTab)=>void}) {
  const {state,update,marketStatus,notify}=useReplayStore(),saved=useSavedState(),portfolio=selectPortfolioAt(state),positions=portfolio.positions
  return <section className="backstage-panel"><div className="control-heading"><div><small>WORKSPACE</small><h2>Overview</h2></div><span className="control-tag">{state.timeline.type==='live'?'LIVE':'REPLAY'}</span></div>
    <div className="overview-balance"><small>Portfolio value</small><strong>{money(portfolio.value)}</strong><span>Local practice portfolio</span></div>
    <StatGrid items={[["Practice cash",money(portfolio.cash)],["Watchlist",state.watchlist.length],["Realized PnL",signedMoney(portfolio.realizedPnl)],["Unrealized PnL",signedMoney(portfolio.unrealizedPnl)],["Tracked assets",state.assets.filter(a=>!a.transient).length],["Open positions",positions.filter(v=>v.position.status==='open').length],["Closed positions",positions.filter(v=>v.position.status==='closed').length],["TradeEvents",state.tradeEvents.length],["Cached candles",state.assets.reduce((n,a)=>n+a.candles.length,0)],["Provider state",Object.values(marketStatus).some(s=>s.error)?'Attention needed':state.assets.some(a=>a.source==='remote')?'Monitoring':'No remote tokens'],["Saved state",`${(saved.bytes/1024).toFixed(1)} KB`]]}/>
    <div className="control-context"><span>{dateTime(activeTimestamp(state))}</span><span>{state.settings.loadedTemplate?.name??'Custom setup'}</span></div>
    <div className="quick-actions">{([['Add token','Tokens'],['Create practice trade','Positions'],['Edit profile','Profile'],['Edit Weekly','Weekly'],['Open replay','Replay'],['Load template','Templates']] as const).map(([name,tab])=><button className="secondary" key={tab} onClick={()=>open(tab)}>{name} ↗</button>)}<button className="secondary" onClick={()=>update(s=>({...s,timeline:{type:'live'}}))}>Jump Live</button><button className="secondary" onClick={()=>downloadSetup(state).catch(()=>notify('Export unavailable'))}>Export</button></div>
    <h3>Recent local activity</h3><div className="cash-log">{state.tradeEvents.filter(e=>e.timestamp<=activeTimestamp(state)).slice().sort((a,b)=>b.timestamp-a.timestamp).slice(0,5).map(e=><article key={e.id}><div><strong>{e.side==='buy'?'Bought':'Sold'} {state.assets.find(a=>a.id===e.assetId)?.symbol}</strong><small>{dateTime(e.timestamp)}</small></div><span>{money(e.usdValue)}</span></article>)}</div>{!state.tradeEvents.length&&<p className="small muted">Your next practice trade will appear here.</p>}
  </section>
}
