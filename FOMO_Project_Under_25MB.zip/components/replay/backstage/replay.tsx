'use client'
import { useEffect, useMemo, useRef, useState } from 'react'
import { activeTimestamp, useReplayStore } from '@/lib/store'
import { nearestCandle, quoteAt, visibleCandles } from '@/lib/market/timeline'
import { cashAt, derivePositions } from '@/lib/positions/calculations'
import { dateTime, money, price } from '@/lib/formatting/numbers'
import { chartDefaults } from '@/lib/customization'
import { PriceChart, Timeframes } from '../chart'
import { ReplayDock } from '../replay-dock'
import { Picker } from '../picker'
import { EmptyState, AssetAvatar } from '../common'
import { StatGrid } from './controls'
import { BottomSheet } from '../sheets'
import type { ChartTimeframe } from '@/lib/market/types'
export function ReplayEditor() {
  const {state,ui,setUI,update,setScrubbing,provider,setHistory}=useReplayStore(),asset=state.assets.find(a=>a.id===state.settings.replayAssetId)??state.assets[0]
  const [timeframe,setTimeframe]=useState<ChartTimeframe>('ALL'),[options,setOptions]=useState(false),[error,setError]=useState(''),[busy,setBusy]=useState(false),[ended,setEnded]=useState(false),[exact,setExact]=useState('')
  const frame=useRef<number|null>(null),pending=useRef<number|null>(null),assetRef=useRef(asset);assetRef.current=asset
  const setTime=(time:number)=>{const a=assetRef.current;if(!a)return;const candle=nearestCandle(a.candles,time);if(candle)update(s=>({...s,settings:{...s.settings,replayAssetId:a.id},timeline:{type:'replay',timestamp:candle.timestamp,speed:0}}))}
  const finish=()=>{if(frame.current!==null){cancelAnimationFrame(frame.current);frame.current=null}setScrubbing(false);if(pending.current!==null)setTime(pending.current);pending.current=null}
  useEffect(()=>()=>{if(frame.current!==null)cancelAnimationFrame(frame.current);setScrubbing(false)},[setScrubbing])
  useEffect(()=>{setEnded(false);setError('')},[asset?.id])
  useEffect(()=>{if(ui.replayStart!==undefined&&asset?.candles.length){setTime(ui.replayStart);setUI({replayStart:undefined})}},[ui.replayStart,asset?.id,asset?.candles.length])
  const timestamp=activeTimestamp(state),quote=asset?quoteAt(asset,state.timeline,state.settings.overrides[asset.id]):null
  const candles=useMemo(()=>asset?visibleCandles(asset.candles,timeframe,timestamp):[],[asset?.candles,timeframe,timestamp])
  const events=useMemo(()=>state.tradeEvents.filter(e=>e.assetId===asset?.id&&e.timestamp<=timestamp),[state.tradeEvents,asset?.id,timestamp])
  if(!asset)return <section className="backstage-panel"><EmptyState title="No replay yet">Track a token with available history to begin.</EmptyState></section>
  const first=asset.candles[0]?.timestamp??timestamp,last=asset.candles.at(-1)?.timestamp??timestamp
  const positions=derivePositions(state.tradeEvents,timestamp)
  return <section className="backstage-panel replay-workbench"><div className="control-heading"><div><small>GLOBAL TIMELINE</small><h2>Market replay</h2></div><span className="control-tag">{state.timeline.type.toUpperCase()}</span></div>
    <Picker label="Replay asset" value={asset.id} options={state.assets.map(a=>({value:a.id,label:`${a.symbol} · ${a.chain}`}))} onChange={id=>update(s=>({...s,settings:{...s.settings,replayAssetId:id},timeline:s.timeline.type==='replay'?{...s.timeline,speed:0}:s.timeline}))}/>
    <div className="replay-quote"><AssetAvatar asset={asset}/><div><strong>{asset.symbol}</strong><span>{dateTime(timestamp)}</span></div><div><h3 data-testid="replay-price">{quote?.unavailable?'Unavailable':price(quote?.priceUsd??null)}</h3><span>{quote?.marketCapUsd===null?'MC unavailable':`${money(quote?.marketCapUsd??null,true)} MC`}</span></div></div>
    <PriceChart candles={candles} rawCandles={asset.candles} domain={{first,last}} events={events} currentPrice={quote?.priceUsd??0} settings={{...chartDefaults,...state.settings.chart}} marketCap={quote?.marketCapUsd} style={state.settings.chartStyle} chartHeight={300} cursor={{timestamp:Math.min(last,timestamp),price:quote?.priceUsd??0}} scrub={{begin:()=>{pending.current=null;setScrubbing(true)},move:fraction=>{pending.current=first+fraction*(last-first);if(frame.current===null)frame.current=requestAnimationFrame(()=>{frame.current=null;if(pending.current!==null)setTime(pending.current)})},finish}}/>
    <Timeframes onOptions={()=>setOptions(true)} value={timeframe} onChange={setTimeframe} style={state.settings.chartStyle} onStyle={()=>update(s=>({...s,settings:{...s.settings,chartStyle:s.settings.chartStyle==='candles'?'line':'candles'}}))}/>
    {options&&<BottomSheet title="Chart options" close={()=>setOptions(false)}><div className="chart-settings"><button role="switch" aria-checked={state.settings.chart?.markers!==false} onClick={()=>update(s=>({...s,settings:{...s.settings,chart:{...s.settings.chart,markers:s.settings.chart?.markers===false}}}))}>Buy / sell markers <strong>{state.settings.chart?.markers===false?'Off':'On'}</strong></button></div></BottomSheet>}<ReplayDock asset={asset}/><div className="replay-bounds"><time>{dateTime(first)}</time><time>{dateTime(last)}</time></div>
    <div className="quick-actions"><button className="primary" disabled={!candles.length} onClick={()=>{const c=nearestCandle(asset.candles,timestamp);if(c)setUI({assetId:asset.id,sheet:'trade',tradeDraft:{side:'buy',candle:{...c,marketCapUsd:quote?.marketCapUsd}}})}}>Buy {asset.symbol}</button>{positions.some(p=>p.assetId===asset.id&&p.status==='open')&&<button className="secondary" onClick={()=>{const c=nearestCandle(asset.candles,timestamp);if(c)setUI({assetId:asset.id,sheet:'trade',tradeDraft:{side:'sell',candle:{...c,marketCapUsd:quote?.marketCapUsd}}})}}>Sell</button>}{positions.some(p=>p.assetId===asset.id)&&<button className="secondary" onClick={()=>setUI({assetId:asset.id,positionId:positions.filter(p=>p.assetId===asset.id).at(-1)?.id??null,sheet:'position'})}>Open position</button>}</div>
    <label className="field">Exact replay timestamp<input aria-label="Exact replay timestamp" type="datetime-local" step="1" value={exact} onChange={e=>setExact(e.target.value)}/></label><button className="secondary full" onClick={()=>{const time=new Date(exact).getTime();if(!Number.isFinite(time))return setError('Choose a valid date and time.');setTime(time);setError('')}}>Go to timestamp</button>
    <StatGrid items={[["Visible / total candles",`${candles.length} / ${asset.candles.length}`],["Events through T",events.length],["Cash through T",money(cashAt(state.cash,state.tradeEvents,timestamp))],["Positions through T",positions.length],["Timeframe",timeframe],["Provider",asset.provider??'Local fixture']]}/>
    {asset.source==='remote'&&<div className="history-pagination"><span>{asset.candles.length.toLocaleString()} candles cached</span>{ended?<span>No earlier history available</span>:<button className="text-accent" disabled={busy} onClick={async()=>{setBusy(true);setError('');try{const before=asset.candles.length?first-1:undefined;const page=await provider.getCandles(asset.id,timeframe,before);const older=page.filter(c=>before===undefined||c.timestamp<=before);setHistory(asset.id,older);setEnded(!older.length)}catch(err){setError(err instanceof Error?err.message:'History unavailable')}finally{setBusy(false)}}}>{busy?'Loading history…':'Load older history'}</button>}</div>}
    {error&&<p className="form-error" role="alert">{error}</p>}<p className="small muted">Drag this chart or timeline to reconstruct cash, holdings and performance across the app. Future candles and events stay hidden.</p>
  </section>
}
