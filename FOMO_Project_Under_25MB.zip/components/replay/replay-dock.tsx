'use client'
import { useEffect, useRef, useState } from 'react'
import { ChevronLeft, ChevronRight, Pause, Play, SkipBack } from 'lucide-react'
import { Picker } from './picker'
import { useReplayStore } from '@/lib/store'
import type { Asset } from '@/lib/market/types'
import type { ReplaySpeed } from '@/lib/store-types'
import { lowerBound, nearestCandle } from '@/lib/market/timeline'
import { dateTime } from '@/lib/formatting/numbers'
export function ReplayDock({asset}:{asset:Asset}) {
  const {state,update,setScrubbing}=useReplayStore(), candles=asset.candles, timeline=state.timeline
  const [speed,setSpeed]=useState('1')
  const [dragIndex,setDragIndex]=useState<number|null>(null)
  const dragging=useRef(false), frame=useRef<number|null>(null), pending=useRef(0)
  useEffect(()=>()=>{if(frame.current!==null)cancelAnimationFrame(frame.current);setScrubbing(false)},[setScrubbing])
  if(!candles.length)return <p className="market-status">Historical chart unavailable</p>
  const timestamp=timeline.type==='replay'?timeline.timestamp:candles.at(-1)!.timestamp
  const index=dragIndex??lowerBound(candles,nearestCandle(candles,timestamp)!.timestamp)
  const move=(i:number,speed:ReplaySpeed=0)=>update(s=>({...s,settings:{...s.settings,replayAssetId:asset.id},timeline:{type:'replay',timestamp:candles[Math.max(0,Math.min(candles.length-1,i))].timestamp,speed}}))
  const point=(e:React.PointerEvent<HTMLDivElement>)=>{
    const rect=e.currentTarget.getBoundingClientRect()
    pending.current=Math.round(Math.max(0,Math.min(1,(e.clientX-rect.left)/rect.width))*(candles.length-1))
    if(frame.current===null)frame.current=requestAnimationFrame(()=>{frame.current=null;setDragIndex(pending.current);move(pending.current)})
  }
  const finish=()=>{if(!dragging.current)return;dragging.current=false;if(frame.current!==null){cancelAnimationFrame(frame.current);frame.current=null}setScrubbing(false);move(pending.current);setDragIndex(null)}
  const running=timeline.type==='replay'?timeline.speed:0
  return <section className="replay-dock" aria-label="Replay controller">
    <div className="replay-caption"><strong>Replay</strong><button className="text-accent" onClick={()=>update(s=>({...s,timeline:{type:'live'}}))}>Jump Live</button></div>
    <div className="replay-scrubber" role="slider" tabIndex={0} aria-label="Replay timeline" aria-valuemin={0} aria-valuemax={candles.length-1} aria-valuenow={index} aria-valuetext={dateTime(candles[index].timestamp)}
      onPointerDown={e=>{e.currentTarget.setPointerCapture(e.pointerId);dragging.current=true;setScrubbing(true);point(e)}} onPointerMove={e=>{if(dragging.current)point(e)}} onPointerUp={finish} onPointerCancel={finish}
      onKeyDown={e=>{const next=e.key==='Home'?0:e.key==='End'?candles.length-1:e.key==='ArrowLeft'||e.key==='ArrowDown'?index-1:e.key==='ArrowRight'||e.key==='ArrowUp'?index+1:e.key==='PageUp'?index+10:e.key==='PageDown'?index-10:null;if(next!==null){e.preventDefault();move(next)}}}>
      <span className="scrubber-track"><span style={{width:`${index/Math.max(1,candles.length-1)*100}%`}}/></span><span className="scrubber-thumb" style={{left:`${index/Math.max(1,candles.length-1)*100}%`}}/>
    </div>
    <div className="replay-time"><time>{dateTime(candles[index].timestamp)}</time><span>{index+1} / {candles.length.toLocaleString()}</span></div>
    <div className="replay-controls">
      <button aria-label="Jump to beginning" onClick={()=>move(0)}><SkipBack size={17}/></button>
      <button aria-label="Previous candle" onClick={()=>move(index-1)}><ChevronLeft size={19}/></button>
      <button aria-label={`Reverse ${speed}x`} aria-pressed={running<0} onClick={()=>move(index,-Number(speed) as ReplaySpeed)}><Play size={16} className="reverse-play"/></button>
      <button aria-label="Pause" aria-pressed={timeline.type==='replay'&&running===0} onClick={()=>move(index)}><Pause size={18}/></button>
      <button aria-label={`Forward ${speed}x`} aria-pressed={running>0} onClick={()=>move(index,Number(speed) as ReplaySpeed)}><Play size={16}/></button>
      <button aria-label="Next candle" onClick={()=>move(index+1)}><ChevronRight size={19}/></button>
      <Picker label="Playback speed" value={speed} options={['1','5','10','50'].map(value=>({value,label:`${value}×`}))} onChange={value=>{setSpeed(value);if(running)move(index,(Math.sign(running)*Number(value)) as ReplaySpeed)}}/>
    </div>
  </section>
}
