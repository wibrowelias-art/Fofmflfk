'use client'

import React, { useEffect, useRef, useState } from 'react'
import { CreditCard, QrCode, Share2, X, ChevronRight } from 'lucide-react'
import { useReplayStore } from '@/lib/store'
import { derivePositions, cashAt } from '@/lib/positions/calculations'
import { selectPositionView } from '@/lib/positions/selectors'
import { calculateFumble } from '@/lib/positions/fumble'
import { quoteAt, visibleCandles } from '@/lib/market/timeline'
import { dateTime, decimal, money, price, quantity, percent } from '@/lib/formatting/numbers'
import type { ChartTimeframe } from '@/lib/market/types'
import { AssetAvatar, Avatar, EmptyState, Segmented } from './common'
import { PriceChart, Timeframes } from './chart'
import { PositionPreview } from './token'

export function BottomSheet({ title, close, children, className = '' }: { title: string; close: () => void; children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLElement | null>(null)
  const closeRef = useRef(close)
  const dragStart=useRef(0),[dragOffset,setDragOffset]=useState(0)
  closeRef.current = close
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null
    const overflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const sheetKey=crypto.randomUUID()
    const onBack=()=>{if(history.state?.replaySheet!==sheetKey)closeRef.current()}
    // Defer registration past Strict Mode's setup/cleanup probe. A queued
    // history.back from that probe must not dismiss the actual sheet.
    const historyTimer=setTimeout(()=>{history.pushState({...history.state,replaySheet:sheetKey},'');window.addEventListener('popstate',onBack)},0)
    ref.current?.focus()
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeRef.current()
      if (e.key === 'Tab') {
        const focusable = ref.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input,select,textarea,[tabindex="0"]')
        if (!focusable?.length) return
        const first = focusable[0], last = focusable[focusable.length - 1]
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus() }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus() }
      }
    }
    document.addEventListener('keydown', onKey)
    return () => { clearTimeout(historyTimer);document.body.style.overflow = overflow; document.removeEventListener('keydown', onKey);window.removeEventListener('popstate',onBack);if(history.state?.replaySheet===sheetKey)history.back(); previous?.focus() }
  }, [])
  return <div className="sheet-overlay" onClick={close}><section ref={ref} tabIndex={-1} role="dialog" aria-modal="true" aria-label={title} className={`bottom-sheet ${className}`} style={dragOffset?{transform:`translateY(${dragOffset}px)`,animation:'none'}:undefined} onClick={e => e.stopPropagation()}><button className="sheet-drag" aria-label="Dismiss sheet" onPointerDown={e=>{dragStart.current=e.clientY;e.currentTarget.setPointerCapture(e.pointerId)}} onPointerMove={e=>{if(e.currentTarget.hasPointerCapture(e.pointerId))setDragOffset(Math.max(0,e.clientY-dragStart.current))}} onPointerUp={()=>{if(dragOffset>75)close();else setDragOffset(0)}} onPointerCancel={()=>setDragOffset(0)} onClick={()=>{if(dragOffset<5)close()}}><span className="sheet-handle"/></button><button className="sheet-close icon" aria-label="Close sheet" onClick={close}><X /></button><h2>{title}</h2>{children}</section></div>
}

export function DepositSheet() {
  const { setUI } = useReplayStore()
  const options = [
    { title: 'Crypto', description: 'Set a local practice balance', icon: <QrCode /> },
    { title: 'Debit', description: 'Set a local practice balance', icon: <CreditCard /> },
    { title: 'Exchanges and apps', description: 'Set a local practice balance', icon: <Share2 /> },
  ]
  return <BottomSheet title="Deposit with" close={() => setUI({ sheet: null })} className="deposit-sheet"><p className="deposit-practice">Practice mode · no funds move</p>{options.map(option => <button key={option.title} className="deposit-option" onClick={() => setUI({screen:'backstage',backstageTab:'Funds',sheet:null})}><span><strong>{option.title}</strong><span>{option.description}</span></span>{option.icon}</button>)}</BottomSheet>
}

export function TradeSheet() {
  const { state, ui, setUI, commitEvents, notify } = useReplayStore()
  const draft = ui.tradeDraft!
  const asset = state.assets.find(a => a.id === ui.assetId)!
  const [amount, setAmount] = useState('')
  const [mode, setMode] = useState<'Percent' | 'Amount'>('Percent')
  const [sellValue, setSellValue] = useState('50')
  const [error, setError] = useState('')
  const positionsAt = derivePositions(state.tradeEvents, draft.candle.timestamp)
  const openUnits = positionsAt.find(p => p.assetId === asset.id && p.status === 'open')?.unitsRemaining ?? 0
  const availableCash = cashAt(state.cash, state.tradeEvents, draft.candle.timestamp)
  const units = draft.side === 'buy' ? Number(amount) / draft.candle.close : mode === 'Percent' ? openUnits * Number(sellValue) / 100 : Number(sellValue)

  return <BottomSheet title={draft.side === 'buy' ? 'Buy here' : 'Sell here'} close={() => setUI({ sheet: null, tradeDraft: null })}>
    <div className="trade-asset"><AssetAvatar asset={asset} /><div><strong>{asset.name}</strong><span>{dateTime(draft.candle.timestamp)}</span></div></div>
    <dl className="trade-details"><div><dt>Price</dt><dd>{price(draft.candle.close)}</dd></div><div><dt>Market cap</dt><dd>{money(draft.candle.marketCapUsd ?? null, true)}</dd></div><div><dt>{draft.side === 'buy' ? 'Available cash' : 'Available units'}</dt><dd>{draft.side === 'buy' ? money(availableCash) : `${quantity(openUnits)} ${asset.symbol}`}</dd></div></dl>
    {draft.side === 'buy' ? <label className="field amount-field">Amount invested<span><b>$</b><input aria-label="Amount invested" inputMode="decimal" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value)} /></span></label> : <><Segmented values={['Percent', 'Amount'] as const} value={mode} onChange={value => { setMode(value); setSellValue(value === 'Percent' ? '50' : '') }} label="Sell amount type" />{mode === 'Percent' && <div className="sell-presets">{[25, 50, 75, 100].map(v => <button key={v} className={sellValue === String(v) ? 'active' : ''} onClick={() => setSellValue(String(v))}>{v}%</button>)}</div>}<label className="field">{mode === 'Percent' ? 'Manual percent' : 'Exact token amount'}<input aria-label={mode === 'Percent' ? 'Manual percent' : 'Exact token amount'} inputMode="decimal" value={sellValue} onChange={e => setSellValue(e.target.value)} /></label></>}
    <div className="estimate"><span>{draft.side === 'buy' ? 'Estimated units' : 'Estimated proceeds'}</span><b>{draft.side === 'buy' ? `${quantity(Number.isFinite(units) ? units : 0)} ${asset.symbol}` : money((Number.isFinite(units) ? units : 0) * draft.candle.close)}</b></div>
    {error && <p className="form-error" role="alert">{error}</p>}
    <button className={`primary full ${draft.side === 'sell' ? 'sell' : ''}`} onClick={() => { try { const entered = decimal(draft.side === 'buy' ? amount : sellValue); if (entered <= 0) throw new Error('Enter an amount greater than zero.'); if (draft.side === 'sell' && mode === 'Percent' && entered > 100) throw new Error('Percent must be between 0 and 100.'); if (!Number.isFinite(units) || units <= 0) throw new Error('No units are available to sell at this time.'); const event = { id: crypto.randomUUID(), assetId: asset.id, side: draft.side, timestamp: draft.candle.timestamp, priceUsd: draft.candle.close, marketCapUsd: draft.candle.marketCapUsd ?? null, units, usdValue: units * draft.candle.close }; commitEvents([...state.tradeEvents, event]); setUI({ sheet: null, tradeDraft: null }); notify(draft.side === 'buy' ? 'Buy added to your position' : 'Sell added to your position') } catch (e) { setError(e instanceof Error ? e.message : 'Unable to save trade') } }}>Confirm {draft.side}</button>
  </BottomSheet>
}

export function PositionSheet() {
  const { state, ui, setUI } = useReplayStore()
  const [timeframe, setTimeframe] = useState<ChartTimeframe>('7D')
  const [style,setStyle]=useState<'candles'|'line'>(state.settings.chartStyle)
  const [showMarkers,setShowMarkers]=useState(true)
  const [options,setOptions]=useState(false)
  const asset = state.assets.find(a => a.id === ui.assetId)!
  const quote = quoteAt(asset, state.timeline, state.settings.overrides[asset.id])
  const positions = derivePositions(state.tradeEvents, quote.timestamp)
  const position = positions.find(p => p.id === ui.positionId) ?? positions.filter(p => p.assetId === asset.id).at(-1)
  const events = state.tradeEvents.filter(e => e.assetId === asset.id && e.timestamp <= quote.timestamp)
  const view=position?selectPositionView(state,position.id):null
  const fumble = view?.fumble
  const [detail,setDetail]=useState<string|null>(null)
  const openShare = (kind: 'position' | 'fumble') => { setUI({ sheet: null, screen: 'share', positionId: position!.id, shareKind: kind });window.scrollTo(0,0) }
  return <BottomSheet title="Position" close={() => setUI({ sheet: null })} className="position-sheet">
    <div className="position-heading"><AssetAvatar asset={asset} verified={asset.verified} /><div><button className="position-token-link" onClick={()=>setUI({screen:'token',assetId:asset.id,sheet:null})}><strong>{asset.symbol}</strong><ChevronRight size={18}/></button><span className={`status-badge ${position?.status === 'closed' ? 'closed' : ''}`}>{position?.status === 'closed' ? 'Closed' : 'Open'} <i /></span></div><div className="position-heading-quote"><b>{quote.unavailable?'Unavailable':price(quote.priceUsd)}</b><span className={(quote.priceChange24hPct??0)>=0?'positive':'negative'}>{percent(quote.priceChange24hPct)}</span></div></div>
    <PriceChart candles={visibleCandles(asset.candles, timeframe, quote.timestamp)} events={events} currentPrice={quote.priceUsd} style={style} showMarkers={showMarkers}/>
    <Timeframes value={timeframe} onChange={setTimeframe} style={style} onStyle={()=>setStyle(s=>s==='candles'?'line':'candles')} onOptions={()=>setOptions(v=>!v)}/>
    {options&&<div className="chart-settings"><button role="switch" aria-checked={showMarkers} onClick={()=>setShowMarkers(v=>!v)}>Buy/Sell markers <strong>{showMarkers?'On':'Off'}</strong></button></div>}
    {position ? <><PositionPreview position={position} currentPrice={quote.priceUsd} /><button className="share-bar" onClick={() => openShare('position')}><Share2 /> Share</button>{fumble && <button className="fumble-link" onClick={() => openShare('fumble')}>View Fumble <span>{money(fumble.missedGain)} missed ↗</span></button>}<div className="trade-history"><h3>Trade history</h3>{view?.events.map(event => <div key={event.id} className="trade-event"><button aria-expanded={detail===event.id} onClick={()=>setDetail(detail===event.id?null:event.id)}><span className={event.side==='buy'?'positive':'negative'}>{event.side==='buy'?'+ Buy':'− Sell'}</span><time>{dateTime(event.timestamp)}</time><b>{money(event.usdValue)}</b></button>{detail===event.id&&<dl><div><dt>Units</dt><dd>{quantity(event.units)} {asset.symbol}</dd></div><div><dt>Execution price</dt><dd>{price(event.priceUsd)}</dd></div>{event.marketCapUsd!==null&&<div><dt>Market cap at trade</dt><dd>{money(event.marketCapUsd,true)}</dd></div>}{event.note&&<div><dt>Note</dt><dd>{event.note}</dd></div>}</dl>}</div>)}</div></> : <EmptyState title="No position yet">Add a practice trade to start this position.</EmptyState>}
  </BottomSheet>
}
