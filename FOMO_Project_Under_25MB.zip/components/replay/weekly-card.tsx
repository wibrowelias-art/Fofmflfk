'use client'
import type { WeeklyTrade } from '@/lib/store-types'
import { useReplayStore } from '@/lib/store'
import { signedMoney } from '@/lib/formatting/numbers'
import { Avatar, AssetAvatar } from './common'
export function WeeklyCard({item,onOpen}:{item:WeeklyTrade;onOpen?:()=>void}) {
  const {state}=useReplayStore(),trader=state.traders.find(t=>t.id===item.traderId),asset=state.assets.find(a=>a.id===item.assetId)
  if(!trader||!asset)return null
  const content=<><span className="weekly-trader"><Avatar src={trader.avatar} name={trader.displayName} size="small" verified={trader.verified}/><strong>{trader.displayName}</strong></span><span className="weekly-profit"><AssetAvatar asset={asset} size="small"/><span><b className={item.pnlUsd>=0?'positive':'negative'}>{signedMoney(item.pnlUsd)}</b><small>{asset.symbol}</small></span></span></>
  return onOpen?<button className="weekly-card" onClick={onOpen}>{content}</button>:<div className="weekly-card">{content}</div>
}
