import {defineConfig} from '@playwright/test'
export default defineConfig({testDir:'./e2e',timeout:60000,workers:1,use:{baseURL:'http://localhost:3000',viewport:{width:390,height:844},isMobile:true,hasTouch:true,serviceWorkers:'block',screenshot:'only-on-failure'},webServer:{command:'pnpm dev',url:'http://localhost:3000',reuseExistingServer:true},reporter:[['list'],['html',{open:'never'}]]})
